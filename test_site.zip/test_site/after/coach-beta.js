/* ===================== پنل مربی — بتا (batch 2026-11-03، باگ D) =====================
   ویرایش حرکت اختصاصی مربی. فقط برای حساب‌های بتا (peleh-beta-gate.js)؛ برای بقیه توابع
   اصلی coach-plus.js بدون تغییر صدا زده می‌شن. coach-plus.js خودش دست نخورده.
   نوع ثبت (تکرار/وزنه/زمان) بعد از ساخت قفله: ست‌های ثبت‌شده‌ی شاگردها با همون نوع ذخیره شدن.
   RLS موجود (ex_update) فقط به مالک اجازه‌ی update می‌ده؛ owner_coach_id هم صریحاً شرط شده. */
(function(){
  if(typeof cxOpenCustomExercise !== "function" || typeof cxCustomExercisesBlock !== "function") return;
  function coachBeta(){
    try{ return typeof pelehBetaUser === "function" && typeof C !== "undefined" && C && C.user && pelehBetaUser(C.user.id); }
    catch(e){ return false; }
  }
  window.isCoachBeta = coachBeta;
  const origOpen = cxOpenCustomExercise;
  const origBlock = cxCustomExercisesBlock;

  function openBeta(prefill, editId){
    const cats = ((typeof PLUS_BANK !== "undefined" && PLUS_BANK && PLUS_BANK.cats) || []);
    const opt = (obj, sel) => Object.entries(obj).map(([k, v]) => `<option value="${k}" ${k === sel ? "selected" : ""}>${esc(v)}</option>`).join("");
    const x = editId ? (C.customExercises || []).find(r => r.id === editId) : null;
    if(editId && !x){ toast("این حرکت پیدا نشد؛ صفحه رو تازه کن."); return; }
    if(!x) return origOpen(prefill); // ساختن حرکت تازه: همون فرم live
    const v = {
      fa: x.name_fa || "", en: x.name_en || "", al: (x.aliases || []).join("، "), lt: x.log_type || "reps_weight",
      dc: (x.disciplines || [])[0] || "bodybuilding", cat: x.category_id == null ? "" : String(x.category_id), eq: x.equipment || "",
      df: x.difficulty == null ? "" : String(x.difficulty), uni: !!x.unilateral, risk: x.risk === "needs_assessment",
      note: (x.extra && x.extra.notes) || "",
    };
    const dfOpts = [["1", "مبتدی"], ["2", "متوسط"], ["3", "پیشرفته"], ["4", "نخبه"]].map(([k, l]) => `<option value="${k}" ${k === v.df ? "selected" : ""}>${l}</option>`).join("");
    openSheet(`<h3>✏️ ویرایش حرکت اختصاصی</h3>
      <div class="c-note" style="margin-bottom:8px;">تغییرها همون لحظه تو برنامه‌ساز و برنامه‌هایی که این حرکت رو دارن دیده می‌شه.</div>
      <div class="c-field"><label>اسم فارسی *</label><input id="ce_fa" class="c-input" maxlength="80" value="${esc(v.fa)}" placeholder="مثلاً: پرس سینه دستگاه همر"></div>
      <div class="c-field"><label>اسم انگلیسی (اختیاری)</label><input id="ce_en" class="c-input" maxlength="80" dir="ltr" value="${esc(v.en)}" placeholder="Hammer Strength Chest Press"></div>
      <div class="c-field"><label>اسم‌های دیگه برای جستجو (با «،» جدا)</label><input id="ce_al" class="c-input" maxlength="200" value="${esc(v.al)}" placeholder="همر، پرس همر"></div>
      <div class="c-field" style="display:flex; gap:8px; flex-wrap:wrap;">
        <div style="flex:1 1 140px;"><label>نوع ثبت *</label><select id="ce_lt" class="c-input" disabled>${opt(EX_LOG_TYPES_FA, v.lt)}</select>
          <div class="c-note" style="margin-top:4px;">نوع ثبت بعد از ساخت عوض نمی‌شه (تاریخچه‌ی شاگردها خراب می‌شه).</div></div>
        <div style="flex:1 1 140px;"><label>رشته</label><select id="ce_dc" class="c-input">${opt(EX_DISCIPLINES_FA, v.dc)}</select></div>
      </div>
      <div class="c-field" style="display:flex; gap:8px; flex-wrap:wrap;">
        <div style="flex:1 1 160px;"><label>گروه عضلانی / دسته</label><select id="ce_cat" class="c-input"><option value="">—</option>${cats.map(c => `<option value="${c.id}" ${String(c.id) === v.cat ? "selected" : ""}>${esc(c.name)}</option>`).join("")}</select></div>
        <div style="flex:1 1 140px;"><label>تجهیزات</label><select id="ce_eq" class="c-input"><option value="">—</option>${opt(EX_EQUIPMENT_FA, v.eq)}</select></div>
      </div>
      <div class="c-field" style="display:flex; gap:8px; flex-wrap:wrap; align-items:flex-end;">
        <div style="flex:1 1 120px;"><label>سطح</label><select id="ce_df" class="c-input"><option value="">—</option>${dfOpts}</select></div>
        <label class="c-check" style="flex:1 1 120px;"><input id="ce_uni" type="checkbox" ${v.uni ? "checked" : ""}> یک‌طرفه (تک‌دست/تک‌پا)</label>
        <label class="c-check" style="flex:1 1 160px;"><input id="ce_risk" type="checkbox" ${v.risk ? "checked" : ""}> نیازمند ارزیابی سطح ⚠️</label>
      </div>
      <div class="c-field"><label>نکته‌ی اجرا (اختیاری)</label><textarea id="ce_note" class="c-input" maxlength="500" placeholder="تنظیم دستگاه، دامنه‌ی حرکت، …">${esc(v.note)}</textarea></div>
      <div class="c-err" id="ce_err"></div>
      <div class="c-row-btns"><button class="c-btn ghost" onclick="cCloseSheet()">انصراف</button><button class="c-btn primary" id="ce_save" onclick="cxUpdateCustomExercise('${esc(x.id)}')">ذخیره‌ی تغییرات</button></div>`);
    setTimeout(() => { const el = document.getElementById("ce_fa"); if(el) el.focus(); }, 30);
  }

  // همون نرمال‌سازی ساده‌ای که سرور (peleh_norm_fa) برای «تکراری نبودن اسم» داره، فقط برای پیام زودتر
  function normFa(s){ return String(s || "").replace(/[يى]/g, "ی").replace(/ك/g, "ک").replace(/[‌‏ً-ْ]/g, "").replace(/\s+/g, " ").trim().toLowerCase(); }

  window.cxUpdateCustomExercise = async function(id){
    if(!coachBeta()) return;
    const g = el => document.getElementById(el);
    const err = g("ce_err"), btn = g("ce_save");
    const x = (C.customExercises || []).find(r => r.id === id);
    if(!x){ err.textContent = "این حرکت پیدا نشد؛ صفحه رو تازه کن."; return; }
    const nm = g("ce_fa").value.trim().replace(/\s+/g, " ");
    if(nm.length < 2 || nm.length > 80){ err.textContent = "اسم حرکت رو کامل بنویس (۲ تا ۸۰ حرف)"; return; }
    if((C.customExercises || []).some(r => r.id !== id && normFa(r.name_fa) === normFa(nm))){ err.textContent = "یه حرکت دیگه با همین اسم ساختی"; return; }
    const dc = ["bodybuilding", "calisthenics", "cardio"].includes(g("ce_dc").value) ? g("ce_dc").value : "bodybuilding";
    const df = g("ce_df").value ? +g("ce_df").value : null;
    const payload = {
      name_fa: nm,
      name_en: g("ce_en").value.trim() || null,
      aliases: g("ce_al").value.split(/[،,]/).map(a => a.trim().slice(0, 60)).filter(Boolean),
      disciplines: [dc],
      category_id: g("ce_cat").value ? +g("ce_cat").value : (dc === "cardio" ? 26 : null),
      equipment: g("ce_eq").value || null,
      unilateral: g("ce_uni").checked,
      difficulty: df && df >= 1 && df <= 4 ? df : null,
      risk: g("ce_risk").checked ? "needs_assessment" : null,
      extra: Object.assign({}, x.extra || {}, { custom: true, notes: g("ce_note").value.trim().slice(0, 500) }),
    };
    btn.disabled = true; err.textContent = "";
    const { data, error } = await sb.from("exercises").update(payload).eq("id", id).eq("owner_coach_id", C.user.id).select("*");
    if(error){ err.textContent = errText(error); btn.disabled = false; return; }
    const row = Array.isArray(data) ? data[0] : data;
    if(!row){ err.textContent = "ذخیره نشد — فقط سازنده‌ی حرکت می‌تونه ویرایشش کنه."; btn.disabled = false; return; }
    C.customExercises = (C.customExercises || []).map(r => r.id === id ? row : r);
    exAddCustomExercises([row]);
    cCloseSheet();
    toast(`«${row.name_fa}» ذخیره شد`);
    render();
  };

  cxOpenCustomExercise = function(prefill, editId){
    if(!coachBeta() || !editId) return origOpen(prefill);
    return openBeta(prefill, editId);
  };
  cxCustomExercisesBlock = function(){
    if(!coachBeta()) return origBlock();
    const list = C.customExercises || [];
    return `<div class="c-h">🏷️ حرکت‌های اختصاصی من <button class="c-btn ghost" style="min-height:38px; padding:6px 12px;" onclick="cxOpenCustomExercise('')">+ حرکت</button></div>
      <div class="c-card">${list.length ? list.map(x => `<div class="c-list-row"><div class="grow"><div class="c-name">${esc(x.name_fa)}</div>
        <div class="c-note">${esc(EX_LOG_TYPES_FA[x.log_type] || "")}${x.equipment ? " · " + esc(EX_EQUIPMENT_FA[x.equipment] || x.equipment) : ""}${(x.disciplines || []).length ? " · " + esc(EX_DISCIPLINES_FA[x.disciplines[0]] || "") : ""}</div></div>
        <button class="c-link" onclick="cxOpenCustomExercise('', '${esc(x.id)}')" aria-label="ویرایش ${esc(x.name_fa)}">ویرایش</button>
        <button class="c-link" onclick="cxArchiveCustomExercise('${esc(x.id)}')" aria-label="بایگانی ${esc(x.name_fa)}">بایگانی</button></div>`).join("")
        : `<div class="c-note">حرکتی که تو بانک پله نیست رو اینجا بساز؛ بدون نیاز به تأیید، همون لحظه تو برنامه‌ساز با برچسب «اختصاصی» میاد.</div>`}</div>`;
  };
})();
