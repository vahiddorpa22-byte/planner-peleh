/* تنظیمات سوییچ خودکار به سرور ایران (peleh-failover.js)
   fallbackKey = کلید «anon» سرور ایران — بعد از نصب سرور (مرحله‌ی ۴ راهنما) این‌جا جایگزین می‌شه.
   تا وقتی مقدار PASTE_... بمونه، سوییچ خودکار کاملاً غیرفعاله و برنامه مثل قبل کار می‌کنه. */
window.PELEH_FAILOVER = {
  fallbackUrl: "https://api.pelehapp.ir",
  fallbackKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzkyNTY5MzIxLCJleHAiOjIxMDc5MjkzMjF9.UE0u1KXSOlBYrl-iZNaQwlMtvkhLwKg2Hqp1eMsgWLk"
};
