/* ===================== پنل ادمین — کوهورت هفتگی (batch 2026-11-03، A1) =====================
   پنل ادمین از قبل فقط برای ادمین‌ها باز می‌شه؛ این کارت فقط خوندنیه و از همون داده‌ای که صفحه‌ی
   «رفتار کاربران» لود کرده (users[].data.history) حساب می‌شه. نه کوئری تازه، نه نوشتن.
   admin.js دست نخورده: renderBehaviorView پیچیده می‌شه و کارت بالای «قیف فعال‌سازی» میاد.

   تعریف‌ها (همون‌ها داخل کارت هم نوشته شده):
     کوهورت  = هفته‌ی ثبت‌نام (شنبه تا جمعه، به وقت مرورگر ادمین)
     فعال    = حداقل ۱ تیک عادت در اون روز (کلیدهای data.history که خالی نیستن؛ تاریخ دستگاه کاربر)
     D0      = تیک در همون روز ثبت‌نام
     D1/D3/D7 = تیک دقیقاً در روز ۱/۳/۷ بعد از روز ثبت‌نام
     هفته‌ی اول = حداقل یه تیک در روزهای ۱ تا ۷
     مخرج هر ستون فقط کسایی‌ان که اون روز براشون کامل گذشته (بقیه «—»)
     حساب‌های تست مثل بقیه‌ی پنل حذف‌ان (realUsers) */
(function(){
  if(typeof renderBehaviorView !== "function") return;
  const orig = renderBehaviorView;
  function addDays(d, n){ const x = new Date(d); x.setDate(x.getDate() + n); return x; }
  function weekStart(d){ const x = new Date(d); x.setHours(0, 0, 0, 0); const back = (x.getDay() + 1) % 7; x.setDate(x.getDate() - back); return x; } // شنبه
  function cohortRows(){
    const list = (typeof realUsers === "function" ? realUsers() : users) || [];
    const todayK = todayKeyLocal(new Date());
    const map = new Map();
    list.forEach(u => {
      if(!u || !u.created_at) return;
      const created = new Date(u.created_at);
      if(isNaN(created.getTime())) return;
      const ws = weekStart(created), key = todayKeyLocal(ws);
      if(!map.has(key)) map.set(key, { ws, n: 0, d0: [0, 0], d1: [0, 0], d3: [0, 0], d7: [0, 0], w1: [0, 0] });
      const c = map.get(key);
      c.n++;
      const hist = (u.data && u.data.history) || {};
      const tick = new Set(Object.keys(hist).filter(k => Array.isArray(hist[k]) && hist[k].length));
      const day = n => todayKeyLocal(addDays(created, n));
      const cell = (slot, n, hit) => { if(day(n) < todayK){ c[slot][1]++; if(hit) c[slot][0]++; } };
      cell("d0", 0, tick.has(day(0)));
      cell("d1", 1, tick.has(day(1)));
      cell("d3", 3, tick.has(day(3)));
      cell("d7", 7, tick.has(day(7)));
      let any = false; for(let i = 1; i <= 7; i++) if(tick.has(day(i))) any = true;
      cell("w1", 7, any);
    });
    return Array.from(map.values()).sort((a, b) => b.ws - a.ws).slice(0, 12);
  }
  function pctCell(p){
    if(!p[1]) return `<td class="mono" style="color:var(--faint);">—</td>`;
    const v = Math.round(p[0] / p[1] * 100);
    return `<td class="mono" style="white-space:nowrap;"><b>${faNum(v)}٪</b> <span class="muted-s">(${faNum(p[0])} از ${faNum(p[1])})</span></td>`;
  }
  function cohortCard(){
    const rows = cohortRows();
    const tot = rows.reduce((t, r) => { ["d0", "d1", "d3", "d7", "w1"].forEach(k => { t[k][0] += r[k][0]; t[k][1] += r[k][1]; }); t.n += r.n; return t; },
      { n: 0, d0: [0, 0], d1: [0, 0], d3: [0, 0], d7: [0, 0], w1: [0, 0] });
    return `<div class="panel scroll-x" style="margin-bottom:22px;">
      <div class="panel-head"><h3>کوهورت هفتگی ثبت‌نام <span class="muted-s">برگشت فعال در روز ۱، ۳ و ۷</span></h3></div>
      <table>
        <thead><tr><th>هفته (از شنبه)</th><th>ثبت‌نام</th><th>D0 (همون روز)</th><th>D1</th><th>D3</th><th>D7</th><th>هفته‌ی اول (روز ۱ تا ۷)</th></tr></thead>
        <tbody>
          ${rows.length ? rows.map(r => `<tr><td data-label="هفته" class="mono">${fmtDate(r.ws.toISOString())}</td><td data-label="ثبت‌نام" class="mono">${faNum(r.n)}</td>${pctCell(r.d0)}${pctCell(r.d1)}${pctCell(r.d3)}${pctCell(r.d7)}${pctCell(r.w1)}</tr>`).join("")
            : `<tr><td colspan="7" class="empty-state">کاربری نیست.</td></tr>`}
          ${rows.length > 1 ? `<tr style="font-weight:800;"><td>جمع ${faNum(rows.length)} هفته</td><td class="mono">${faNum(tot.n)}</td>${pctCell(tot.d0)}${pctCell(tot.d1)}${pctCell(tot.d3)}${pctCell(tot.d7)}${pctCell(tot.w1)}</tr>` : ``}
        </tbody>
      </table>
      <div class="page-sub" style="padding:10px 20px 14px; line-height:2;">
        <b>تعریف‌ها:</b> «فعال» = حداقل ۱ تیک عادت در اون روز (تاریخ دستگاه کاربر). D0 = تیک در روز ثبت‌نام؛ D1/D3/D7 = تیک دقیقاً در روز ۱/۳/۷ بعد از ثبت‌نام؛ «هفته‌ی اول» = حداقل یه تیک در روزهای ۱ تا ۷.
        مخرج هر خونه فقط کسایی‌ان که اون روز براشون کامل گذشته (عدد داخل پرانتز = تیک‌زده/واجد شرایط). حساب‌های تست ${typeof includeTestUsers !== "undefined" && includeTestUsers ? "<b>شامل شدن</b>" : "حذف شدن"}.
        <br><span style="color:var(--faint);">ثبت مطالعه‌ی کتاب و ثبت‌های سلامت اینجا حساب نمی‌شن؛ فقط تیک عادت‌ها. ۱۲ هفته‌ی آخر.</span>
      </div>
    </div>`;
  }
  renderBehaviorView = function(){
    const html = orig.apply(this, arguments);
    try{
      const i = html.indexOf('<div class="pulse-card">');
      return i < 0 ? html + cohortCard() : html.slice(0, i) + cohortCard() + html.slice(i);
    }catch(e){ console.error("cohort card failed:", e); return html; }
  };
})();
