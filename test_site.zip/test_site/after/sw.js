// test: no SW caching
