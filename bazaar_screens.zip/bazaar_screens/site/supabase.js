/* LOCAL SCREENSHOT ONLY (Bazaar store screens, 2026-11-08) — never upload. Demo data only; no real user data.
   ?act= screen to open ~1.8 s after load (see A below). */
(function(){
  var qs = new URLSearchParams(location.search);
  try{ localStorage.setItem("pelehInstallSeenAt", String(Date.now())); }catch(e){}
  var UID = "55555555-5555-4555-8555-555555555555";
  function tk(d){ d = d || new Date(); return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0"); }
  function ago(n){ var d = new Date(); d.setDate(d.getDate() - n); d.setHours(20, 0, 0, 0); return d; }

  var acts = [
    { id: "act_1", title: "کتاب خوندن", points: 15, days: ["daily"], icon: "📖" },
    { id: "act_2", title: "پیاده‌روی ۳۰ دقیقه", points: 15, days: ["daily"], icon: "🚶" },
    { id: "act_3", title: "۸ لیوان آب", points: 5, days: ["daily"], icon: "💧" },
    { id: "act_4", title: "مدیتیشن", points: 10, days: ["daily"], icon: "🧘" },
    { id: "act_5", title: "زبان انگلیسی", points: 10, days: ["daily"], icon: "🗣️" }
  ];
  var history = {};
  var skip = { 3: ["act_4"], 6: ["act_2", "act_5"], 9: ["act_3"], 13: ["act_1", "act_4"], 17: ["act_2"], 21: ["act_5", "act_4"], 24: ["act_3"] };
  for(var i = 1; i <= 27; i++){
    history[tk(ago(i))] = acts.map(function(a){ return a.id; }).filter(function(id){ return !(skip[i] || []).includes(id); });
  }
  history[tk()] = ["act_1", "act_3"];

  var lib = [
    { id: 1, title: "عادت‌های اتمی", authors: "جیمز کلیر", status: "reading", pages: 320, currentPage: 212, genre: "روان‌شناسی" },
    { id: 2, title: "صد سال تنهایی", authors: "گابریل گارسیا مارکز", status: "finished", pages: 460, currentPage: 460, genre: "رمان", finishedAt: ago(9).toISOString() },
    { id: 3, title: "انسان در جستجوی معنا", authors: "ویکتور فرانکل", status: "finished", pages: 200, currentPage: 200, genre: "روان‌شناسی", finishedAt: ago(22).toISOString() },
    { id: 4, title: "شازده کوچولو", authors: "آنتوان دو سنت‌اگزوپری", status: "want", pages: 120, currentPage: 0, genre: "رمان" }
  ];
  var log = [];
  for(var j = 0; j <= 18; j++){
    if(j === 7 || j === 15) continue;
    log.push({ id: "l" + j, bookId: j < 9 ? 1 : 2, dateKey: tk(ago(j)), minutes: 20 + (j % 4) * 5, pages: 10 + (j % 3) * 4, note: "", points: 6, ts: ago(j).getTime() });
  }
  var weightLog = [];
  [28, 21, 14, 7, 0].forEach(function(n, k){ weightLog.push({ d: tk(ago(n)), kg: [72.4, 71.9, 71.5, 71.0, 70.6][k] }); });

  var data = {
    settings: { showAllSections: true, reminderSlot: "evening" },
    activities: acts, history: history,
    seenCoach: { quickstart_v1: true, today: true, today2: true, books: true, health: true, plus: true }, seenTips: { task_tiers: true, leaderboard_structure: true, challenge_rewards: true },
    funnel: { first_habit: "2026-10-01T00:00:00Z" },
    dailyExtra: {}, nextTaskSeq: 20, nextActivitySeq: 10,
    rewards: [ { id: 1, title: "یه قهوه‌ی خوب ☕", points: 300 }, { id: 2, title: "یه کتاب تازه 📚", points: 900 }, { id: 3, title: "یه روز سفر 🏞️", points: 3000 } ], nextRewardId: 4,
    workProfile: { completed: true, employment: null, workStart: "", workEnd: "", interests: [], interestsCustom: "" },
    books: { onboarded: true, interests: ["روان‌شناسی", "رمان"], library: lib, log: log, points: 1840, challenges: [ { id: "c30day", joinedAt: ago(16).toISOString(), done: false, doneAt: null, missedDays: 0, _synced: true } ],
      nextLibId: 5, nextLogId: 40, lastPenaltyCheck: tk(), streak: { count: 9, lastDate: tk(), best: 14 }, badges: ["first_book", "streak7"] },
    health: { profile: { completed: true, age: 29, height: 165, currentWeight: 70.6, targetWeight: 66, mainGoal: "fit", mainGoals: ["fit"], activityLevel: "light",
      daysPerWeek: 3, minutesPerSession: 45, level: "beginner", equipment: [] }, sports: { likes: ["walking", "yoga"], dislikes: [], customLike: "", discovery: null }, weightLog: weightLog },
    beta: { lamMax: 2, sport: "yoga", lamIntroSeen: true }
  };
  data.dailyExtra[tk()] = { tasks: [
    { id: "task_11", text: "۲۰ صفحه از «عادت‌های اتمی»", priority: "important", done: true, starred: true },
    { id: "task_12", text: "تمرین یوگا ۱۵ دقیقه", priority: "important", done: false, starred: false },
    { id: "task_13", text: "برنامه‌ی هفته‌ی بعد رو بنویسم", priority: "normal", done: false, starred: false }
  ] };
  var profile = { id: UID, name: "سارا", phone: "09120000000", phone_verified: true, verified_phone: "09120000000",
    birthdate: null, photo: null, referral_code: "SARA24", email: "09120000000@phone.pelehapp.ir", created_at: "2026-09-01T00:00:00Z", data: data };
  var user = { id: UID, email: "09120000000@phone.pelehapp.ir", app_metadata: { provider: "email" } };

  // نفرات برتر (اسم‌های ساختگی)
  var names = ["مریم", "سارا", "علی", "نگار", "رضا", "هستی", "امید", "پریا", "کیان", "مهسا", "آرش", "یاسمن"];
  var pts = [2480, 2210, 1975, 1820, 1690, 1540, 1410, 1300, 1185, 1060, 940, 870];
  function monthKeyNow(){ try{ return jalaliMonthKey(); }catch(e){ return ""; } }
  var lbRows = names.map(function(n, k){ return { user_id: k === 1 ? UID : ("66666666-6666-4666-8666-" + String(100000000000 + k)), display_name: n, month_points: pts[k], year_points: pts[k] * 3, total_points: pts[k] * 4, month_key: "__M__", year_key: "__Y__" }; });

  window.__MOCK_INIT = { user: user, profile: profile, tables: { leaderboard: lbRows, leaderboard_awards: [], support_messages: [], workout_sets: [], exercises: [] },
    rpc: {
      peleh_client_flags: { plus_enabled: true, quickstart_v1: true, min_app_version: "0" },
      plus_status: { enabled: true, role: "athlete", has_plus: true, require_entitlement: false, payments_enabled: false, bazaar_enabled: true, bazaar_days: 30, plan_days: 30, price_toman: 500000, payment_note: "", pending_payment: false, plus_until: null },
      athlete_progress_summary: [], family_progress: [], skill_progress_status: [], athlete_my_coaches: [], athlete_body_shares: [], last_sets_for: {},
      peleh_report_client: null, peleh_my_health_points: { points: 0 }, peleh_book_event: { ok: true }, peleh_join_challenge: { ok: true }
    },
    invoke: {} };
  // month/year key را بعد از لود app.js درست کن
  window.addEventListener("DOMContentLoaded", function(){
    try{ var mk = jalaliMonthKey(), yk = jalaliYearKey(); lbRows.forEach(function(r){ r.month_key = mk; r.year_key = yk; }); }catch(e){}
    try{ window.hasSeenCoach = function(){ return true; }; window.renderTipBanner = function(){ return ""; }; }catch(e){}
  });
})();

/* LOCAL SCREENSHOT ONLY: open a screen */
(function(){
  var qs = new URLSearchParams(location.search);
  var act = qs.get("act");
  if(!act) return;
  function byText(sel, txt){ return Array.prototype.find.call(document.querySelectorAll(sel), function(x){ return x.textContent.indexOf(txt) >= 0; }); }
  function scrollToText(sel, txt, off){ var el = byText(sel, txt); if(el){ el.scrollIntoView({ block: "start" }); window.scrollBy(0, off || -70); } }
  window.__A = {
    today: function(){},
    habits: function(){
      var tile = document.getElementById("coach-task-tiers"); if(!tile) return;
      var grid = tile.parentElement;
      Array.prototype.forEach.call(grid.parentElement.children, function(c){ if(c !== grid && (c.compareDocumentPosition(grid) & Node.DOCUMENT_POSITION_FOLLOWING)) c.style.display = "none"; });
      Array.prototype.forEach.call(grid.children, function(c){ if(c !== tile && (c.compareDocumentPosition(tile) & Node.DOCUMENT_POSITION_FOLLOWING)) c.style.display = "none"; });
    },
    calendar: function(){ switchTab("calendar"); },
    books: function(){ booksSubTab = "home"; switchTab("books"); },
    library: function(){ booksSubTab = "library"; switchTab("books"); },
    challenges: function(){ booksSubTab = "challenges"; switchTab("books"); },
    leaderboard: function(){ booksSubTab = "challenges"; switchTab("books"); setTimeout(openLeaderboard, 300); },
    lambook: function(){ openLamBook(); },
    health: function(){ switchTab("health"); },
    plus: function(){ switchTab("plus"); },
    rewards: function(){ openRewards(); },
    more: function(){ switchTab("more"); },
    settings: function(){ switchTab("settings"); }
  };
  var st = document.createElement("style");
  st.textContent = ".screen{animation:none!important;opacity:1!important;transform:none!important} .overlay,.sheet,.c-sheet-wrap,.c-sheet,.drawer,.drawer-overlay{transition:none!important;animation:none!important} html{scroll-behavior:auto!important} .tip-banner{display:none!important}";
  document.addEventListener("DOMContentLoaded", function(){ document.head.appendChild(st); });
  window.addEventListener("load", function(){ setTimeout(function(){ try{ (window.__A[act] || function(){})(); }catch(e){ console.error("act failed", e); } }, 1800); });
})();

/* Mock سبک supabase-js برای تست مرورگری (فقط تست — در production استفاده نمی‌شه).
   وضعیت از window.__MOCK_INIT (اگه قبل از این فایل تعریف شده باشه) خونده می‌شه:
     { user:{id,email}, profile:{...row}, rpc:{name: value | (args)=>value}, tables:{name:[rows]} }
   همه‌ی فراخوانی‌ها در window.__mock.calls ثبت می‌شن. */
(function(){
  const init = window.__MOCK_INIT || {};
  const M = window.__mock = {
    user: ("user" in init) ? init.user : { id: "11111111-1111-4111-8111-111111111111", email: "09120000000@phone.peleh" },
    profile: init.profile || null,
    rpc: init.rpc || {},
    tables: init.tables || {},
    invoke: init.invoke || {},
    calls: [],
  };
  const ok = (data, extra) => Promise.resolve(Object.assign({ data, error: null, count: Array.isArray(data) ? data.length : 0 }, extra || {}));
  function exec(st){
    M.calls.push({ table: st.table, op: st.op, payload: st.payload, filters: st.filters, select: st.selectArgs });
    if(st.table === "profiles" && M.profile){
      if(st.op === "select"){
        const sel = (st.selectArgs && st.selectArgs[0]) || "*";
        let row = M.profile;
        if(/rev:data->>_rev/.test(sel)) row = { rev: (M.profile.data || {})._rev || null };
        else if(sel === "data") row = { data: M.profile.data };
        return ok(st.single ? JSON.parse(JSON.stringify(row)) : [JSON.parse(JSON.stringify(row))]);
      }
      if(st.op === "update"){
        const p = JSON.parse(JSON.stringify(st.payload || {}));
        Object.assign(M.profile, p);
        return ok(st.selectArgs ? [{ id: M.profile.id }] : null);
      }
      if(st.op === "upsert" || st.op === "insert") return ok(null);
    }
    let rows = M.tables[st.table] || [];
    // batch 2026-11-08: ساده‌ترین فیلتر .eq روی ستون‌های بدون نقطه (برای count خوانده‌نشده و ست‌های یه حرکت)
    if(st.op === "select") rows = rows.filter(r => st.filters.every(f => f[0] !== "eq" || String(f[1]).indexOf(".") >= 0 || !(f[1] in r) || String(r[f[1]]) === String(f[2])));
    if(st.op === "select"){
      if(st.selectArgs && st.selectArgs[1] && st.selectArgs[1].head) return ok(null, { count: rows.length });
      return ok(st.single ? (rows[0] || null) : rows);
    }
    if(st.op === "insert" || st.op === "upsert"){
      const arr = Array.isArray(st.payload) ? st.payload : [st.payload];
      M.tables[st.table] = rows.concat(arr);
      return ok(st.selectArgs ? arr : null);
    }
    if(st.op === "update"){
      // batch test: update rows that match every .eq(col, val) filter
      const hit = rows.filter(r => st.filters.every(f => f[0] !== "eq" || String(r[f[1]]) === String(f[2])));
      hit.forEach(r => Object.assign(r, JSON.parse(JSON.stringify(st.payload || {}))));
      if(M.failNextUpdate){ M.failNextUpdate = false; return Promise.resolve({ data: null, error: { message: "mock update failed", code: "42501" } }); }
      return ok(st.selectArgs ? JSON.parse(JSON.stringify(hit)) : null);
    }
    return ok(st.selectArgs ? [] : null);
  }
  function query(table){
    const st = { table, op: "select", filters: [], payload: null, single: false, selectArgs: null };
    const q = new Proxy(function(){}, {
      get(_t, prop){
        if(prop === "then"){ const p = exec(st); return p.then.bind(p); }
        if(prop === "catch" || prop === "finally"){ const p = exec(st); return p[prop].bind(p); }
        return (...args) => {
          if(prop === "select"){ st.selectArgs = args; }
          else if(["update", "insert", "upsert", "delete"].includes(prop)){ st.op = prop; st.payload = args[0]; }
          else if(prop === "maybeSingle" || prop === "single"){ st.single = true; }
          else st.filters.push([prop].concat(args));
          return q;
        };
      },
    });
    return q;
  }
  const channelObj = { on(){ return channelObj; }, subscribe(){ return channelObj; }, unsubscribe(){} };
  const client = {
    from: query,
    rpc(name, args){
      M.calls.push({ rpc: name, args });
      const v = M.rpc[name];
      if(v === undefined) return Promise.resolve({ data: null, error: { message: "mock: rpc " + name + " not defined", code: "PGRST202" } });
      try{ return ok(typeof v === "function" ? v(args) : v); }
      catch(e){ return Promise.resolve({ data: null, error: { message: e.message } }); }
    },
    functions: { invoke(name, opts){
      M.calls.push({ invoke: name, body: opts && opts.body });
      const v = M.invoke[name];
      return Promise.resolve({ data: v === undefined ? { success: false } : (typeof v === "function" ? v(opts && opts.body) : v), error: null });
    } },
    auth: {
      getSession(){ return Promise.resolve({ data: { session: M.user ? { user: M.user, access_token: "mock" } : null }, error: null }); },
      getUser(){ return Promise.resolve({ data: { user: M.user }, error: null }); },
      onAuthStateChange(){ return { data: { subscription: { unsubscribe(){} } } }; },
      signOut(){ M.user = null; return Promise.resolve({ error: null }); },
      refreshSession(){ return Promise.resolve({ data: { session: { user: M.user } }, error: null }); },
    },
    storage: { from(bucket){ return {
      upload(path){ M.calls.push({ upload: bucket + "/" + path }); return ok({ path }); },
      createSignedUrl(path){ return ok({ signedUrl: "data:image/gif;base64,R0lGODlhAQABAAAAACw=" }); },
      createSignedUrls(paths){ return ok((paths || []).map(p => ({ path: p, signedUrl: "data:image/svg+xml;utf8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="60" height="80"><rect width="60" height="80" fill="#8a7"/></svg>') }))); },
      getPublicUrl(path){ return { data: { publicUrl: "/mock/" + bucket + "/" + path } }; },
      remove(){ return ok([]); },
    }; } },
    channel(){ return channelObj; },
    removeChannel(){ return Promise.resolve(); },
  };
  window.supabase = { createClient(){ return client; } };
})();