"""Lam ep3: remove the baked face from both talking plates (same method as ep2_faceless.py).
A = Vahid's still (phone pose, 1116x2000) · B = last frame of his Flow clip (book pose; 720x1280 upscaled to 1116x2000).
Low frequency: quarter-scale inpaint + a cubic surface fitted on clean clay of the face plane (feathered).
High frequency: procedural clay grain matched to a clean cheek patch. Output: ep3/lam_ep3_{A,B}_faceless.png + checks.
"""
from pathlib import Path
import numpy as np, cv2

EP = Path(__file__).resolve().parents[2] / "ep3"
(EP / "_build").mkdir(exist_ok=True)

PLATES = {
    "A": dict(src="lam_ep3_start.jpg", s=1.0,
              eyes=(((540, 826), (56, 60)), ((641, 829), (56, 60))),
              brows=(((495, 769), (520, 752), (544, 747), (568, 750), (592, 759)),
                     ((588, 757), (612, 745), (636, 741), (660, 745), (688, 759))),
              mouth=((548, 906), (572, 913), (592, 915), (612, 913), (630, 906)),
              box=(488, 692, 690, 990), c=(590, 840), sc=(102, 150), patch=(930, 990, 640, 720), seed=7),
    "B": dict(src="lam_ep3_B_start.png", s=1.8,
              eyes=(((503, 812), (110, 114)), ((684, 812), (110, 114))),
              brows=(((416, 702), (465, 660), (506, 650), (553, 656), (573, 670)),
                     ((587, 673), (636, 642), (683, 634), (730, 648), (767, 688))),
              mouth=((510, 942), (559, 967), (606, 973), (653, 967), (703, 942)),
              box=(398, 585, 808, 1045), c=(600, 815), sc=(205, 230), patch=(1000, 1050, 700, 780), seed=11),
}


def run(key, P):
    img = cv2.imread(str(EP / P["src"])).astype(np.float32)
    H, W = img.shape[:2]
    s = P["s"]
    m = np.zeros((H, W), np.uint8)
    for c, ax in P["eyes"]:
        cv2.ellipse(m, c, ax, 0, 0, 360, 255, -1)
    for pts in P["brows"]:
        cv2.polylines(m, [np.array(pts, np.int32)], False, 255, int(26 * s), cv2.LINE_AA)
    cv2.polylines(m, [np.array(P["mouth"], np.int32)], False, 255, int(16 * s * (1.4 if s > 1 else 1) * ({"C": 1.3, "D": 1.7}.get(key, 1))), cv2.LINE_AA)
    m = cv2.dilate(m, np.ones((int(9 * s) | 1, int(9 * s) | 1), np.uint8))

    q = 4
    small = cv2.resize(img, (W // q, H // q), interpolation=cv2.INTER_AREA).astype(np.uint8)
    ms = cv2.dilate(cv2.resize(m, (W // q, H // q), interpolation=cv2.INTER_NEAREST), np.ones((3, 3), np.uint8))
    low = cv2.inpaint(small, ms, 6, cv2.INPAINT_TELEA).astype(np.float32)
    low = cv2.GaussianBlur(cv2.resize(low, (W, H), interpolation=cv2.INTER_CUBIC), (0, 0), 6)

    FX0, FY0, FX1, FY1 = P["box"]
    yy, xx = np.mgrid[FY0:FY1, FX0:FX1]
    clean = cv2.dilate(m, np.ones((15, 15), np.uint8))[FY0:FY1, FX0:FX1] == 0
    u = (xx - P["c"][0]) / P["sc"][0]; v = (yy - P["c"][1]) / P["sc"][1]

    def basis(u, v):
        return np.stack([np.ones_like(u), u, v, u * u, u * v, v * v, u ** 3, u * u * v, u * v * v, v ** 3], -1)

    A = basis(u[clean], v[clean])
    smooth = cv2.GaussianBlur(img, (0, 0), 2.5)[FY0:FY1, FX0:FX1]
    surf = np.zeros_like(smooth)
    for ch in range(3):
        coef, *_ = np.linalg.lstsq(A, smooth[..., ch][clean], rcond=None)
        surf[..., ch] = basis(u, v) @ coef
    wy = np.clip(np.minimum(yy - FY0, FY1 - 1 - yy) / 25.0, 0, 1)
    wx = np.clip(np.minimum(xx - FX0, FX1 - 1 - xx) / 12.0, 0, 1)
    wb = (wy * wx)[..., None]
    low[FY0:FY1, FX0:FX1] = low[FY0:FY1, FX0:FX1] * (1 - wb) + surf * wb

    y0, y1, x0, x1 = P["patch"]
    patch = img[y0:y1, x0:x1]
    hp = patch - cv2.GaussianBlur(patch, (0, 0), 2.0 * s)
    target = float(np.median(np.abs(hp - np.median(hp))) * 1.4826)
    rng = np.random.default_rng(P["seed"])
    n1 = cv2.GaussianBlur(rng.normal(0, 1, (H, W)).astype(np.float32), (0, 0), 0.9 * s)
    n2 = cv2.GaussianBlur(rng.normal(0, 1, (H, W)).astype(np.float32), (0, 0), 2.2 * s)
    noise = n1 / n1.std() * 0.9 + n2 / n2.std() * 0.18
    grain = (noise / noise.std() * target)[..., None] * np.ones(3, np.float32)
    print(key, "grain std", round(target, 2))

    a = cv2.GaussianBlur(m.astype(np.float32) / 255, (0, 0), 7 * s)[..., None]
    out = img * (1 - a) + (low + grain) * a
    cv2.imwrite(str(EP / f"lam_ep3_{key}_faceless.png"), np.clip(out, 0, 255).astype(np.uint8))
    cx, cy = P["c"]; r = int(260 * max(1, s * 0.75))
    crop = np.hstack([img[cy - r:cy + r, cx - r:cx + r], out[cy - r:cy + r, cx - r:cx + r]])
    cv2.imwrite(str(EP / "_build" / f"faceless_check_{key}.jpg"), np.clip(cv2.resize(crop, (1040, 520)), 0, 255).astype(np.uint8))


PLATES["C"] = dict(PLATES["A"], src="az2_start.jpg", seed=13,      # Azarjashn v2 still (same pose/face position as A)
                   mouth=((532, 902), (560, 913), (590, 917), (620, 913), (650, 902)))

PLATES["D"] = dict(src="az2_end_start.png", s=1.3,                   # Azarjashn v2 end pose (clip @4.25 s, candle lit)
                   eyes=(((485, 720), (88, 90)), ((653, 722), (88, 90))),
                   brows=(((405, 615), (440, 585), (480, 572), (520, 575), (542, 588)),
                          ((575, 562), (610, 552), (650, 555), (690, 570), (715, 592))),
                   mouth=((518, 868), (545, 860), (575, 862), (605, 862), (630, 872)),
                   box=(380, 470, 760, 1000), c=(580, 740), sc=(190, 260), patch=(880, 940, 420, 480), seed=17)

import sys
for k, P in PLATES.items():
    if len(sys.argv) > 1 and k not in sys.argv[1:]:
        continue
    run(k, P)
print("ok")
