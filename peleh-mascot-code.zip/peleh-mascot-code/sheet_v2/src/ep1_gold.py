﻿"""Ep1: step-1 (face wall) gold light-up on R3a, face kit on top; still + 2.4 s test clip with ding."""
from pathlib import Path
import subprocess
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
from gold_step import light_up_frame, ding_wav, DUR, FPS

ROOT = Path(__file__).resolve().parents[1]
EP = ROOT.parent / "ep1"
base = cv2.imread(str(ROOT.parent / "renders_vahid" / "R3a.jpg"))[:, :, ::-1].astype(np.float32)
H, W = base.shape[:2]
P1 = [(480, 618), (496, 598), (688, 576), (698, 584), (826, 606), (832, 732), (700, 740), (700, 1010), (478, 1010)]
m = np.zeros((H, W), np.uint8); cv2.fillPoly(m, [np.array(P1, np.int32)], 255)
cv2.circle(m, (662, 802), 64, 255, -1)          # whole right-eye lid goes gold (the eye overlaps the step-2 column)
y = np.arange(H, dtype=np.float32)[:, None]
m = cv2.GaussianBlur(m.astype(np.float32) / 255, (0, 0), 1.0) * np.clip((1010 - y) / 90, 0, 1)
cv2.imwrite(str(EP / "rig_face" / "body_step1_mask_R3a.png"), (m * 255).astype(np.uint8))
body = cv2.GaussianBlur(cv2.fillPoly(np.zeros((H, W), np.uint8), [np.array([(455, 600), (700, 565), (1060, 930), (1060, 1180), (455, 1180)], np.int32)], 255).astype(np.float32) / 255, (0, 0), 8)


def over(img, p):
    lay = np.asarray(Image.open(p)).astype(np.float32)
    a = lay[..., 3:] / 255
    return img * (1 - a) + lay[..., :3] * a


eyesE10 = EP / "rig_face" / "face_R3a_E10_satisfied_nomouth.png"
eyesE01 = EP / "rig_face" / "face_R3a_E01_hook_nomouth.png"
smirk = EP / "rig_mouth" / "mouth_R3a_smirk_wide_rest.png"
rest = EP / "rig_mouth" / "mouth_R3a_X_rest_neutral.png"
faced = over(over(base, eyesE10), smirk)
lit = light_up_frame(faced, m, body, 1.2, G=160, ground_y=1700)
Image.fromarray(lit.astype(np.uint8)).save(EP / "frames" / "lam_ep1_R3a_E10_step1_gold.png")
fr = EP / "_g"; fr.mkdir(exist_ok=True)
pre, hold = 0.5, 1.3
N = int((pre + DUR + hold) * FPS)
for i in range(N):
    t = i / FPS - pre
    img = over(over(base, eyesE01 if t < 0.3 else eyesE10), rest if t < 0.3 else smirk)
    img = img if t < 0 else light_up_frame(img, m, body, t, G=160, ground_y=1700)
    img = cv2.resize(img.astype(np.uint8), (1080, 1620), interpolation=cv2.INTER_AREA)
    cv2.imwrite(str(fr / f"{i:04d}.png"), img[:, :, ::-1])
ding_wav(EP / "_ding.wav", at=pre + 0.15 * DUR, total=N / FPS)
ff = imageio_ffmpeg.get_ffmpeg_exe()
subprocess.run([ff, "-y", "-framerate", str(FPS), "-i", str(fr / "%04d.png"), "-i", str(EP / "_ding.wav"), "-c:v", "libx264",
                "-pix_fmt", "yuv420p", "-crf", "18", "-c:a", "aac", "-b:a", "160k", "-shortest", str(EP / "lam_ep1_step1_gold_test.mp4")],
               check=True, capture_output=True)
for p in fr.glob("*.png"):
    p.unlink()
fr.rmdir(); (EP / "_ding.wav").unlink()
print("ok")
