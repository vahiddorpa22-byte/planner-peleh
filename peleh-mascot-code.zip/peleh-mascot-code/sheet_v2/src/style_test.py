﻿"""Style-match test: remove the painted face from the bean-bag render and put the vector kit on it."""
from pathlib import Path
import numpy as np, cv2
from PIL import Image, ImageFilter
import lam_facekit as K
from render_util import html_to_png

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT.parent / "ref" / "lam_beanbag_square_profile.jpg"
OUT = ROOT / "style_test"
OUT.mkdir(exist_ok=True)

img = cv2.imread(str(REF))[:, :, ::-1].astype(np.float32)
H, W = img.shape[:2]

# ---- 1. feature mask (hand-placed from measured geometry, see report)
mask = np.zeros((H, W), np.uint8)
cv2.circle(mask, (458, 398), 72, 255, -1)
cv2.circle(mask, (577, 399), 74, 255, -1)
cv2.ellipse(mask, (452, 316), (72, 29), -2, 0, 360, 255, -1)
cv2.ellipse(mask, (578, 315), (70, 24), -3, 0, 360, 255, -1)
cv2.ellipse(mask, (522, 476), (64, 34), -8, 0, 360, 255, -1)
mask[:, :397] = 0                     # keep the hand on the cheek untouched
mask = cv2.dilate(mask, np.ones((5, 5), np.uint8))

# ---- 2. smooth shading: boundary-driven inpaint at 1/4 res (no overshoot), then blur inside the hole
small = cv2.resize(img, (W // 4, H // 4), interpolation=cv2.INTER_AREA)
msmall = cv2.resize(mask, (W // 4, H // 4), interpolation=cv2.INTER_NEAREST)
msmall = cv2.dilate(msmall, np.ones((3, 3), np.uint8))
inp = cv2.inpaint(np.clip(small, 0, 255).astype(np.uint8), msmall, 6, cv2.INPAINT_TELEA).astype(np.float32)
inp = cv2.GaussianBlur(inp, (0, 0), 2.5)
fill = cv2.resize(inp, (W, H), interpolation=cv2.INTER_CUBIC)
fill = cv2.GaussianBlur(fill, (0, 0), 6)
# ---- 3. clay micro-texture from a clean patch of the same surface
patch = img[505:570, 415:575]
hp = patch - cv2.GaussianBlur(patch, (0, 0), 4)
rng = np.random.default_rng(7)
tex = np.zeros_like(img)
ph, pw = hp.shape[:2]
for y in range(0, H, ph):
    for x in range(0, W, pw):
        t = hp[:, ::-1] if rng.random() > .5 else hp
        tex[y:y + ph, x:x + pw] = t[:min(ph, H - y), :min(pw, W - x)]
fill += tex * 0.9

m = cv2.GaussianBlur(mask.astype(np.float32) / 255, (0, 0), 4)[..., None]
clean = img * (1 - m) + fill * m
clean_u8 = np.clip(clean, 0, 255).astype(np.uint8)
Image.fromarray(clean_u8).save(OUT / "beanbag_face_removed.png")

# ---- 4. render vector faces at render geometry
Rr = 55.0
GEO = dict(eyeL=(458 / Rr, 397 / Rr), eyeR=(577 / Rr, 398 / Rr), browL=(452 / Rr, 320 / Rr), browR=(580 / Rr, 316 / Rr),
           mouthc=(521 / Rr, 484 / Rr), mscale=1.12, eyeRscale=1.03)


def face_layer(ex, mouth_override=None, name="x"):
    saved = K.EXPR[ex]["mouth"]
    if mouth_override:
        K.EXPR[ex]["mouth"] = mouth_override
    inner = K.face(Rr, ex, **GEO)
    K.EXPR[ex]["mouth"] = saved
    svg = K.svg_doc(inner, W, H, (0, 0, W, H))
    p = OUT / f"_layer_{name}.png"
    html_to_png("<!doctype html><style>html,body{margin:0;background:transparent}</style>" + svg, p, W, H)
    return Image.open(p).convert("RGBA")


def grade(layer):
    """Match the scene: the render is darker/warmer than the neutral kit (key light + JPEG softness)."""
    a = np.asarray(layer).astype(np.float32)
    rgb = a[..., :3]
    rgb *= np.array([0.90, 0.86, 0.80])          # warm, darker scene exposure (eye white #DACAB1 in render)
    rgb = cv2.GaussianBlur(rgb, (0, 0), 0.6)
    noise = rng.normal(0, 2.0, rgb.shape[:2])[..., None]
    rgb = np.clip(rgb + noise, 0, 255)
    a[..., :3] = rgb
    a[..., 3] = cv2.GaussianBlur(a[..., 3], (0, 0), 0.5)
    return Image.fromarray(a.astype(np.uint8), "RGBA")


base = Image.fromarray(clean_u8).convert("RGBA")
tests = [("E01", None, "expr_E01"), ("E03", None, "expr_E03"), ("E04", None, "expr_E04"),
         ("E01", ("D_AA", False), "mouth_D_AA"), ("E01", ("E_O", False), "mouth_E_O"), ("E01", ("G_FV", False), "mouth_G_FV")]
for ex, mo, name in tests:
    lay = grade(face_layer(ex, mo, name))
    out = base.copy()
    out.alpha_composite(lay)
    out.convert("RGB").save(OUT / f"test_{name}.png")
for p in OUT.glob("_layer_*.png"):
    p.unlink()
print("ok")
