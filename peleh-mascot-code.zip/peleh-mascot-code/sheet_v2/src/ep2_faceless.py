"""Remove the baked face (eyes, lids, brows, mouth) from Vahid's ep2 still so the face kit can be drawn on clean clay.
Low-frequency colour comes from an inpaint at quarter scale (smooth lighting gradient, incl. the phone glow);
high-frequency clay grain is borrowed from a clean forehead patch and blended in with a feathered mask.
Output: ep2/lam_ep2_faceless.png (+ ep2/_build/faceless_check.jpg)
"""
from pathlib import Path
import numpy as np, cv2

EP = Path(__file__).resolve().parents[2] / "ep2"
(EP / "_build").mkdir(exist_ok=True)
img = cv2.imread(str(EP / "lam_ep2_start.jpg")).astype(np.float32)
H, W = img.shape[:2]

m = np.zeros((H, W), np.uint8)
for c in ((452, 833), (552, 835)):                          # eyes incl. lid rim + contact shadow
    cv2.ellipse(m, c, (52, 61), 0, 0, 360, 255, -1)
for pts, th in ((((399, 773), (430, 760), (455, 756), (480, 757), (500, 761)), 26),      # viewer-left brow
                (((500, 748), (520, 739), (545, 735), (570, 740), (597, 762)), 26),      # viewer-right brow
                (((476, 911), (500, 905), (520, 903), (538, 905)), 16)):                 # mouth
    cv2.polylines(m, [np.array(pts, np.int32)], False, 255, th, cv2.LINE_AA)
m = cv2.dilate(m, np.ones((9, 9), np.uint8))

# low frequency: inpaint at 1/4 scale, upsample (no smear of the 3D eye shading)
q = 4
small = cv2.resize(img, (W // q, H // q), interpolation=cv2.INTER_AREA).astype(np.uint8)
ms = cv2.resize(m, (W // q, H // q), interpolation=cv2.INTER_NEAREST)
ms = cv2.dilate(ms, np.ones((3, 3), np.uint8))
low = cv2.inpaint(small, ms, 6, cv2.INPAINT_TELEA).astype(np.float32)
low = cv2.resize(low, (W, H), interpolation=cv2.INTER_CUBIC)
low = cv2.GaussianBlur(low, (0, 0), 6)
# better low frequency on the flat face plane: smooth cubic surface fitted to clean clay around the features
FX0, FX1, FY0, FY1 = 400, 600, 680, 985
yy, xx = np.mgrid[FY0:FY1, FX0:FX1]
clean = cv2.dilate(m, np.ones((15, 15), np.uint8))[FY0:FY1, FX0:FX1] == 0
u = (xx - 500) / 100.0; v = (yy - 830) / 140.0
def basis(u, v):
    return np.stack([np.ones_like(u), u, v, u * u, u * v, v * v, u ** 3, u * u * v, u * v * v, v ** 3], -1)
A = basis(u[clean], v[clean])
smooth = cv2.GaussianBlur(img, (0, 0), 2.5)[FY0:FY1, FX0:FX1]
surf = np.zeros_like(smooth)
for ch in range(3):
    coef, *_ = np.linalg.lstsq(A, smooth[..., ch][clean], rcond=None)
    surf[..., ch] = basis(u, v) @ coef
# feather the fitted surface into the inpaint toward the box edges (no visible rectangle)
wy = np.clip(np.minimum(yy - FY0, FY1 - 1 - yy) / 25.0, 0, 1)
wx = np.clip(np.minimum(xx - FX0, FX1 - 1 - xx) / 12.0, 0, 1)
wb = (wy * wx)[..., None]
low[FY0:FY1, FX0:FX1] = low[FY0:FY1, FX0:FX1] * (1 - wb) + surf * wb

# high frequency: procedural clay grain matched to the real grain strength of a clean cheek patch
patch = img[930:990, 560:640]
hp = patch - cv2.GaussianBlur(patch, (0, 0), 2.0)
target = float(np.median(np.abs(hp - np.median(hp))) * 1.4826)          # robust std (ignores the odd speck)
rng = np.random.default_rng(7)
n1 = cv2.GaussianBlur(rng.normal(0, 1, (H, W)).astype(np.float32), (0, 0), 0.9)
n2 = cv2.GaussianBlur(rng.normal(0, 1, (H, W)).astype(np.float32), (0, 0), 2.2)
noise = n1 / n1.std() * 0.9 + n2 / n2.std() * 0.18
grain = (noise / noise.std() * target)[..., None] * np.array([1.0, 1.0, 1.0], np.float32)
specks = (rng.random((H, W)) > 0.99975).astype(np.float32)
grain += cv2.GaussianBlur(specks, (0, 0), 0.7)[..., None] * 90       # sparse pale specks like the render
print("grain std", round(target, 2))

fill = low + grain
a = cv2.GaussianBlur(m.astype(np.float32) / 255, (0, 0), 7)[..., None]
out = img * (1 - a) + fill * a
cv2.imwrite(str(EP / "lam_ep2_faceless.png"), np.clip(out, 0, 255).astype(np.uint8))
crop = np.hstack([img[620:1020, 340:760], out[620:1020, 340:760]])
cv2.imwrite(str(EP / "_build" / "faceless_check.jpg"), np.clip(cv2.resize(crop, None, fx=1.5, fy=1.5), 0, 255).astype(np.uint8))
print("ok", W, H)
