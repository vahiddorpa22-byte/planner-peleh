"""Trial «لَم و ۷ تا کتاب»: faceless talking plates from Vahid's Flow clip (419192a7).
A = clip @0.00 s (holding the stack) · B = clip @7.16 s (holding the pink book). Same method as ep3/ep4_faceless.py.
"""
import sys
import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location("f4", Path(__file__).with_name("ep4_faceless.py"))
# reuse the run() of ep4_faceless without executing its plate loop: load source, strip the loop
src = Path(spec.origin).read_text(encoding="utf-8").split("\nfor k, P in PLATES.items():")[0]
ns = {"__file__": str(Path(__file__))}
exec(compile(src, "ep4_faceless_core", "exec"), ns)
ns["EP"] = Path(__file__).resolve().parents[2] / "trial_books"
(ns["EP"] / "_build").mkdir(exist_ok=True)

PLATES = {
    "A": dict(src="tb_A_start.png", s=1.25,
              eyes=(((555, 779), (75, 75)), ((681, 779), (75, 75))),
              brows=(((503, 672), (522, 652), (545, 638), (574, 632), (604, 636)),
                     ((629, 631), (652, 628), (675, 629), (705, 640), (730, 660))),
              mouth=((585, 876), (603, 885), (621, 888), (639, 885), (657, 876)),
              box=(462, 600, 742, 935), c=(600, 770), sc=(140, 170), patch=(902, 932, 505, 575), seed=31),
    "B": dict(src="tb_B_start.png", s=1.7,
              eyes=(((556, 707), (114, 110)), ((744, 707), (114, 110))),
              brows=(((475, 585), (505, 565), (535, 551), (585, 545), (636, 546)),
                     ((655, 534), (687, 533), (719, 537), (775, 553), (829, 580))),
              mouth=((618, 855), (635, 846), (652, 843), (669, 846), (688, 856)),
              box=(440, 500, 838, 925), c=(645, 710), sc=(200, 220), patch=(878, 914, 450, 510), seed=33),
}
run = ns["run"]
for k, P in PLATES.items():
    if len(sys.argv) > 1 and k not in sys.argv[1:]:
        continue
    run(k, P)
