﻿"""Work on Vahid's new renders (R1, R3a, R3b, R4):
1) sneaker gold colour-correction to #C9A227, 2) vector face kit on the faceless bodies (style test),
3) gold-step effect on R1 (+ demo MP4 with face), 4) measured proportions (printed for the grid page)."""
from pathlib import Path
import copy, json, subprocess
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
import lam_facekit as K
from render_util import html_to_png
from gold_step import light_up_frame, ding_wav, DUR, FPS

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT.parent / "renders_vahid"
OUT = ROOT / "renders_cc"
ST = ROOT / "style_test"
FX = ROOT / "fx"
for d in (OUT, ST, FX):
    d.mkdir(exist_ok=True)
NAMES = {"R1": "lam_r_front_noface_01_v1", "R2": "lam_r_34_noface_01_v1", "R3a": "lam_r_beanbag_book_noface_01_v1",
         "R3b": "lam_r_beanbag_phone_noface_01_v1", "R3c": "lam_r_beanbag_notebook_noface_01_v1", "R4": "lam_r_room_empty_01_v1"}


# ------------------------------------------------------------------ 1. sneaker colour correction
def gold_correct(bgr, strength=1.0):
    """Pull yellow/gold pixels (sneaker panels) to the palette gold #C9A227 (H~46deg, S~0.81, V~0.79)."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV).astype(np.float32)
    h, s, v = hsv[..., 0] * 2, hsv[..., 1] / 255, hsv[..., 2] / 255
    m = np.clip(1 - np.abs(h - 50) / 14, 0, 1) * np.clip((s - 0.28) / 0.2, 0, 1) * np.clip((v - 0.25) / 0.2, 0, 1)
    m = cv2.GaussianBlur(m, (0, 0), 1.2) * strength
    th, ts = 46.0, 0.80
    nh = h * (1 - m) + th * m
    ns = s * (1 - m) + np.clip(s * 0.4 + ts * 0.6, 0, 1) * m
    nv = v * (1 - m * 0.16)                      # lemon -> muted: a touch darker
    out = np.stack([nh / 2, ns * 255, nv * 255], -1).clip(0, 255).astype(np.uint8)
    return cv2.cvtColor(out, cv2.COLOR_HSV2BGR), m


def mean_hex(bgr, m):
    sel = bgr[m > 0.6]
    if not len(sel):
        return None
    b, g, r = np.median(sel, 0).astype(int)
    return f"#{r:02X}{g:02X}{b:02X}"


cc = {}
report = {}
for k, n in NAMES.items():
    im = cv2.imread(str(SRC / f"{k}.jpg"))
    fixed, m = gold_correct(im)
    if k not in ("R1", "R2"):           # only R1/R2 are lemon-yellow; the others already sit near #C9A227
        report[k] = {"gold_measured": mean_hex(im, m)}
        cv2.imwrite(str(OUT / f"{n}_cc.png"), im); cc[k] = im[:, :, ::-1].astype(np.float32)
        continue
    report[k] = {"gold_before": mean_hex(im, m), "gold_after": mean_hex(fixed, m)}
    cv2.imwrite(str(OUT / f"{n}_cc.png"), fixed)
    cc[k] = fixed[:, :, ::-1].astype(np.float32)
print("gold", report)

# ------------------------------------------------------------------ 2. faces on the renders
# Placement chosen on each render's step-1 block (eyes may overlap step 2 only below its top), pixels.
GEO = {
    "R1": dict(R=80, eyeL=(345, 640), eyeR=(515, 640), browL=(340, 524), browR=(508, 528), mouth=(462, 768), ms=1.18),
    "R3a": dict(R=56, eyeL=(545, 800), eyeR=(662, 802), browL=(541, 714), browR=(654, 717), mouth=(612, 886), ms=1.15),
    "R3c": dict(R=90, eyeL=(389, 660), eyeR=(589, 660), browL=(384, 528), browR=(590, 530), mouth=(500, 792), ms=1.2),
    "R3b": dict(R=58, eyeL=(535, 745), eyeR=(655, 747), browL=(531, 656), browR=(648, 659), mouth=(600, 836), ms=1.15),
}
GRADE = {"R1": (0.97, 0.95, 0.93), "R3c": (0.84, 0.84, 0.88), "R3a": (0.85, 0.83, 0.86), "R3b": (0.83, 0.82, 0.86)}
NAVY_L = 0.299 * 0x1B + 0.587 * 0x2A + 0.114 * 0x4A


def face_layer(rk, ex, look=None, mouth=None, eyes_from=None):
    g = GEO[rk]
    R = g["R"]
    saved = copy.deepcopy(K.EXPR[ex])
    e = K.EXPR[ex]
    if eyes_from:
        src = K.EXPR[eyes_from]
        e["eyeL"], e["eyeR"], e["browL"], e["browR"] = src["eyeL"], src["eyeR"], src["browL"], src["browR"]
    if look is not None:
        for side in ("eyeL", "eyeR"):
            if e[side] != "happy":
                lst = list(e[side]); lst[3] = look; e[side] = tuple(lst)
    if mouth:
        e["mouth"] = mouth
    u = lambda p: (p[0] / R, p[1] / R)
    inner = K.face(R, ex, eyeL=u(g["eyeL"]), eyeR=u(g["eyeR"]), browL=u(g["browL"]), browR=u(g["browR"]),
                   mouthc=u(g["mouth"]), mscale=g["ms"])
    K.EXPR[ex] = saved
    H, W = cc[rk].shape[:2]
    p = ST / f"_lay.png"
    html_to_png("<!doctype html><style>html,body{margin:0;background:transparent}</style>" + K.svg_doc(inner, W, H, (0, 0, W, H)), p, W, H)
    lay = np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)
    p.unlink()
    return lay


def composite(rk, lay):
    base = cc[rk]
    rgb, a = lay[..., :3].copy(), lay[..., 3:] / 255
    local = cv2.GaussianBlur(base, (0, 0), 22)
    lum = rgb @ np.array([0.299, 0.587, 0.114])
    navyish = ((rgb[..., 2] > rgb[..., 0] + 8) & (lum < 150)).astype(np.float32)
    navyish = cv2.GaussianBlur(navyish, (0, 0), 0.8)[..., None]
    ratio = np.clip(lum / NAVY_L, 0.45, 1.30)[..., None]
    lids = np.clip(local * ratio, 0, 255)                 # lids / lip rims take the body's local colour
    rgb = rgb * (1 - navyish) + lids * navyish
    rgb = rgb * np.array(GRADE[rk])
    rgb = cv2.GaussianBlur(rgb, (0, 0), 0.7)
    rgb += np.random.default_rng(1).normal(0, 2.2, rgb.shape[:2])[..., None]
    a = cv2.GaussianBlur(a[..., 0], (0, 0), 0.6)[..., None]
    return np.clip(base * (1 - a) + rgb * a, 0, 255)


TESTS = [
    ("R3a", "E01", (-0.28, 0.30), None, None, "R3a_E01_reading"),
    ("R3a", "E03", None, None, None, "R3a_E03_curious"),
    ("R3a", "E04", None, None, None, "R3a_E04_excited"),
    ("R3a", "E08", (-0.25, 0.25), ("D_AA", False), None, "R3a_mouth_D_AA"),
    ("R3a", "E08", (-0.25, 0.25), ("E_O", False), None, "R3a_mouth_E_O"),
    ("R3a", "E08", (-0.25, 0.25), ("G_FV", False), None, "R3a_mouth_G_FV"),
    ("R3b", "E05", (0.32, 0.34), None, None, "R3b_E05_phone"),
    ("R3b", "E02", (0.25, 0.35), None, None, "R3b_E02_tired"),
    ("R3b", "E06", None, None, None, "R3b_E06_caught"),
    ("R3c", "E01", None, None, None, "R3c_E01"),
    ("R3c", "E09", (0.05, 0.38), None, None, "R3c_E09_planning"),
    ("R3c", "E04", None, None, None, "R3c_E04"),
    ("R3c", "E10", None, None, None, "R3c_E10"),
    ("R1", "E01", None, None, None, "R1_E01"),
    ("R1", "E04", None, None, None, "R1_E04"),
    ("R1", "E10", None, None, None, "R1_E10"),
]
layers = {}
for rk, ex, look, mo, ef, name in TESTS:
    lay = face_layer(rk, ex, look, mo, ef)
    layers[(rk, ex)] = lay
    out = composite(rk, lay)
    Image.fromarray(out.astype(np.uint8)).save(ST / f"vr_{name}.png")
print("faces ok")
json.dump({k: v for k, v in GEO.items()}, open(ST / "face_placement_px.json", "w"), indent=1)

# ------------------------------------------------------------------ 3. gold step (R1 + R3c)
POLYS = {
  "R1": {1: [(247, 365), (520, 288), (660, 310), (680, 495), (545, 500), (545, 1300), (250, 1300)],
         2: [(545, 500), (700, 497), (740, 500), (855, 520), (860, 712), (740, 718), (740, 1306), (545, 1304)],
         3: [(740, 718), (930, 710), (1040, 725), (1045, 948), (935, 955), (935, 1310), (740, 1308)],
         4: [(935, 955), (1050, 945), (1130, 965), (1100, 1010), (1092, 1300), (1040, 1316), (935, 1312)]},
  "R3c": {1: [(243, 375), (258, 360), (720, 360), (735, 375), (735, 1260), (243, 1260)],
          2: [(735, 590), (895, 590), (905, 605), (905, 1260), (735, 1260)],
          3: [(905, 780), (1005, 780), (1015, 795), (1015, 1260), (905, 1260)],
          4: [(1015, 950), (1128, 950), (1140, 965), (1138, 1050), (1120, 1260), (1015, 1260)]},
}
GPX = {"R1": 215.0, "R3c": 197.0}
FADE = {"R1": (5000, 5001), "R3c": (1150, 1262)}
ff = imageio_ffmpeg.get_ffmpeg_exe()
(FX / "masks").mkdir(exist_ok=True)


def with_face(img, lay):
    a = lay[..., 3:] / 255
    return img * (1 - a) + lay[..., :3] * a


def run_fx(rk, exprs=("E01", "E04", "E10")):
    base = cc[rk]
    H, W = base.shape[:2]
    yy = np.arange(H, dtype=np.float32)[:, None]
    fade = np.clip((FADE[rk][1] - yy) / (FADE[rk][1] - FADE[rk][0]), 0, 1)
    msk = {}
    for k, pts in POLYS[rk].items():
        m = np.zeros((H, W), np.uint8); cv2.fillPoly(m, [np.array(pts, np.int32)], 255)
        msk[k] = cv2.GaussianBlur(m.astype(np.float32) / 255, (0, 0), 1.0) * fade
        cv2.imwrite(str(FX / "masks" / f"body_step{k}_mask_{rk}.png"), (msk[k] * 255).astype(np.uint8))
    body = np.clip(sum(msk.values()), 0, 1)
    ov = base.copy()
    cols = {1: (231, 76, 60), 2: (46, 204, 113), 3: (52, 152, 219), 4: (241, 196, 15)}
    for k, m in msk.items():
        ov = ov * (1 - .45 * m[..., None]) + np.array(cols[k]) * .45 * m[..., None]
    Image.fromarray(ov.astype(np.uint8)).save(FX / f"step_masks_overlay_{rk}.png")
    G = GPX[rk]
    faceL = {}
    for ex in exprs:
        lay = layers[(rk, ex)]
        comp = composite(rk, lay)
        a = cv2.GaussianBlur(lay[..., 3], (0, 0), 0.6)[..., None]
        faceL[ex] = np.dstack([comp, a])
    for k in msk:
        f = light_up_frame(base, msk[k], body, 1.2, G=G, ground_y=1800)
        Image.fromarray(with_face(f, faceL["E10"]).astype(np.uint8)).save(FX / f"gold_step{k}_lit_{rk}.png")
    fr = FX / "_frames"; fr.mkdir(exist_ok=True)
    pre, hold = 0.7, 1.9
    N = int((pre + DUR + hold) * FPS)
    for i in range(N):
        t = i / FPS - pre
        img = base if t < 0 else light_up_frame(base, msk[4], body, t, G=G, ground_y=1800)
        ex = "E01" if t < 0.25 else ("E04" if t < 1.5 else "E10")
        img = with_face(img, faceL[ex])
        small = cv2.resize(img.astype(np.uint8), (1080, 1620), interpolation=cv2.INTER_AREA)
        canvas = np.full((1920, 1080, 3), np.array([0x14, 0x1F, 0x38]), np.uint8)
        canvas[150:1770] = small
        cv2.imwrite(str(fr / f"{i:04d}.png"), canvas[:, :, ::-1])
        if 0 <= t < DUR and i % 3 == 0:
            cv2.imwrite(str(FX / f"_strip_{rk}_{i:04d}.png"), small[:, :, ::-1])
    ding_wav(FX / f"_ding_{rk}.wav", at=pre + 0.15 * DUR, total=N / FPS)
    subprocess.run([ff, "-y", "-framerate", str(FPS), "-i", str(fr / "%04d.png"), "-i", str(FX / f"_ding_{rk}.wav"),
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-c:a", "aac", "-b:a", "160k", "-shortest",
                    str(FX / f"lam_fx_gold_step4_{rk}_demo_v1.mp4")], check=True, capture_output=True)
    for p in fr.glob("*.png"):
        p.unlink()
    fr.rmdir()


for rk in ("R3c", "R1"):
    run_fx(rk)
print("fx ok")