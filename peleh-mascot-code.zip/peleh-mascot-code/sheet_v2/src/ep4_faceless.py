"""Lam ep4 «زمستون»: remove the baked face from the two talking plates (same method as ep3_faceless.py).
A = Flow clip db497413 @2.9 s (eyes open, arms out) · B = same clip @7.2 s (reading, no page in front of the mouth).
Both 720x1280 frames upscaled to 1116x2000. Output: ep4/lam_ep4_{A,B}_faceless.png + _build/faceless_check_*.jpg
"""
from pathlib import Path
import sys
import numpy as np, cv2

EP = Path(__file__).resolve().parents[2] / "ep4"
(EP / "_build").mkdir(exist_ok=True)

PLATES = {
    "A": dict(src="lam_ep4_A2_start.png", s=1.15,
              eyes=(((492, 860), (58, 56)), ((600, 861), (58, 56))),
              brows=(((437, 795), (465, 778), (494, 768), (518, 772), (540, 783)),
                     ((545, 783), (568, 772), (593, 770), (617, 778), (640, 792))),
              mouth=((505, 929), (527, 942), (549, 947), (571, 942), (591, 933)),
              box=(408, 715, 655, 1000), c=(530, 860), sc=(125, 145), patch=(950, 990, 420, 470), seed=21),
    "B": dict(src="lam_ep4_B_start.png", s=1.7,
              eyes=(((449, 862), (108, 102)), ((625, 866), (106, 102))),
              brows=(((348, 726), (390, 707), (434, 696), (478, 703), (523, 724)),
                     ((531, 707), (573, 693), (614, 690), (655, 704), (695, 735))),
              mouth=((472, 964), (505, 978), (539, 984), (573, 978), (608, 970)),
              box=(318, 640, 702, 1085), c=(510, 860), sc=(195, 225), patch=(1000, 1060, 330, 400), seed=23),
}


def run(key, P):
    img = cv2.imread(str(EP / P["src"])).astype(np.float32)
    H, W = img.shape[:2]
    s = P["s"]
    m = np.zeros((H, W), np.uint8)
    for c, ax in P["eyes"]:
        cv2.ellipse(m, c, ax, 0, 0, 360, 255, -1)
    for pts in P["brows"]:
        cv2.polylines(m, [np.array(pts, np.int32)], False, 255, int(26 * s), cv2.LINE_AA)
    cv2.polylines(m, [np.array(P["mouth"], np.int32)], False, 255, int(16 * s * 1.4), cv2.LINE_AA)
    m = cv2.dilate(m, np.ones((int(9 * s) | 1, int(9 * s) | 1), np.uint8))

    q = 4
    small = cv2.resize(img, (W // q, H // q), interpolation=cv2.INTER_AREA).astype(np.uint8)
    ms = cv2.dilate(cv2.resize(m, (W // q, H // q), interpolation=cv2.INTER_NEAREST), np.ones((3, 3), np.uint8))
    low = cv2.inpaint(small, ms, 6, cv2.INPAINT_TELEA).astype(np.float32)
    low = cv2.GaussianBlur(cv2.resize(low, (W, H), interpolation=cv2.INTER_CUBIC), (0, 0), 6)

    FX0, FY0, FX1, FY1 = P["box"]
    yy, xx = np.mgrid[FY0:FY1, FX0:FX1]
    clean = cv2.dilate(m, np.ones((15, 15), np.uint8))[FY0:FY1, FX0:FX1] == 0
    u = (xx - P["c"][0]) / P["sc"][0]; v = (yy - P["c"][1]) / P["sc"][1]

    def basis(u, v):
        return np.stack([np.ones_like(u), u, v, u * u, u * v, v * v, u ** 3, u * u * v, u * v * v, v ** 3], -1)

    A = basis(u[clean], v[clean])
    smooth = cv2.GaussianBlur(img, (0, 0), 2.5)[FY0:FY1, FX0:FX1]
    surf = np.zeros_like(smooth)
    for ch in range(3):
        coef, *_ = np.linalg.lstsq(A, smooth[..., ch][clean], rcond=None)
        surf[..., ch] = basis(u, v) @ coef
    wy = np.clip(np.minimum(yy - FY0, FY1 - 1 - yy) / 25.0, 0, 1)
    wx = np.clip(np.minimum(xx - FX0, FX1 - 1 - xx) / 12.0, 0, 1)
    wb = (wy * wx)[..., None]
    low[FY0:FY1, FX0:FX1] = low[FY0:FY1, FX0:FX1] * (1 - wb) + surf * wb

    y0, y1, x0, x1 = P["patch"]
    patch = img[y0:y1, x0:x1]
    hp = patch - cv2.GaussianBlur(patch, (0, 0), 2.0 * s)
    target = float(np.median(np.abs(hp - np.median(hp))) * 1.4826)
    rng = np.random.default_rng(P["seed"])
    n1 = cv2.GaussianBlur(rng.normal(0, 1, (H, W)).astype(np.float32), (0, 0), 0.9 * s)
    n2 = cv2.GaussianBlur(rng.normal(0, 1, (H, W)).astype(np.float32), (0, 0), 2.2 * s)
    noise = n1 / n1.std() * 0.9 + n2 / n2.std() * 0.18
    grain = (noise / noise.std() * target)[..., None] * np.ones(3, np.float32)

    a = cv2.GaussianBlur(m.astype(np.float32) / 255, (0, 0), 7 * s)[..., None]
    out = img * (1 - a) + (low + grain) * a
    cv2.imwrite(str(EP / f"lam_ep4_{key}_faceless.png"), np.clip(out, 0, 255).astype(np.uint8))
    cx, cy = P["c"]; r = int(260 * max(1, s * 0.75))
    crop = np.hstack([img[cy - r:cy + r, cx - r:cx + r], out[cy - r:cy + r, cx - r:cx + r]])
    cv2.imwrite(str(EP / "_build" / f"faceless_check_{key}.jpg"), np.clip(cv2.resize(crop, (1040, 520)), 0, 255).astype(np.uint8))
    print(key, "ok")


for k, P in PLATES.items():
    if len(sys.argv) > 1 and k not in sys.argv[1:]:
        continue
    run(k, P)
