"""«بهانه‌های لَم» episode 2 «وقت ندارم» — v2 with the full Lam face kit (2026-11-11).
v1 had no lip-sync (Vahid: not acceptable). v2:
  * Vahid's still with its baked face removed (ep2_faceless.py) → the face kit draws eyes, lids, brows and mouth.
  * Phoneme-timed lip-sync: every Persian sound of Lam's two lines placed by hand on a 10 ms energy map of the
    recording (Danesh), mapped to the kit's 10 visemes (M/B/P closed, F/V, teeth S/SH/T/D, L/N/R, open آ, a/e,
    wide ی, round او), with 2-frame minimum holds and soft co-articulation.
  * Acting: bored eyes on the phone → one sarcastic brow on «ندارم» → caught/sheepish while Peleh asks → eyes
    shut on the sigh → looks away, defensive smirk on «اونا حساب نیست», brow pop on «نیست». Natural blinks.
  * Halo pulse while Peleh speaks (same language as ep1). Lam never speaks over the Flow clip (its face is baked);
    the clip carries the action under Peleh's last line and the reading payoff.
Output: ep2/lam_ep2_final.mp4 (+ _upload), check_sheet_ep2.jpg, frame0_lam_ep2.jpg, lam_ep2_timeline.json
"""
from pathlib import Path
import copy, json, subprocess, wave
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
import lam_facekit as K
from render_util import html_to_png, FONT
from gold_step import ding_wav

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
W0 = MASCOT.parent
EP = MASCOT / "ep2"
B = EP / "_build_v3"
B.mkdir(exist_ok=True)
FF = imageio_ffmpeg.get_ffmpeg_exe()
FPS, SR = 30, 44100
GOLD, CREAM = "#C9A227", "#F3F0E8"
TEMPO = 1.08
TARGET_I = -14.0


# =============================================================== audio
def load(p, sr=SR):
    raw = subprocess.run([FF, "-v", "quiet", "-i", str(p), "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768


def fade(x, ms=15):
    n = int(SR * ms / 1000); x = x.copy()
    x[:n] *= np.linspace(0, 1, n); x[-n:] *= np.linspace(1, 0, n)
    return x


def tempo(y, f):
    out = subprocess.run([FF, "-v", "quiet", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "-", "-af", f"atempo={f}", "-f", "f32le", "-"],
                         input=y.astype(np.float32).tobytes(), capture_output=True).stdout
    return np.frombuffer(out, np.float32).copy()


lam = load(EP / "lam_ep2_lam.mp3")
pel = load(EP / "lam_ep2_peleh.mp3")
ITEMS = [("L1", "L", 0.06, 3.20, 0.05),   # وقتِ کتاب... ندارم.
         ("P1", "P", 0.06, 3.34, 0.06),   # چهل و هفت... دقیقه؟
         ("L2", "L", 4.24, 7.18, 0.08),   # [آه] اونا... حساب نیست.
         ("P2", "P", 3.72, 7.12, 0.06)]   # پونزده دقیقه‌ش... مالِ کتاب.
# v3 (2026-11-12, Vahid: «خیلی مکث داره»): the mid-line pauses (0.45-0.95 s each, measured on a 10 ms energy map at
# peak-32 dB) are cut down to ~0.12 s. Source-time intervals removed per take:
CUTS = {"L1": [(1.46, 2.28)],                    # کتاب ……… ندارم  (breath + 0.53 s silence)
        "P1": [(1.92, 2.24)],                    # چهل و هفت ……… دقیقه
        "L2": [(4.77, 4.89), (5.66, 6.16)],      # [آه] … اونا ……… حساب نیست
        "P2": [(5.81, 6.16)]}                    # پونزده دقیقه‌ش ……… مالِ کتاب
XF = int(0.012 * SR)                             # 12 ms crossfade at each join
segs, t = {}, 0.0
for key, spk, a, b, gap in ITEMS:
    src = lam if spk == "L" else pel
    pieces, p0 = [], a
    for c0, c1 in CUTS.get(key, []) + [(b, b)]:
        pieces.append(src[int(p0 * SR):int(c0 * SR)].copy()); p0 = c1
    y0 = pieces[0]
    for pc in pieces[1:]:
        if len(pc) == 0:
            continue
        r = np.linspace(0, 1, XF, dtype=np.float32)
        y0 = np.concatenate([y0[:-XF], y0[-XF:] * (1 - r) + pc[:XF] * r, pc[XF:]])
    y = fade(tempo(fade(y0), TEMPO))
    t += gap
    segs[key] = (t, t + len(y) / SR, y, spk, a)
    t += len(y) / SR
S_ = lambda k: segs[k][0]
E_ = lambda k: segs[k][1]


def to_out(key, ts):
    """source time of that take → timeline, skipping the cut pauses (a time inside a cut snaps to the join)."""
    rm = 0.0
    for c0, c1 in CUTS.get(key, []):
        if ts >= c1:
            rm += c1 - c0
        elif ts > c0:
            rm += ts - c0
    return segs[key][0] + (ts - segs[key][4] - rm) / TEMPO


TAIL = 2.4
DUR = E_("P2") + TAIL
T_CTA = E_("P2") + 0.35
N = int(round(DUR * FPS)); NS = int(DUR * SR) + SR
lam_tr, pel_tr = np.zeros(NS, np.float32), np.zeros(NS, np.float32)
for key, (a, b, y, spk, _) in segs.items():
    tr = lam_tr if spk == "L" else pel_tr
    i = int(a * SR); tr[i:i + len(y)] += y[:max(0, min(len(y), NS - i))]
print({k: (round(v[0], 2), round(v[1], 2)) for k, v in segs.items()}, "DUR", round(DUR, 2))

# =============================================================== phoneme timing (source seconds, read off the 10 ms energy map)
# viseme per phoneme class: closed M/B/P · F/V · teeth (S SH T D Z CH J) · L/N/R · open آ (aa) · a/e (C_E) · ی (EE_wide) · او (F_OO/E_O)
PH = {
    "L1": [(0.13, "G_FV"), (0.20, "C_E"), (0.33, "C_E"), (0.44, "B_SSH"), (0.50, "C_E"), (0.56, "X"),        # وَ قْ تِ
           (0.58, "C_E"), (0.63, "C_E"), (0.70, "B_SSH"), (0.75, "D_AA"), (1.28, "A_MBP"), (1.40, "X"),     # ک تا ب
           (2.36, "H_L"), (2.52, "C_E"), (2.61, "B_SSH"), (2.67, "D_AA"), (2.81, "H_L"), (2.85, "C_E"),     # ن د ا ر
           (2.97, "A_MBP"), (3.12, "X")],                                                                    # م
    "L2": [(4.36, "E_O"), (4.58, "X"),                                                                       # آه (exhale)
           (4.96, "F_OO"), (5.17, "H_L"), (5.27, "D_AA"), (5.60, "X"),                                       # او نا
           (6.22, "C_E"), (6.36, "B_SSH"), (6.49, "D_AA"), (6.61, "A_MBP"), (6.70, "H_L"),                   # حِ سا ب ن
           (6.76, "EE_wide"), (6.90, "B_SSH"), (6.97, "B_SSH"), (7.06, "X")],                                # ی س ت
}
vis = ["X"] * N
for key, seq in PH.items():
    for (ts, v), nxt in zip(seq, seq[1:] + [(seq[-1][0] + 0.1, "X")]):
        k0, k1 = int(round(to_out(key, ts) * FPS)), int(round(to_out(key, nxt[0]) * FPS))
        for k in range(max(0, k0), min(N, max(k1, k0 + 2))):          # min hold 2 frames
            vis[k] = v
# anticipation: lips start moving 1 frame early (reads more natural on screen)
vis = vis[1:] + ["X"]

# =============================================================== plate + face kit layers (original still space 1116x2000)
plate0 = cv2.imread(str(EP / "lam_ep2_faceless.png"))[:, :, ::-1].astype(np.float32)
H0, W0p = plate0.shape[:2]
G = dict(R=48, eyeL=(452, 830), eyeR=(552, 832), browL=(449, 758), browR=(555, 760), mouth=(507, 906), ms=1.02)
GRADE = np.array((0.86, 0.84, 0.88))
NAVY_L = 0.299 * 0x1B + 0.587 * 0x2A + 0.114 * 0x4A
LOCAL = cv2.GaussianBlur(plate0, (0, 0), 22)

# expressions for this episode (same parameter language as the kit)
K.EXPR["X_bored"] = dict(eyeL=(0.52, -4, 0, (-0.34, 0.30), 1, False), eyeR=(0.52, 4, 0, (-0.34, 0.30), 1, False),
                         browL=("flat", 0.02), browR=("flat", 0.02), mouth=("none", False))
K.EXPR["X_bored_up"] = dict(eyeL=(0.40, -4, 0, (-0.30, 0.26), 1, False), eyeR=(0.30, 4, 0, (-0.30, 0.26), 1, False),
                            browL=("flat", 0.02), browR=("up", -0.02), mouth=("none", False))
K.EXPR["X_caught"] = dict(eyeL=(0.04, 0, 0, (0.18, -0.06), 0.88, False), eyeR=(0.04, 0, 0, (0.18, -0.06), 0.88, False),
                          browL=("worried", -0.02), browR=("worried", -0.02), mouth=("none", False))
K.EXPR["X_caught2"] = dict(eyeL=(0.10, 0, 0, (-0.42, 0.16), 0.88, False), eyeR=(0.10, 0, 0, (-0.42, 0.16), 0.88, False),
                           browL=("worried", 0.02), browR=("worried", 0.02), mouth=("none", False))
K.EXPR["X_defend"] = dict(eyeL=(0.38, -3, 0, (-0.46, 0.06), 1, False), eyeR=(0.38, 3, 0, (-0.46, 0.06), 1, False),
                          browL=("base", 0.04), browR=("up", 0.06), mouth=("none", False))
K.EXPR["X_defend_up"] = dict(eyeL=(0.26, -3, 0, (-0.40, 0.02), 1, False), eyeR=(0.22, 3, 0, (-0.40, 0.02), 1, False),
                             browL=("up", -0.04), browR=("up", -0.06), mouth=("none", False))


def render_svg(inner, name):
    p = B / f"_{name}.png"
    html_to_png("<!doctype html><style>html,body{margin:0;background:transparent}</style>" + K.svg_doc(inner, W0p, H0, (0, 0, W0p, H0)), p, W0p, H0)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def grade(lay, seed=1):
    rgb, a = lay[..., :3].copy(), lay[..., 3]
    lum = rgb @ np.array([0.299, 0.587, 0.114])
    nv = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] + 8) & (lum < 150)).astype(np.float32), (0, 0), 0.8)[..., None]
    ratio = np.clip(lum / NAVY_L, 0.45, 1.30)[..., None]
    rgb = rgb * (1 - nv) + np.clip(LOCAL * ratio, 0, 255) * nv
    rgb = cv2.GaussianBlur(rgb * GRADE, (0, 0), 0.7) + np.random.default_rng(seed).normal(0, 2.0, rgb.shape[:2])[..., None]
    return np.dstack([np.clip(rgb, 0, 255), cv2.GaussianBlur(a, (0, 0), 0.6)])


def face_inner(ex, closed=False):
    saved = copy.deepcopy(K.EXPR[ex]); e = K.EXPR[ex]
    if closed:
        for side in ("eyeL", "eyeR"):
            l = list(e[side]); l[0], l[2] = 0.97, 0.0; e[side] = tuple(l)
    R = G["R"]; u = lambda p: (p[0] / R, p[1] / R)
    inner = K.face(R, ex, eyeL=u(G["eyeL"]), eyeR=u(G["eyeR"]), browL=u(G["browL"]), browR=u(G["browR"]), mouthc=u(G["mouth"]), mscale=G["ms"])
    K.EXPR[ex] = saved
    return inner


S = 1080 / W0p
HS = round(H0 * S)
CROP = (HS - 1920) // 2


def to1080(a):
    a = cv2.resize(a, (1080, HS), interpolation=cv2.INTER_AREA)
    return a[CROP:CROP + 1920]


cache = B / "layers_v2.npz"
EXS = ["X_bored", "X_bored_up", "X_caught", "X_caught2", "X_defend", "X_defend_up"]
if cache.exists():
    L = dict(np.load(cache))
else:
    L = {}
    for ex in EXS:
        L[f"face_{ex}"] = np.clip(to1080(grade(render_svg(face_inner(ex), ex))), 0, 255).astype(np.uint8)
        L[f"blink_{ex}"] = np.clip(to1080(grade(render_svg(face_inner(ex, True), ex + "_b"))), 0, 255).astype(np.uint8)
    R = G["R"]
    for m in K.MOUTHS:
        inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth(R, m, False, G["ms"])}</g>'
        L[f"m_{m}"] = np.clip(to1080(grade(render_svg(inner, "m_" + m), 3)), 0, 255).astype(np.uint8)
    for kind in ("flat_down", "forced", "smirk_wide", "hmm"):
        inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth_for_expr(R, (kind, False), G["ms"])}</g>'
        L[f"rest_{kind}"] = np.clip(to1080(grade(render_svg(inner, "r_" + kind), 3)), 0, 255).astype(np.uint8)
    np.savez(cache, **L)
PLATE = to1080(plate0)


def over(img, rgba, a=1.0):
    rgba = rgba.astype(np.float32); al = rgba[..., 3:] / 255 * a
    return img * (1 - al) + rgba[..., :3] * al


# halo ring (warm pixels on the circle) for Peleh's presence pulse
yy, xx = np.mgrid[0:1920, 0:1080].astype(np.float32)
warm = (PLATE[..., 0] > 150) & (PLATE[..., 0] > PLATE[..., 2] + 25)
cxr, cyr, rr = 557 * S, 790 * S - CROP, 362 * S
ring = cv2.GaussianBlur(((np.abs(np.hypot(xx - cxr, yy - cyr) - rr) < 34) & warm).astype(np.float32), (0, 0), 10)
ring = ring / (ring.max() + 1e-6)

# =============================================================== acting timeline
def act(t):
    """(expression, rest mouth) at time t."""
    if t < to_out("L1", 2.30):
        return "X_bored", "flat_down"
    if t < S_("P1") + 0.18:
        return "X_bored_up", "flat_down"
    if t < S_("P1") + 1.55:
        return "X_caught", "forced"
    if t < to_out("L2", 4.30):
        return "X_caught2", "hmm"
    if t < to_out("L2", 6.68):
        return "X_defend", "smirk_wide"
    return "X_defend_up", "smirk_wide"


T_SIGH = (to_out("L2", 4.30), to_out("L2", 4.72))          # eyes shut on the sigh
BLINKS = [to_out("L1", 1.42), S_("P1") + 1.95, to_out("L2", 5.62)]       # natural blinks (3 frames each)
blink_frames = {int(bt * FPS) + i for bt in BLINKS for i in range(3)}


def face_frame(k, t):
    ex, rest = act(t)
    closed = (k in blink_frames) or (T_SIGH[0] <= t < T_SIGH[1])
    img = over(PLATE, L[("blink_" if closed else "face_") + ex])
    v = vis[k]
    img = over(img, L[f"rest_{rest}"] if v == "X" else L[f"m_{v}"])
    if S_("P1") - 0.25 <= t <= E_("P1") + 0.3:                     # halo breathes while Peleh speaks
        a0, a1 = S_("P1"), E_("P1")
        env = np.clip(min(t - a0 + 0.25, a1 + 0.3 - t) / 0.4, 0, 1)
        pulse = env * (0.55 + 0.45 * np.sin(2 * np.pi * (t - a0) / 1.3))
        img = 255 - (255 - img) * (1 - ring[..., None] * pulse * 0.55 * np.array([1.0, 0.85, 0.45]))
    return img


# =============================================================== Flow clip (Lam silent): action under P2 + reading payoff
raw = subprocess.run([FF, "-v", "quiet", "-i", str(EP / "lam_ep2_flow_clip.mp4"), "-vf", "fps=30,scale=1080:1920:flags=lanczos",
                      "-an", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
CLIP = np.frombuffer(raw, np.uint8).reshape(-1, 1920, 1080, 3)
CN = len(CLIP)
T_CLIP = S_("P2") - 0.05
C_A = (T_CLIP, 1.55, 6.0)                 # surprised look → phone down → book (under «پونزده دقیقه‌ش مالِ کتاب»)
C_B = (E_("P2") + 0.05, 6.0, CN / FPS - 0.04)


def clip_frame(t):
    for (t0, a, b), t1 in ((C_A, C_B[0]), (C_B, DUR)):
        if t0 <= t < t1:
            u = (t - t0) / max(1e-3, t1 - t0)
            return CLIP[min(CN - 1, int((a + (b - a) * u) * FPS))].astype(np.float32)
    return None


def cam(img, z, fx, fy):
    cw, ch = 1080 / z, 1920 / z
    x0 = float(np.clip(fx - cw / 2, 0, 1080 - cw)); y0 = float(np.clip(fy - ch / 2, 0, 1920 - ch))
    M = np.float32([[z, 0, -x0 * z], [0, z, -y0 * z]])
    out = cv2.warpAffine(img, M, (1080, 1920), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
    if z > 1.25:
        out = out + 0.3 * (out - cv2.GaussianBlur(out, (0, 0), 1.2))
    return out


FACE_C = (500 * S, 860 * S - CROP)
SHOTS = [(0.0, S_("P1") - 0.08, 1.00, 1.07, 540, 960),                                  # wide, slow push (hook)
         (S_("P1") - 0.08, S_("L2") - 0.08, 1.62, 1.68, FACE_C[0], FACE_C[1]),          # close on the face: caught
         (S_("L2") - 0.08, T_CLIP, 1.30, 1.37, 470, 905)]                               # medium: the excuse

# head-bob from Lam's voice energy
hop = SR // FPS
lr = np.array([np.sqrt((lam_tr[k * hop:(k + 1) * hop] ** 2).mean() + 1e-12) for k in range(N)])
lr = np.convolve(lr, np.ones(4) / 4, "same"); BOB = np.clip(lr / (np.percentile(lr[lr > 0.005], 95) + 1e-6), 0, 1)

# =============================================================== overlays
CSS = (f"@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}"
       "html,body{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}body{font-family:Vaz;direction:rtl}")


def ov(name, body):
    p = B / f"ov_{name}.png"
    html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style>{body}", p, 1080, 1920)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def sub(text, color):
    return (f"<div style='position:absolute;left:50px;right:50px;top:1420px;text-align:center'><span style='display:inline-block;"
            f"background:rgba(14,22,40,.74);border-radius:22px;padding:10px 30px;font-size:58px;font-weight:700;line-height:1.35;color:{color}'>{text}</span></div>")


ICON = (W0 / "app_ref" / "icon-512.png").as_uri()
OV = {
    "label": ov("label", f"<div style='position:absolute;right:46px;top:236px;background:rgba(14,22,40,.72);border:2px solid rgba(201,162,39,.7);"
                         f"border-radius:20px;padding:6px 20px;font-size:36px;font-weight:800;color:{CREAM}'>لَم · <span style='color:{GOLD}'>قسمت ۲</span></div>"),
    "hook": ov("hook", f"<div style='position:absolute;left:60px;right:60px;top:330px;text-align:center'><div style='display:inline-block;"
                       f"background:rgba(14,22,40,.84);border:2px solid rgba(201,162,39,.6);border-radius:28px;padding:20px 44px;font-size:84px;"
                       f"font-weight:800;color:{CREAM}'>وقتِ کتاب <span style='color:{GOLD}'>ندارم.</span></div></div>"),
    "counter": ov("counter", f"<div style='position:absolute;left:0;right:0;top:330px;text-align:center'><div style='display:inline-block;"
                             f"background:{GOLD};border-radius:999px;padding:14px 40px;font-size:62px;font-weight:900;color:#1B2A4A;"
                             f"box-shadow:0 10px 40px rgba(0,0,0,.45)'>📱 ۴۷ دقیقه ریلز</div></div>"),
    "P1": ov("P1", sub("چهل و هفت دقیقه؟", GOLD)),
    "L2": ov("L2", sub("…اونا حساب نیست.", CREAM)),
    "P2": ov("P2", sub("پونزده دقیقه‌ش مالِ کتاب.", GOLD)),
    "cta": ov("cta", f"<div style='position:absolute;left:50px;right:50px;top:300px;text-align:center'><div style='display:inline-block;"
                     f"background:rgba(14,22,40,.86);border:2px solid rgba(201,162,39,.7);border-radius:30px;padding:22px 44px'>"
                     f"<div style='font-size:74px;font-weight:800;color:{CREAM};line-height:1.35'>بهانه‌ی بعدی مال تو؟</div>"
                     f"<div style='font-size:42px;font-weight:700;color:{GOLD};margin-top:8px'>لَم · قسمت ۳ دوشنبه · فالو کن</div></div></div>"
                     f"<div style='position:absolute;left:0;right:0;top:1400px;text-align:center'><div style='display:inline-flex;align-items:center;gap:18px;"
                     f"background:rgba(14,22,40,.80);border-radius:26px;padding:12px 28px 12px 18px'><img src='{ICON}' style='width:84px;height:84px;"
                     f"border-radius:20px;box-shadow:0 0 0 2px {GOLD}'><span style='font-size:50px;font-weight:800;color:{CREAM}'>پله</span></div></div>"),
}
T_COUNT = E_("L1") - 0.05

# =============================================================== render
enc = subprocess.Popen([FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", str(B / "video.mp4")], stdin=subprocess.PIPE)
for k in range(N):
    t = k / FPS
    cf = clip_frame(t)
    if cf is None:
        sh = next((x for x in SHOTS if x[0] <= t < x[1]), SHOTS[-1])
        u = np.clip((t - sh[0]) / max(1e-3, sh[1] - sh[0]), 0, 1)
        z = sh[2] + (sh[3] - sh[2]) * u + 0.008 * BOB[k]
        img = cam(face_frame(k, t), z, sh[4], sh[5] - 5 * BOB[k])
    else:
        z = 1.04 if t < C_B[0] else 1.04 + 0.05 * np.clip((t - C_B[0]) / TAIL, 0, 1)
        img = cam(cf, z, 540, 940)
    img = over(img, OV["label"])
    if t < S_("P1") - 0.05:
        img = over(img, OV["hook"], np.clip((S_("P1") - 0.05 - t) / 0.2, 0, 1))
    if T_COUNT <= t < S_("L2"):
        a = np.clip(min((t - T_COUNT) / 0.15, (S_("L2") - t) / 0.2), 0, 1)
        c = OV["counter"]
        if t - T_COUNT < 0.3:
            sc = 1 + 0.18 * np.exp(-((t - T_COUNT - 0.08) / 0.09) ** 2)
            c = cv2.warpAffine(c, cv2.getRotationMatrix2D((540, 380), 0, sc), (1080, 1920), borderValue=(0, 0, 0, 0))
        img = over(img, c, a)
    for key in ("P1", "L2", "P2"):
        if S_(key) - 0.05 <= t < E_(key) + 0.25 and t < T_CTA:
            img = over(img, OV[key], np.clip(min((t - S_(key) + 0.05) / 0.12, (E_(key) + 0.25 - t) / 0.15), 0, 1))
    if t >= T_CTA:
        img = over(img, OV["cta"], np.clip((t - T_CTA) / 0.2, 0, 1))
    enc.stdin.write(np.clip(img, 0, 255).astype(np.uint8).tobytes())
enc.stdin.close(); enc.wait()

# =============================================================== audio mix
mus = load(W0 / "reel_d010" / "music_leberch_reading.mp3")
mus = mus[int(2.0 * SR):int(2.0 * SR) + NS]; mus = np.pad(mus, (0, max(0, NS - len(mus))))
voice = lam_tr + pel_tr
actv = np.convolve((np.abs(voice) > 0.01).astype(np.float32), np.ones(int(0.25 * SR)) / int(0.25 * SR), "same") > 0.02
duck = np.convolve(np.where(actv, 0.09, 0.20).astype(np.float32), np.ones(int(0.3 * SR)) / int(0.3 * SR), "same")
tt = np.arange(NS) / SR
duck *= np.clip(tt / 0.4, 0, 1) * np.clip((DUR - tt) / 0.7, 0, 1)
mix = voice + mus * duck


def add(x, at, g):
    i = int(at * SR)
    if 0 <= i < NS:
        n = max(0, min(len(x), NS - i)); mix[i:i + n] += x[:n] * g


wh = load(W0 / "reel_d013" / "_build" / "sfx_whoosh.wav")
add(wh, SHOTS[1][0] - 0.05, 0.08)
add(wh, T_CLIP - 0.05, 0.12)
pt = load(W0 / "audio" / "page_turn.wav"); pt = pt[:int(0.9 * SR)] * np.linspace(1, 0, int(0.9 * SR)) ** 0.5
add(pt, C_A[0] + (C_B[0] - C_A[0]) * ((5.2 - 1.55) / (6.0 - 1.55)), 0.40)
ding_wav(B / "ding.wav", at=0.0, total=2.0, sr=SR)
add(load(B / "ding.wav"), T_CTA + 0.05, 0.6)
add(load(B / "ding.wav")[:int(0.6 * SR)], T_COUNT, 0.25)
mix = mix[:int(DUR * SR)]; mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
with wave.open(str(B / "mix.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype(np.int16).tobytes())


def lufs(path):
    e = subprocess.run([FF, "-hide_banner", "-i", str(path), "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    s_ = e[e.rindex("Summary:"):]
    return float(s_.split("I:")[1].split("LUFS")[0]), float(s_.split("Peak:")[1].split("dBFS")[0])


I0, _ = lufs(B / "mix.wav"); gain = TARGET_I - I0
for _ in range(4):
    subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "mix.wav"), "-af", f"volume={gain:.2f}dB,alimiter=limit=0.84:attack=3:release=60:level=false,aresample=48000",
                    "-ac", "2", str(B / "mix_norm.wav")], check=True)
    I1, tp1 = lufs(B / "mix_norm.wav")
    if abs(I1 - TARGET_I) < 0.3:
        break
    gain += TARGET_I - I1
out = EP / "lam_ep2_final_v3.mp4"
subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "video.mp4"), "-i", str(B / "mix_norm.wav"), "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                "-shortest", "-movflags", "+faststart", str(out)], check=True)
subprocess.run([FF, "-y", "-v", "error", "-i", str(out), "-c:v", "libx264", "-preset", "slow", "-b:v", "1900k", "-maxrate", "2400k", "-bufsize", "4800k",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(EP / "lam_ep2_final_v3_upload.mp4")], check=True)
subprocess.run([FF, "-y", "-v", "error", "-i", str(out), "-frames:v", "1", "-q:v", "2", str(B / "frame0_lam_ep2_v3.jpg")], check=True)
json.dump({"segments": {k: [round(v[0], 3), round(v[1], 3)] for k, v in segs.items()}, "visemes": vis, "shots": SHOTS, "T_CLIP": T_CLIP,
           "T_CTA": T_CTA, "DUR": DUR, "loudness": {"input_I": I0, "out_I": I1, "out_TP": tp1}}, open(EP / "lam_ep2_timeline_v3.json", "w"), indent=1)
print("done", out, round(DUR, 2), "LUFS", I1)
