﻿"""LAM (لَم) vector face kit — parametric SVG generator.

All parts are drawn in a local coordinate system where R = eye-globe radius.
Spec geometry (character_sheet_spec.md §1): eye Ø = 1.8G -> R = 0.9G.
Lighting is fixed (key light upper-left), so parts are NOT mirrored in light even when mirrored in shape.
"""
import math

NAVY, GOLD, CREAM = "#1B2A4A", "#C9A227", "#F3F0E8"
BROW = "#33251A"      # sampled from bean-bag render (median of brow pixels)
MOUTH_IN = "#2A1520"
TONGUE = "#C96A6A"
PUPIL = "#170D05"     # sampled
AO = "#0B1124"

_uid = [0]


def uid(p):
    _uid[0] += 1
    return f"{p}{_uid[0]}"


def f(v):
    return f"{v:.2f}"


def blur(fid, sd):
    return (f'<filter id="{fid}" x="-60%" y="-60%" width="220%" height="220%">'
            f'<feGaussianBlur stdDeviation="{sd}"/></filter>')


# ---------------------------------------------------------------- eyes
def eye_white(R, ao=True):
    g, b1, b2, c = uid("wg"), uid("bl"), uid("bl"), uid("cp")
    s = [f'<defs><radialGradient id="{g}" cx="0.36" cy="0.30" r="0.80">'
         f'<stop offset="0" stop-color="#F4EEE1"/><stop offset="0.40" stop-color="#E6DAC3"/>'
         f'<stop offset="0.75" stop-color="#C9B999"/><stop offset="1" stop-color="#8C7B60"/></radialGradient>'
         f'{blur(b1, R*0.07)}{blur(b2, R*0.05)}<clipPath id="{c}"><circle r="{f(R)}"/></clipPath></defs>']
    if ao:
        s.append(f'<ellipse cx="{f(R*.05)}" cy="{f(R*.09)}" rx="{f(R*1.06)}" ry="{f(R*1.06)}" fill="{AO}" opacity=".65" filter="url(#{b1})"/>')
    s.append(f'<circle r="{f(R)}" fill="url(#{g})"/>')
    # socket occlusion ring, bounce light at the bottom + soft top-left sheen (polish v2: less "clean")
    s.append(f'<g clip-path="url(#{c})"><circle r="{f(R)}" fill="none" stroke="#3A2E26" stroke-width="{f(R*.16)}" opacity=".35" filter="url(#{b2})"/>'
             f'<ellipse cx="{f(R*.05)}" cy="{f(R*.92)}" rx="{f(R*.55)}" ry="{f(R*.16)}" fill="#fff" opacity=".12" filter="url(#{b2})"/>'
             f'<ellipse cx="{f(-R*.38)}" cy="{f(-R*.42)}" rx="{f(R*.30)}" ry="{f(R*.20)}" fill="#fff" opacity=".28" filter="url(#{b2})"/></g>')
    return "".join(s)


def pupil(R, scale=1.0, highlight=True, double=False):
    g, b = uid("pg"), uid("bl")
    r = 0.45 * R * scale
    s = [f'<defs><radialGradient id="{g}" cx="0.40" cy="0.35" r="0.70"><stop offset="0" stop-color="#3E2718"/>'
         f'<stop offset="0.55" stop-color="#1E1009"/><stop offset="1" stop-color="#0A0503"/></radialGradient>{blur(b, R*.012)}</defs>',
         f'<circle r="{f(r)}" fill="url(#{g})"/>',
         f'<circle r="{f(r*0.97)}" fill="none" stroke="#5A3A26" stroke-width="{f(R*.015)}" opacity=".35"/>']
    if highlight:
        s.append(eye_highlight(R, scale, double))
    return "".join(s)


def eye_highlight(R, scale=1.0, double=False):
    b = uid("bl")
    r = 0.45 * R * scale
    s = [f'<defs>{blur(b, R*.01)}</defs>',
         f'<ellipse cx="{f(-r*.42)}" cy="{f(-r*.45)}" rx="{f(r*.26)}" ry="{f(r*.21)}" fill="#FFFDF7" opacity=".95" filter="url(#{b})"/>',
         f'<circle cx="{f(r*.30)}" cy="{f(r*.36)}" r="{f(r*.09)}" fill="#FFFDF7" opacity=".55"/>']
    if double:
        s.append(f'<ellipse cx="{f(r*.18)}" cy="{f(-r*.52)}" rx="{f(r*.15)}" ry="{f(r*.12)}" fill="#FFFDF7" opacity=".9"/>')
    return "".join(s)


def lid(R, cover, tilt=0.0, lower=0.0, sag=0.07):
    """Upper lid cap covering `cover` (0..1) of the eye height; tilt in degrees (+ = viewer-right side lower).
    Optional lower lid covering `lower` from the bottom (squint)."""
    cover = max(cover, 0.04)
    gl, c, c2, b1, b2 = uid("lg"), uid("cp"), uid("cp"), uid("bl"), uid("bl")
    Rc = R * 1.07          # polish v2: lid dome slightly larger than the white (reads as a thick clay lid)
    y0 = -R + 2 * R * cover
    k = math.tan(math.radians(tilt))
    W = R * 1.35
    yl, yr = y0 - k * W, y0 + k * W
    ym = y0 + R * sag * (1 if cover < 0.97 else 0)
    edge = f"M{f(-W)},{f(yl)} Q0,{f(2*ym - (yl+yr)/2)} {f(W)},{f(yr)}"
    cap = f"M{f(-W)},{f(-R*1.6)} L{f(W)},{f(-R*1.6)} L{f(W)},{f(yr)} Q0,{f(2*ym - (yl+yr)/2)} {f(-W)},{f(yl)} Z"
    s = [f'<defs><radialGradient id="{gl}" cx="0.30" cy="0.12" r="0.95" gradientUnits="objectBoundingBox">'
         f'<stop offset="0" stop-color="#56608A"/><stop offset="0.45" stop-color="#2C3A63"/>'
         f'<stop offset="0.85" stop-color="{NAVY}"/><stop offset="1" stop-color="#121B34"/></radialGradient>'
         f'<clipPath id="{c}"><circle r="{f(Rc)}"/></clipPath><clipPath id="{c2}"><circle r="{f(R)}"/></clipPath>'
         f'{blur(b1, R*.09)}{blur(b2, R*.018)}</defs>']
    # shadow cast by lid onto the white
    s.append(f'<g clip-path="url(#{c2})"><path d="{edge}" fill="none" stroke="#231B26" stroke-width="{f(R*.32)}" opacity=".62" filter="url(#{b1})" transform="translate(0,{f(R*.09)})"/></g>')
    s.append(f'<g clip-path="url(#{c})"><path d="{cap}" fill="url(#{gl})"/>'
             f'<path d="{edge}" fill="none" stroke="#0B1229" stroke-width="{f(R*.09)}" opacity=".95" filter="url(#{b2})"/>'
             f'<path d="{edge}" fill="none" stroke="#4E5A86" stroke-width="{f(R*.075)}" opacity=".9" transform="translate(0,{f(-R*.075)})" filter="url(#{b2})"/>'
             f'<path d="{edge}" fill="none" stroke="#7480AA" stroke-width="{f(R*.025)}" opacity=".7" transform="translate(0,{f(-R*.095)})" filter="url(#{b2})"/></g>')
    if lower > 0:
        yb = R - 2 * R * lower
        ed2 = f"M{f(-W)},{f(yb)} Q0,{f(yb - R*.12)} {f(W)},{f(yb)}"
        cap2 = f"M{f(-W)},{f(R*1.6)} L{f(W)},{f(R*1.6)} L{f(W)},{f(yb)} Q0,{f(yb - R*.12)} {f(-W)},{f(yb)} Z"
        gl2 = uid("lg")
        s.append(f'<defs><linearGradient id="{gl2}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3A4672"/>'
                 f'<stop offset=".5" stop-color="{NAVY}"/><stop offset="1" stop-color="#121B34"/></linearGradient></defs>'
                 f'<g clip-path="url(#{c})"><path d="{cap2}" fill="url(#{gl2})"/>'
                 f'<path d="{ed2}" fill="none" stroke="#0E1630" stroke-width="{f(R*.05)}" filter="url(#{b2})"/></g>')
    return "".join(s)


def eye_happy(R):
    """Closed happy eye (^): full lid globe + upward arch crease."""
    gl, b1, b2 = uid("lg"), uid("bl"), uid("bl")
    s = [f'<defs><radialGradient id="{gl}" cx="0.32" cy="0.22" r="0.9"><stop offset="0" stop-color="#3A4672"/>'
         f'<stop offset=".5" stop-color="#22305A"/><stop offset=".9" stop-color="{NAVY}"/><stop offset="1" stop-color="#121B34"/></radialGradient>'
         f'{blur(b1, R*.07)}{blur(b2, R*.02)}</defs>',
         f'<ellipse cx="{f(R*.04)}" cy="{f(R*.08)}" rx="{f(R*1.02)}" ry="{f(R*.95)}" fill="{AO}" opacity=".45" filter="url(#{b1})"/>',
         f'<ellipse rx="{f(R*1.0)}" ry="{f(R*.92)}" fill="url(#{gl})"/>',
         f'<path d="M{f(-R*.68)},{f(R*.30)} Q0,{f(-R*.52)} {f(R*.68)},{f(R*.30)}" fill="none" stroke="#0A1024" stroke-width="{f(R*.11)}" stroke-linecap="round" filter="url(#{b2})"/>',
         f'<path d="M{f(-R*.60)},{f(R*.44)} Q0,{f(-R*.32)} {f(R*.60)},{f(R*.44)}" fill="none" stroke="#56628E" stroke-width="{f(R*.05)}" stroke-linecap="round" opacity=".7" filter="url(#{b2})"/>']
    return "".join(s)


def eye(R, cover=0.35, tilt=0.0, look=(0, 0), pscale=1.0, lower=0.0, double=False):
    """Complete eye: white + pupil (clipped) + lid. look = (dx, dy) in units of R (pupil centre offset)."""
    c = uid("cp")
    px, py = look[0] * R, look[1] * R
    return (eye_white(R) + f'<defs><clipPath id="{c}"><circle r="{f(R)}"/></clipPath></defs>'
            f'<g clip-path="url(#{c})"><g transform="translate({f(px)},{f(py)})">{pupil(R, pscale, True, double)}</g></g>'
            + lid(R, cover, tilt, lower))


# ---------------------------------------------------------------- brows
BROW_SHAPES = {   # dy (R), arch (R), inner_k (R; + = inner end lower)
    "base":    (0.00, 0.16, 0.00),
    "up":      (-0.26, 0.24, 0.00),
    "frown":   (0.10, 0.04, 0.24),
    "worried": (-0.14, -0.02, -0.26),
    "soft":    (-0.08, 0.20, -0.06),
    "flat":    (0.12, 0.00, -0.10),
}


def brow(R, shape="base", side="L", extra_dy=0.0):
    """Viewer-left brow has its broad head (inner end) on +x; right brow is mirrored."""
    dy, arch, k = BROW_SHAPES[shape]
    dy += extra_dy
    L = R * 0.92         # half length (~eye width; trimmed so the pair never touches)
    t0 = R * 0.42        # head thickness (0.3G spec ~0.33R; +25% reads closer to the renders)
    pts_top, pts_bot = [], []
    N = 40
    for i in range(N + 1):
        u = -1 + 2 * i / N
        x = u * L
        y = (dy - arch * (1 - u * u) + k * u) * R / R * R if False else (dy - arch * (1 - u * u) + k * u) * 1.0
        y *= R
        t = t0 * (0.42 + 0.58 * ((u + 1) / 2) ** 0.8) * (1 - 0.15 * u * u)
        # normal of centreline
        dydx = (2 * arch * u + k) * R / L
        nx, ny = -dydx, 1.0
        n = math.hypot(nx, ny)
        nx, ny = nx / n, ny / n
        pts_top.append((x - nx * t / 2, y - ny * t / 2))
        pts_bot.append((x + nx * t / 2, y + ny * t / 2))
    # round caps
    def cap(center_pts, start, end, rev):
        (x1, y1), (x2, y2) = start, end
        cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
        r = math.hypot(x2 - x1, y2 - y1) / 2
        a0 = math.atan2(y1 - cy, x1 - cx)
        out = []
        for j in range(1, 12):
            a = a0 + (math.pi * j / 12) * (1 if rev else -1)
            out.append((cx + r * math.cos(a), cy + r * math.sin(a)))
        return out
    poly = pts_top + cap(None, pts_top[-1], pts_bot[-1], True) + pts_bot[::-1] + cap(None, pts_bot[0], pts_top[0], True)
    d = "M" + " L".join(f"{f(x)},{f(y)}" for x, y in poly) + "Z"
    g, b1, b2, c = uid("bg"), uid("bl"), uid("bl"), uid("cp")
    flip = ' transform="scale(-1,1)"' if side == "R" else ""
    return (f'<defs><linearGradient id="{g}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5A4231"/>'
            f'<stop offset=".45" stop-color="#3A2A1E"/><stop offset="1" stop-color="#1E140D"/></linearGradient>'
            f'{blur(b1, R*.06)}{blur(b2, R*.02)}<clipPath id="{c}"><path d="{d}"/></clipPath></defs>'
            f'<g{flip}><path d="{d}" fill="{AO}" opacity=".6" filter="url(#{b1})" transform="translate({f(R*.03)},{f(R*.09)})"/>'
            f'<path d="{d}" fill="url(#{g})"/>'
            f'<g clip-path="url(#{c})"><path d="{d}" fill="none" stroke="#7A5C44" stroke-width="{f(R*.06)}" opacity=".55" filter="url(#{b2})" transform="translate(0,{f(R*.035)})"/></g></g>')


# ---------------------------------------------------------------- mouths
# shape: (hw factor, top h, bottom h, superellipse n, teeth_top, teeth_bot, tongue, extra_bend)
OPEN = {
    "B_SSH":   (1.00, .07, .13, 5.0, True, True, None, 0.0),
    "C_E":     (0.90, .15, .33, 3.0, True, False, "low", 0.0),
    "D_AA":    (0.95, .22, .64, 2.4, True, False, "big", 0.0),
    "E_O":     (0.50, .25, .38, 2.0, False, False, "low", 0.0),
    "F_OO":    (0.30, .15, .19, 2.0, False, False, None, 0.0),
    "G_FV":    (0.85, .07, .15, 4.0, True, False, "lip", 0.0),
    "H_L":     (0.80, .17, .42, 2.6, True, False, "up", 0.0),
    "EE_wide": (1.15, .08, .21, 5.0, True, True, None, -0.13),
}
MOUTHS = ["X_rest", "A_MBP", "B_SSH", "C_E", "D_AA", "E_O", "F_OO", "G_FV", "H_L", "EE_wide"]


def _curve(hw, bend, skew):
    return lambda x: bend * (x / hw) ** 2 + skew * (x / hw)


def mouth(R, shape, frown=False, scale=1.0):
    hw0 = 0.665 * R * scale
    bend = (0.17 if frown else -0.04) * R * scale
    skew = -0.05 * R * scale
    b1, b2, b3 = uid("bl"), uid("bl"), uid("bl")
    defs = f'{blur(b1, R*.05*scale)}{blur(b2, R*.015*scale)}{blur(b3, R*.03*scale)}'
    s = []
    if shape in ("X_rest", "A_MBP", "smile_soft", "flat_down", "hmm", "purse"):
        if shape == "X_rest":
            hw, bnd, sk, w = hw0 * 0.95, (0.12 if frown else -0.10) * R * scale, -0.13 * R * scale, 0.075
        elif shape == "A_MBP":
            hw, bnd, sk, w = hw0 * 0.80, (0.15 if frown else 0.0), 0.0, 0.10
            bnd = bnd * R * scale
        elif shape == "smile_soft":
            hw, bnd, sk, w = hw0 * 0.80, -0.14 * R * scale, 0.0, 0.07
        elif shape == "flat_down":
            hw, bnd, sk, w = hw0 * 0.75, 0.08 * R * scale, 0.02 * R * scale, 0.07
        elif shape == "hmm":
            hw, bnd, sk, w = hw0 * 0.33, 0.02 * R * scale, 0.0, 0.09
        else:  # purse: crooked pursed lips (grumpy / thinking)
            hw, bnd, sk, w = hw0 * 0.45, (0.10 if frown else 0.03) * R * scale, -0.08 * R * scale, 0.085
        c = _curve(hw, bnd, sk)
        N = 36
        top, bot = [], []
        for i in range(N + 1):
            x = -hw + 2 * hw * i / N
            u = x / hw
            th = w * R * scale * (0.35 + 0.65 * (1 - u * u) ** 0.6) / 2
            top.append((x, c(x) - th))
            bot.append((x, c(x) + th))
        d = "M" + " L".join(f"{f(x)},{f(y)}" for x, y in top + bot[::-1]) + "Z"
        line = "M" + " L".join(f"{f(x)},{f(c(x))}" for x, _ in top)
        s.append(f'<path d="{line}" fill="none" stroke="#5B6690" stroke-width="{f(R*.05*scale)}" stroke-linecap="round" opacity=".45" filter="url(#{b3})" transform="translate(0,{f(R*.075*scale)})"/>')
        if shape in ("A_MBP", "hmm", "purse"):  # puffed lips
            s.append(f'<ellipse cx="0" cy="{f(c(0) - R*.10*scale)}" rx="{f(hw*.8)}" ry="{f(R*.07*scale)}" fill="#55608A" opacity=".35" filter="url(#{b3})"/>'
                     f'<ellipse cx="0" cy="{f(c(0) + R*.12*scale)}" rx="{f(hw*.85)}" ry="{f(R*.08*scale)}" fill="#55608A" opacity=".40" filter="url(#{b3})"/>')
        s.append(f'<path d="{d}" fill="#0C1020" filter="url(#{b2})"/>')
        if shape == "X_rest" and not frown:  # dimple at the raised (viewer-right) corner
            x2, y2 = hw, c(hw)
            s.append(f'<path d="M{f(x2 + R*.01*scale)},{f(y2 - R*.07*scale)} Q{f(x2 + R*.06*scale)},{f(y2 + R*.01*scale)} {f(x2 + R*.0*scale)},{f(y2 + R*.07*scale)}" '
                     f'fill="none" stroke="#0C1020" stroke-width="{f(R*.03*scale)}" stroke-linecap="round" opacity=".45" filter="url(#{b2})"/>')
        return f"<defs>{defs}</defs>" + "".join(s)

    hwf, ht, hb, n, tt, tb, tongue, eb = OPEN[shape]
    hw = hw0 * hwf
    ht, hb = ht * R * scale, hb * R * scale
    bnd = bend + eb * R * scale * (0.4 if frown else 1.0)
    c = _curve(hw, bnd, skew)
    N = 60
    xs = [-hw + 2 * hw * i / N for i in range(N + 1)]
    env = [(max(0.0, 1 - abs(x / hw) ** n)) ** (1 / n) for x in xs]
    top = [(x, c(x) - ht * e) for x, e in zip(xs, env)]
    bot = [(x, c(x) + hb * e) for x, e in zip(xs, env)]
    cav = "M" + " L".join(f"{f(x)},{f(y)}" for x, y in top + bot[::-1]) + "Z"
    topd = "M" + " L".join(f"{f(x)},{f(y)}" for x, y in top)
    botd = "M" + " L".join(f"{f(x)},{f(y)}" for x, y in bot)
    gc, cp, gt = uid("mg"), uid("cp"), uid("tg")
    defs += (f'<radialGradient id="{gc}" cx="0.5" cy="0.62" r="0.65"><stop offset="0" stop-color="#4E2232"/>'
             f'<stop offset=".6" stop-color="{MOUTH_IN}"/><stop offset="1" stop-color="#14080E"/></radialGradient>'
             f'<linearGradient id="{gt}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FBF8F1"/>'
             f'<stop offset=".7" stop-color="#E8DFCD"/><stop offset="1" stop-color="#C4B69B"/></linearGradient>'
             f'<clipPath id="{cp}"><path d="{cav}"/></clipPath>')
    s.append(f'<path d="{cav}" fill="{AO}" opacity=".55" filter="url(#{b1})" transform="translate({f(R*.02*scale)},{f(R*.05*scale)})"/>')
    s.append(f'<path d="{cav}" fill="url(#{gc})"/>')
    inner = []
    tg = TONGUE
    if tongue == "low":
        inner.append(f'<ellipse cx="{f(hw*.08)}" cy="{f(c(0) + hb*.95)}" rx="{f(hw*.55)}" ry="{f(hb*.55)}" fill="{tg}" opacity=".95"/>')
    elif tongue == "big":
        inner.append(f'<ellipse cx="{f(hw*.06)}" cy="{f(c(0) + hb*.82)}" rx="{f(hw*.62)}" ry="{f(hb*.50)}" fill="{tg}"/>'
                     f'<ellipse cx="{f(-hw*.12)}" cy="{f(c(0) + hb*.62)}" rx="{f(hw*.22)}" ry="{f(hb*.12)}" fill="#E39A98" opacity=".7" filter="url(#{b2})"/>')
    elif tongue == "up":
        inner.append(f'<ellipse cx="0" cy="{f(c(0) + hb*.85)}" rx="{f(hw*.6)}" ry="{f(hb*.45)}" fill="#A9545A"/>'
                     f'<path d="M{f(-hw*.30)},{f(c(0)+hb*.7)} Q0,{f(c(0) - ht*.6)} {f(hw*.30)},{f(c(0)+hb*.7)} Z" fill="{tg}"/>')
    if tt:
        th = min(R * .13 * scale, (ht + hb) * 0.42)
        tp = [(x, y - R * scale) for x, y in top]
        tpb = [(x, y + th) for x, y in top]
        d = "M" + " L".join(f"{f(x)},{f(y)}" for x, y in tp + tpb[::-1]) + "Z"
        inner.append(f'<path d="{d}" fill="url(#{gt})"/>')
    if tb:
        th = min(R * .11 * scale, (ht + hb) * 0.40)
        bp = [(x, y + R * scale) for x, y in bot]
        bpt = [(x, y - th) for x, y in bot]
        d = "M" + " L".join(f"{f(x)},{f(y)}" for x, y in bp + bpt[::-1]) + "Z"
        inner.append(f'<path d="{d}" fill="url(#{gt})" opacity=".92"/>')
        inner.append(f'<path d="M{f(-hw)},{f(c(0)+ (hb-ht)/2 * 0)} " fill="none"/>')
    if tongue == "lip":   # G_FV: lower lip tucked under the upper teeth
        inner.append(f'<ellipse cx="0" cy="{f(c(0) + hb*1.05)}" rx="{f(hw*1.15)}" ry="{f(hb*.75)}" fill="#2A3558"/>'
                     f'<ellipse cx="{f(-hw*.1)}" cy="{f(c(0) + hb*.75)}" rx="{f(hw*.55)}" ry="{f(hb*.18)}" fill="#55608A" opacity=".6" filter="url(#{b2})"/>')
    # shadow under upper lip
    inner.append(f'<path d="{topd}" fill="none" stroke="#000" stroke-width="{f(R*.10*scale)}" opacity=".45" filter="url(#{b3})" transform="translate(0,{f(R*.03*scale)})"/>')
    s.append(f'<g clip-path="url(#{cp})">{"".join(inner)}</g>')
    # lips: dark edge + highlights (clay rim)
    s.append(f'<path d="{cav}" fill="none" stroke="#10182E" stroke-width="{f(R*.05*scale)}" stroke-linejoin="round" filter="url(#{b2})"/>')
    lw = R * (.09 if shape == "F_OO" else .05) * scale
    s.append(f'<path d="{botd}" fill="none" stroke="#56628E" stroke-width="{f(lw)}" stroke-linecap="round" opacity=".55" filter="url(#{b3})" transform="translate(0,{f(R*.07*scale)})"/>')
    s.append(f'<path d="{topd}" fill="none" stroke="#56628E" stroke-width="{f(R*.035*scale)}" stroke-linecap="round" opacity=".30" filter="url(#{b3})" transform="translate(0,{f(-R*.06*scale)})"/>')
    if shape == "F_OO":
        s.append(f'<ellipse cx="0" cy="{f(c(0) + (hb-ht)/2)}" rx="{f(hw*1.35)}" ry="{f((ht+hb)*0.85)}" fill="none" stroke="#2A3760" stroke-width="{f(R*.10*scale)}" opacity=".8" filter="url(#{b3})"/>')
    return f"<defs>{defs}</defs>" + "".join(s)


# ---------------------------------------------------------------- expressions
# per eye: (cover, tilt, lower, (lookx, looky), pupil scale, double sparkle)  | brow L, brow R (shape, extra dy) | mouth
EXPR = {
    "E01": dict(name="طعنه‌زن (پیش‌فرض)", en="Sarcastic (default)",
                eyeL=(0.35, -4, 0, (0.30, 0.06), 1, False), eyeR=(0.35, 4, 0, (0.30, 0.06), 1, False),
                browL=("base", 0.04), browR=("up", 0.08), mouth=("X_rest", False)),
    "E02": dict(name="خسته", en="Tired",
                eyeL=(0.55, -6, 0, (0.05, 0.32), 1, False), eyeR=(0.55, 6, 0, (0.05, 0.32), 1, False),
                browL=("flat", 0.0), browR=("flat", 0.0), mouth=("flat_down", False)),
    "E03": dict(name="کنجکاو", en="Curious",
                eyeL=(0.06, 0, 0, (0.28, -0.30), 1, False), eyeR=(0.06, 0, 0, (0.28, -0.30), 1, False),
                browL=("up", 0.0), browR=("up", -0.14), mouth=("hmm", False)),
    "E04": dict(name="ذوق‌زده", en="Excited",
                eyeL="happy", eyeR="happy",
                browL=("up", -0.08), browR=("up", -0.08), mouth=("laugh", False)),
    "E05": dict(name="غرغرو / بی‌میل", en="Grumpy / reluctant",
                eyeL=(0.45, 8, 0, (-0.40, 0.08), 1, False), eyeR=(0.45, -8, 0, (-0.40, 0.08), 1, False),
                browL=("frown", 0.0), browR=("frown", 0.0), mouth=("purse", True)),
    "E06": dict(name="مچ‌گرفته / خجالتی", en="Caught / sheepish",
                eyeL=(0.02, 0, 0, (-0.45, 0.22), 0.85, False), eyeR=(0.02, 0, 0, (-0.45, 0.22), 0.85, False),
                browL=("worried", 0.0), browR=("worried", 0.0), mouth=("forced", False)),
    "E07": dict(name="متعجبِ دل‌گرم", en="Touched surprise",
                eyeL=(0.02, 0, 0, (0.0, 0.04), 1.08, True), eyeR=(0.02, 0, 0, (0.0, 0.04), 1.08, True),
                browL=("soft", -0.18), browR=("soft", -0.18), mouth=("o_small", False)),
    "E08": dict(name="مهربان / در حال گوش دادن", en="Kind / listening",
                eyeL=(0.20, 0, 0, (0.06, 0.22), 1, False), eyeR=(0.20, 0, 0, (0.06, 0.22), 1, False),
                browL=("soft", 0.0), browR=("soft", 0.0), mouth=("smile_soft", False)),
    "E09": dict(name="حسابگر / در حال فکر", en="Calculating",
                eyeL=(0.12, 0, 0, (0.22, -0.30), 1, False), eyeR=(0.42, -6, 0.22, (0.22, -0.30), 1, False),
                browL=("up", -0.04), browR=("frown", 0.04), mouth=("purse", False)),
    "E10": dict(name="راضی (لبخند کج)", en="Satisfied smirk",
                eyeL=(0.30, -3, 0, (0.0, 0.05), 1, False), eyeR=(0.30, 3, 0, (0.0, 0.05), 1, False),
                browL=("soft", 0.04), browR=("soft", -0.04), mouth=("smirk_wide", False)),
}


def mouth_for_expr(R, m, scale=1.0):
    kind, frown = m
    if kind == "none":          # eyes+brows only (mouth swapped separately for lip-sync)
        return ""
    if kind == "laugh":
        return mouth_custom(R, scale, hwf=1.05, ht=.12, hb=.62, n=2.6, bend=-0.20, tt=True, tongue="big")
    if kind == "forced":
        return mouth_custom(R, scale, hwf=1.05, ht=.12, hb=.24, n=6, bend=-0.05, tt=True, tb=True, skew=0.06)
    if kind == "o_small":
        return mouth_custom(R, scale, hwf=0.40, ht=.20, hb=.28, n=2, bend=0, tt=False)
    if kind == "smirk_wide":
        return mouth(R, "X_rest", False, scale * 1.22)
    return mouth(R, kind, frown, scale)


def mouth_custom(R, scale, hwf, ht, hb, n, bend, tt=False, tb=False, tongue=None, skew=-0.05):
    key = f"_c{uid('k')}"
    OPEN[key] = (hwf, ht, hb, n, tt, tb, tongue, bend + 0.04)
    try:
        return mouth(R, key, False, scale)
    finally:
        OPEN.pop(key, None)


def face(R, ex, eyeL=(-1.11, 0), eyeR=(1.11, 0), browL=None, browR=None, mouthc=(0.30, 2.11), mscale=1.0,
         eyeRscale=1.0):
    """Compose one expression. Coordinates in units of R (eye centres default per spec)."""
    e = EXPR[ex]
    browL = browL or (eyeL[0] - 0.06, eyeL[1] - 1.55)
    browR = browR or (eyeR[0] + 0.06, eyeR[1] - 1.55)
    out = []
    for (cx, cy), spec, sc in ((eyeL, e["eyeL"], 1.0), (eyeR, e["eyeR"], eyeRscale)):
        Rr = R * sc
        if spec == "happy":
            out.append(f'<g transform="translate({f(cx*R)},{f(cy*R)})">{eye_happy(Rr)}</g>')
        else:
            cov, tilt, low, look, ps, dbl = spec
            out.append(f'<g transform="translate({f(cx*R)},{f(cy*R)})">{eye(Rr, cov, tilt, look, ps, low, dbl)}</g>')
    out.append(f'<g transform="translate({f(browL[0]*R)},{f(browL[1]*R)})">{brow(R, e["browL"][0], "L", e["browL"][1])}</g>')
    out.append(f'<g transform="translate({f(browR[0]*R)},{f(browR[1]*R)})">{brow(R, e["browR"][0], "R", e["browR"][1])}</g>')
    out.append(f'<g transform="translate({f(mouthc[0]*R)},{f(mouthc[1]*R)})">{mouth_for_expr(R, e["mouth"], mscale)}</g>')
    return "".join(out)


def faceplate(w, h, rx=40):
    """Navy clay patch used behind previews (not part of the kit)."""
    g, n = uid("fp"), uid("nz")
    return (f'<defs><radialGradient id="{g}" cx="0.28" cy="0.18" r="1.0"><stop offset="0" stop-color="#34416C"/>'
            f'<stop offset=".5" stop-color="{NAVY}"/><stop offset="1" stop-color="#111A31"/></radialGradient>'
            f'<filter id="{n}"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="3"/>'
            f'<feColorMatrix values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 .05 0"/><feComposite in2="SourceGraphic" operator="in"/></filter></defs>'
            f'<rect x="{f(-w/2)}" y="{f(-h/2)}" width="{f(w)}" height="{f(h)}" rx="{rx}" fill="url(#{g})"/>'
            f'<rect x="{f(-w/2)}" y="{f(-h/2)}" width="{f(w)}" height="{f(h)}" rx="{rx}" fill="#fff" filter="url(#{n})"/>')


def svg_doc(inner, w, h, vb=None):
    vb = vb or (-w / 2, -h / 2, w, h)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{int(w)}" height="{int(h)}" '
            f'viewBox="{f(vb[0])} {f(vb[1])} {f(vb[2])} {f(vb[3])}">{inner}</svg>')
