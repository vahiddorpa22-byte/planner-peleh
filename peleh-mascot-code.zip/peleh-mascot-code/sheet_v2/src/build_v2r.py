﻿"""Form lock 'v2-R': proportions measured on Vahid's renders (R3c master, R1, R3b, R3a), team proposal."""
import lam_facekit as K
from common import *
from build_grid import DEFS, fa, schematic_34
from render_util import html_to_png

RV = ROOT.parent / "renders_vahid"
CC = ROOT / "renders_cc"
ST = ROOT / "style_test"
OUT = ROOT / "grid"

# v2-R in G (G = one riser).  (x0, x1, height)
STEPS2 = [(0, 2.4, 4.9), (2.4, 3.1, 3.9), (3.1, 3.8, 2.9), (3.8, 4.5, 1.9)]
FACE2 = dict(eye_d=0.9, gap=0.1, eye_below_top=1.5, brow_above=0.67, mouth_below=0.67)

MEAS = {  # pixel measurements on the renders (step tops, tread x-bounds, bottom or None)
    "R3c": dict(tops=[360, 590, 780, 950], xs=[243, 735, 905, 1015, 1140], bottom=None, note="روبه‌رو، تمیز · پایه‌ی پیشنهادی"),
    "R1": dict(tops=[320, 497, 712, 950], xs=[245, 545, 740, 935, 1050], bottom=1300, note="روبه‌رو با کمی چرخش · زمینه‌ی خاکستری"),
    "R3b": dict(tops=[520, 645, 780, 905], xs=[455, 700, 825, 940, 1040], bottom=None, note="پوف + گوشی"),
    "R3a": dict(tops=[595, 730, 915], xs=[470, 700, 900, 1060], bottom=None, note="پوف + کتاب · پله‌ی ۴ پشت دست پنهان است"),
}


def stats(k):
    m = MEAS[k]
    t = m["tops"]
    risers = [b - a for a, b in zip(t, t[1:])]
    G = sum(risers) / len(risers)
    treads = [(b - a) / G for a, b in zip(m["xs"], m["xs"][1:])]
    width = (m["xs"][-1] - m["xs"][0]) / G
    h = (m["bottom"] - t[0]) / G if m["bottom"] else None
    return G, treads, width, h


def schematic_v2r(G, ox, oy, face="E01", grid=True):
    X = lambda x: ox + x * G
    Y = lambda y: oy - y * G
    s = []
    if grid:
        for i in range(-3, 7):
            s.append(f'<line x1="{X(-2)}" y1="{Y(i)}" x2="{X(6.6)}" y2="{Y(i)}" stroke="#fff" stroke-opacity="{.3 if i==0 else .12}"/>'
                     f'<text x="{X(-2.2)}" y="{Y(i)+5}" font-size="14" fill="#E6E8EE" fill-opacity=".7" text-anchor="end" font-family="Vaz">{i}G</text>')
        for i in range(-2, 7):
            s.append(f'<line x1="{X(i)}" y1="{Y(-3.6)}" x2="{X(i)}" y2="{Y(6.2)}" stroke="#fff" stroke-opacity=".10"/>')
    # legs / shoes / arms (spec limbs: leg 0.5G, shoe 1G high)
    for lx in (1.3, 3.2):
        s.append(f'<rect x="{X(lx-.25)}" y="{Y(0.2)}" width="{.5*G}" height="{2.7*G}" rx="{.25*G}" fill="url(#navyV)"/>'
                 f'<rect x="{X(lx-.75)}" y="{Y(-2.5)}" width="{1.5*G}" height="{1.0*G}" rx="{.42*G}" fill="url(#cream)"/>'
                 f'<rect x="{X(lx-.75)}" y="{Y(-2.5)+.25*G}" width="{1.5*G}" height="{.42*G}" fill="{GOLD}" rx="{.12*G}"/>'
                 f'<rect x="{X(lx-.8)}" y="{Y(-3.3)}" width="{1.6*G}" height="{.22*G}" rx="{.1*G}" fill="#E4DDCB"/>')
    for side in (-1, 1):
        x0 = 0.12 if side < 0 else 4.38
        ex = x0 + side * 0.95
        s.append(f'<path d="M{X(x0)},{Y(1.5)} C{X(x0+side*0.8)},{Y(1.45)} {X(ex+side*.1)},{Y(0.8)} {X(ex)},{Y(-0.3)}" fill="none" stroke="url(#navyV)" stroke-width="{.45*G}" stroke-linecap="round"/>'
                 f'<ellipse cx="{X(ex)}" cy="{Y(-0.6)}" rx="{.5*G}" ry="{.48*G}" fill="#22325A"/>')
    d = 0.2
    pts = [(d, d), (4.5 - d, d)]
    for x0, x1, h in reversed(STEPS2):
        pts += [(x1 - d, h - d), (x0 - d if x0 > 0 else d, h - d)]
    pts = pts[:-1] + [(d, STEPS2[0][2] - d)]
    path = "M" + " L".join(f"{X(x):.1f},{Y(y):.1f}" for x, y in pts) + "Z"
    s.append(f'<path d="{path}" fill="url(#navyB)" stroke="url(#navyB)" stroke-width="{2*d*G}" stroke-linejoin="round"/>')
    for k, (a, b, h) in enumerate(STEPS2, 1):
        cx = X((a + b) / 2)
        s.append(f'<circle cx="{cx}" cy="{Y(0.55)}" r="{.24*G}" fill="{GOLD}"/><text x="{cx}" y="{Y(0.55)+6}" font-size="{.3*G}" font-weight="800" fill="{NAVY}" text-anchor="middle" font-family="Vaz">{fa(k)}</text>'
                 f'<text x="{cx}" y="{Y(h)-.25*G}" font-size="14" font-weight="700" fill="{NAVY}" fill-opacity=".8" text-anchor="middle" font-family="Vaz" direction="ltr">{h}G</text>')
    s.append(f'<path d="M{X(0)},{Y(0)+.45*G} H{X(4.5)}" stroke="{GOLD}" stroke-width="1.5"/><text x="{X(2.25)}" y="{Y(0)+.45*G+20}" font-size="16" fill="{GOLD}" text-anchor="middle" font-family="Vaz" font-weight="700" direction="ltr">4.5G</text>')
    s.append(f'<path d="M{X(-1.45)},{Y(0)} V{Y(4.9)}" stroke="{GOLD}" stroke-width="1.5"/><text x="{X(-1.55)}" y="{Y(2.45)}" font-size="16" fill="{GOLD}" text-anchor="end" font-family="Vaz" font-weight="700" direction="ltr">4.9G</text>')
    if face:
        R = FACE2["eye_d"] / 2 * G
        cx = 1.2
        ey = 4.9 - FACE2["eye_below_top"]
        off = (FACE2["eye_d"] + FACE2["gap"]) / 2
        u = lambda x, y: (X(x) / R, Y(y) / R)
        fc = K.face(R, face, eyeL=u(cx - off, ey), eyeR=u(cx + off, ey), browL=u(cx - off, ey + FACE2["brow_above"]),
                    browR=u(cx + off, ey + FACE2["brow_above"]), mouthc=u(cx + 0.15, ey - FACE2["mouth_below"]), mscale=1.05)
        s.append(fc)
    return "".join(s)


def grid_png():
    W, H = 1800, 1000
    G = 86
    r3c = uri(RV / "R3c.jpg")
    svg = (f'<svg width="{W}" height="{H}" style="direction:ltr">{DEFS}<rect width="{W}" height="{H}" fill="{GREY}"/>'
           f'<image href="{r3c}" x="1030" y="110" width="{1333*0.62:.0f}" height="{2000*0.62:.0f}" clip-path="url(#cl)"/>'
           f'<defs><clipPath id="cl"><rect x="1080" y="110" width="680" height="860" rx="18"/></clipPath></defs>'
           f'<text x="1420" y="955" font-size="20" font-weight="800" fill="#fff" text-anchor="middle" font-family="Vaz">R3c (Vahid) · master reference</text>'
           f'<text x="60" y="60" font-size="30" font-weight="800" fill="{NAVY}" font-family="Vaz">lam_P1_proportion_grid · v2-R (R3c master) · LOCKED · approved by Vahid 2026-11-02</text>'
           f'<g>{schematic_v2r(G, 330, 660)}</g></svg>')
    html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS} html,body{{width:{W}px;height:{H}px}}</style>{svg}",
                OUT / "lam_P1_proportion_grid_v2R.png", W, H, transparent=False)


def overlay_svg(k, sc, x0, y0):
    m = MEAS[k]
    G, treads, width, h = stats(k)
    T = lambda x, y: ((x - x0) * sc, (y - y0) * sc)
    s = []
    for i, y in enumerate(m["tops"], 1):
        a, b = T(m["xs"][0] - 40, y), T(m["xs"][-1] + 60, y)
        s.append(f'<line x1="{a[0]}" y1="{a[1]}" x2="{b[0]}" y2="{b[1]}" stroke="#fff" stroke-opacity=".8" stroke-width="2" stroke-dasharray="9 6"/>'
                 f'<g transform="translate({b[0]+4},{a[1]})"><circle r="13" fill="#fff"/><text y="5" font-size="15" font-weight="800" fill="{NAVY}" text-anchor="middle" font-family="Vaz">{fa(i)}</text></g>')
    for x in m["xs"]:
        a, b = T(x, m["tops"][0] - 30), T(x, (m["bottom"] or m["tops"][-1] + 250))
        s.append(f'<line x1="{a[0]}" y1="{a[1]}" x2="{b[0]}" y2="{b[1]}" stroke="#7FD3FF" stroke-width="1.6" stroke-opacity=".85"/>')
    yb = (m["bottom"] or m["tops"][-1] + 230)
    for (xa, xb), tv in zip(zip(m["xs"], m["xs"][1:]), treads):
        p = T((xa + xb) / 2, yb - 20)
        s.append(f'<text x="{p[0]}" y="{p[1]}" font-size="15" fill="#7FD3FF" text-anchor="middle" font-family="Vaz" font-weight="700" direction="ltr">{tv:.2f}G</text>')
    return "".join(s), G, treads, width, h


def page_v2r():
    sc = 0.62
    svg_c, G, tr, w, h = overlay_svg("R3c", sc, 150, 250)
    main = f"""<div style="position:absolute;top:118px;right:64px;width:{1050*sc:.0f}px;height:{1400*sc:.0f}px;border-radius:18px;overflow:hidden">
<div style="position:absolute;left:{-150*sc}px;top:{-250*sc}px;width:{1333*sc}px;height:{2000*sc}px;background:url('{uri(RV/'R3c.jpg')}') 0 0/100% 100%"></div>
<svg width="{1050*sc:.0f}" height="{1400*sc:.0f}" style="position:absolute;left:0;top:0;direction:ltr">{svg_c}</svg>
<div style="position:absolute;right:12px;top:10px" class="tag">R3c · <span class="ltr">G ≈ {G:.0f}px</span></div></div>"""
    thumbs = []
    for k, (x0, y0, x1, y1) in (("R1", (150, 200, 1250, 1400)), ("R3b", (330, 420, 1130, 1220))):
        sc2 = 300 / (x1 - x0)
        sv, G2, tr2, w2, h2 = overlay_svg(k, sc2, x0, y0)
        src = CC / "lam_r_front_noface_01_v1_cc.png" if k == "R1" else RV / f"{k}.jpg"
        thumbs.append(f"""<div><div style="position:relative;width:300px;height:{(y1-y0)*sc2:.0f}px;border-radius:14px;overflow:hidden">
<div style="position:absolute;left:{-x0*sc2}px;top:{-y0*sc2}px;width:{1333*sc2}px;height:{2000*sc2}px;background:url('{uri(src)}') 0 0/100% 100%"></div>
<svg width="300" height="{(y1-y0)*sc2:.0f}" style="position:absolute;left:0;top:0;direction:ltr">{sv}</svg></div>
<div style="font-size:14px;margin-top:4px"><b>{k}</b> · {MEAS[k]['note']}</div></div>""")
    rows = []
    for k in ("R3c", "R1", "R3b", "R3a"):
        G_, t_, w_, h_ = stats(k)
        tt = " / ".join(f"{v:.2f}" for v in t_)
        rows.append(f"<tr><td class='ltr'><b>{k}</b></td><td>{len(MEAS[k]['tops'])}</td><td class='ltr'>{tt}</td><td class='ltr'>{w_:.2f}G</td><td class='ltr'>{('%.2f' % (w_/h_)) if h_ else '≈0.9*'}</td></tr>")
    rows.append("<tr style='color:#F08A80'><td>شیت (8:7)</td><td>۴</td><td class='ltr'>2 / 2 / 2 / 2</td><td class='ltr'>8G</td><td class='ltr'>1.14</td></tr>")
    rows.append(f"<tr style='color:{GOLD}'><td><b>پیشنهاد v2-R</b></td><td>۴</td><td class='ltr'>2.4 / 0.7 / 0.7 / 0.7</td><td class='ltr'>4.5G</td><td class='ltr'>0.92</td></tr>")
    table = ("<table style='width:100%;border-collapse:collapse;font-size:15px;margin-top:6px'>"
             "<tr style='color:#AEB4C2;font-size:13px'><td>رندر</td><td>پله‌ی دیده‌شده</td><td>پهنای پله‌ها (G)</td><td>پهنا</td><td>پهنا:ارتفاع</td></tr>"
             + "".join(rows) + "</table>")
    body = f"""{main}
<div style="position:absolute;top:118px;right:{64+1050*sc+28:.0f}px;display:flex;flex-direction:column;gap:14px">{''.join(thumbs)}</div>
<div class="card" style="position:absolute;top:118px;left:64px;width:640px;height:858px;padding:20px 24px">
<h3>قفل شد: فرم روی رندرها (v2-R)، نه ۸:۷</h3>
<p>در هر ۵ رندر وحید، ابزار تصویر یک الگوی ثابت ساخته: <b>پله‌ی ۱ یک «دیوار» پهن</b> (۱٫۴ تا ۲٫۵G) و سه پله‌ی باریک بعدی، با ارتفاع پله‌های تقریباً برابر. هیچ‌کدام به ۸:۷ با پله‌های ۲G نزدیک نیست؛ ولی با هم تا حدود ±۱۵٪ سازگارند.</p>
<style>td{{padding:5px 6px;border-bottom:1px solid rgba(255,255,255,.07)}}</style>{table}
<p style="font-size:12px;color:#8790A6">* پایین بدن در R3c زیر دست‌ها پنهان است؛ ارتفاع برآوردی. R3a فقط ۳ پله نشان می‌دهد.</p>
<p style="margin-top:8px"><b style="color:{GOLD}">v2-R:</b> ۴ پله‌ی هم‌ارتفاع (۱G)، پله‌ی ۱ = <span class="ltr">2.4G</span>، بقیه <span class="ltr">0.7G</span>، پهنا <span class="ltr">4.5G</span> : ارتفاع <span class="ltr">4.9G</span> (تقریباً مربع). قانون «پهن، نه ستون» می‌شود: <b>پهنا:ارتفاع ≥ ۰٫۸۵</b>. R1 با ۰٫۸۲ مرزی است.</p>
<p style="margin-top:6px"><b>صورت:</b> کامل روی دیوار پله‌ی ۱؛ چشم <span class="ltr">Ø0.9G</span> (~۲۰٪ پهنای بدن)، مرکز چشم <span class="ltr">1.5G</span> زیر سقف پله‌ی ۱. این همان تناقض ابرو/پله‌ی ۲ مشخصات را هم حل می‌کند.</p>
<p style="margin-top:6px;color:#C3C8D3">چرا: رندرها همین الان دارایی تولیدند؛ اجبار ابزار به ۸:۷ یعنی رندرگیری دوباره و احتمال ناهمخوانی. ۸:۷ برای P2 (مدل سه‌بعدی واقعی یا طراح) نگه داشته شود.</p>
<div style="margin-top:10px"><span class="tag">قفل‌شده · تأیید وحید ۱۱ آبان ۱۴۰۵</span></div></div>"""
    return page("P1·03", "قفل فرم v2-R (قفل‌شده)", "Form lock · LOCKED on Vahid renders (R3c master)", body,
                "G = میانگین ارتفاع پله در هر رندر · خط‌چین سفید = سقف پله‌ها · آبی = مرز پله‌ها")


if __name__ == "__main__":
    grid_png()
    render_page(page_v2r(), OUT / "page_v2r.png")
    for k in MEAS:
        print(k, stats(k))
