"""Trial «لَم و ۷ تا کتاب» (Wed 27 Aban 1405, 21:00 · never shared to the profile).
Plate A = Flow clip 419192a7 @0 s (faceless + kit) · clip 0→jump (wobble + fall, a bit faster) · whip-cut over Flow's jump
· clip after the jump → 7.16 s (holding the pink book) · Plate B = clip @7.16 s (faceless + kit).
  L1 «هفت تا کتاب! برای چالش!»     proud, ×۷ pill
  L2 «از یکشنبه شروع می‌کنم.»       confident smirk
  P1 «یکشنبه، اول آذره. شروع چالش.» eyes to the calendar, gold circle «یکشنبه ۱ آذر»
  (beat)                            eyes dart
  L3 «…پس یکشنبه‌ی بعدش.»          nervous grin → clip (books fall)
  P2 «یکی کافیه، لَم. شبی ده صفحه.» Lam holding one book
  L4 «…این یکی سبکه.»               sheepish, looks at the book
  P3 «هر دوشنبه یه قسمت تازه از لَم. فالو کن.»  CTA
Output: trial_books/lam_trial_books.mp4 (+ _upload), _build/check.jpg, timeline.json
"""
from pathlib import Path
import copy, json, subprocess, wave
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
import lam_facekit as K
from render_util import html_to_png, FONT
from gold_step import ding_wav

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
W0 = MASCOT.parent
EP = MASCOT / "trial_books"
B = EP / "_build"
B.mkdir(exist_ok=True)
FF = imageio_ffmpeg.get_ffmpeg_exe()
FPS, SR = 30, 44100
GOLD, CREAM = "#C9A227", "#F3F0E8"
TEMPO = 1.05
TARGET_I = -14.0


def load(p, sr=SR):
    raw = subprocess.run([FF, "-v", "quiet", "-i", str(p), "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768


def fade(x, ms=15):
    n = int(SR * ms / 1000); x = x.copy()
    x[:n] *= np.linspace(0, 1, n); x[-n:] *= np.linspace(1, 0, n)
    return x


def tempo(y, f):
    out = subprocess.run([FF, "-v", "quiet", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "-", "-af", f"atempo={f}", "-f", "f32le", "-"],
                         input=y.astype(np.float32).tobytes(), capture_output=True).stdout
    return np.frombuffer(out, np.float32).copy()


lam = load(EP / "lam.mp3")
pel = load(EP / "peleh.mp3")
pel = pel * (np.sqrt(np.mean(lam[np.abs(lam) > .02] ** 2)) / np.sqrt(np.mean(pel[np.abs(pel) > .02] ** 2)))

# ---------------------------------------------------------------- clip: find Flow's jump (largest frame difference 4.5–5.3 s)
raw = subprocess.run([FF, "-v", "quiet", "-i", str(EP / "flow_clip.mp4"), "-vf", "scale=1116:1984:flags=lanczos,pad=1116:2000:0:8,scale=1080:1935,crop=1080:1920:0:7",
                      "-an", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
CLIP = np.frombuffer(raw, np.uint8).reshape(-1, 1920, 1080, 3)
CN, CFPS = len(CLIP), 24.0
small = [cv2.resize(CLIP[i], (108, 192)).astype(np.float32) for i in range(CN)]
dif = [np.abs(small[i + 1] - small[i]).mean() for i in range(CN - 1)]
# Lam catches the pink book in the air (4.81–4.88 s), then Flow punches the camera in between 4.88 and 4.92 s:
# the whip-cut sits exactly on that re-framing (checked frame by frame).
JUMP = 118                                                 # first frame after the camera punch-in (4.917 s)
B_SRC = int(round(7.16 * CFPS))
SPEED1 = 1.12                                              # wobble + fall a little faster
SEG1 = JUMP / CFPS / SPEED1                                # output seconds of part 1
WHIP = 0.24
SEG2 = (B_SRC - JUMP) / CFPS
CLIP_LEN = SEG1 + SEG2
print("jump at clip frame", JUMP, round(JUMP / CFPS, 2), "diff", round(dif[JUMP - 1], 1), "median", round(float(np.median(dif)), 1))

ITEMS = [("L1", "L", 0.04, 3.48, 0.15),
         ("L2", "L", 4.50, 6.58, 0.22),
         ("P1", "P", 0.08, 4.22, 0.14),
         ("L3", "L", 7.86, 10.58, 0.50),       # 0.5 s eye-dart beat before «پس…»
         ("P2", "P", 5.28, 9.30, None),        # starts right after the whip-cut (Lam holding one book)
         ("L4", "L", 11.10, 12.74, 0.25),
         ("P3", "P", 10.10, 14.06, 0.35)]
CUTS = {"L1": [(1.55, 1.92)], "P1": [(2.66, 2.96)]}
XF = int(0.012 * SR)


def cut_take(src, key, a, b):
    pieces, p0 = [], a
    for c0, c1 in CUTS.get(key, []) + [(b, b)]:
        pieces.append(src[int(p0 * SR):int(c0 * SR)].copy()); p0 = c1
    y0 = pieces[0]
    for pc in pieces[1:]:
        r = np.linspace(0, 1, XF, dtype=np.float32)
        y0 = np.concatenate([y0[:-XF], y0[-XF:] * (1 - r) + pc[:XF] * r, pc[XF:]])
    return fade(tempo(fade(y0), TEMPO))


segs, t = {}, 0.0
for key, spk, a, b, gap in ITEMS:
    y = cut_take(lam if spk == "L" else pel, key, a, b)
    if key == "P2":
        t = segs["L3"][1] + 0.10 + SEG1 + 0.15
    else:
        t += gap
    segs[key] = (t, t + len(y) / SR, y, spk, a)
    t += len(y) / SR
S_ = lambda k: segs[k][0]
E_ = lambda k: segs[k][1]


def to_out(key, ts):
    rm = 0.0
    for c0, c1 in CUTS.get(key, []):
        if ts >= c1:
            rm += c1 - c0
        elif ts > c0:
            rm += ts - c0
    return segs[key][0] + (ts - segs[key][4] - rm) / TEMPO


T_CLIP = E_("L3") + 0.10
T_JUMP = T_CLIP + SEG1
T_B = T_CLIP + CLIP_LEN
if S_("L4") < max(E_("P2"), T_B) + 0.2:                     # keep L4 after P2 and after the clip
    raise SystemExit("timeline overlap")
T_CTA = S_("P3") - 0.05
TAIL = 1.7
DUR = E_("P3") + TAIL
N = int(round(DUR * FPS)); NS = int(DUR * SR) + SR
lam_tr, pel_tr = np.zeros(NS, np.float32), np.zeros(NS, np.float32)
for key, (a, b, y, spk, _) in segs.items():
    tr = lam_tr if spk == "L" else pel_tr
    i = int(a * SR); tr[i:i + len(y)] += y[:max(0, min(len(y), NS - i))]
print({k: (round(v[0], 2), round(v[1], 2)) for k, v in segs.items()}, "clip", round(T_CLIP, 2), round(T_JUMP, 2), round(T_B, 2), "DUR", round(DUR, 2))

# ---------------------------------------------------------------- visemes (source seconds of Vahid's take)
M, T, L_, FV = "A_MBP", "B_SSH", "H_L", "G_FV"
AA, E, I, U, O = "D_AA", "C_E", "EE_wide", "F_OO", "E_O"
RUNS = {
    "L1": [((0.09, 1.43), [(None, E, FV), (T, AA, None), (T, E, None), (T, AA, M)]),          # هَف تا کِ تاب
           ((2.07, 3.42), [(M, E, None), (L_, AA, None), (T, AA, L_), (None, E, T)])],         # بَ را چا لِش
    "L2": [((4.60, 5.00), [(None, E, T)]),                                                     # اَز
           ((5.09, 6.51), [(None, E, T), (T, E, M), (M, E, None), (T, O, None), (L_, U, None), (M, I, None), (T, O, M)])],  # یِک شَم بِه شُ رو می کُنم
    "L3": [((8.23, 8.56), [(M, E, T)]),                                                        # پَس
           ((8.92, 10.51), [(None, E, T), (T, E, M), (M, E, None), (None, I, None), (M, E, None), (T, E, T)])],  # یِک شَم بِه یِ بَع دِش
    "L4": [((11.20, 11.70), [(None, I, L_), (None, E, T)]),                                    # این یِ
           ((11.74, 12.67), [(T, I, None), (T, E, M), (T, U, None), (T, E, None)])],           # کی سَ بُ که
}
WEIGHT = {AA: 1.35, U: 1.3, I: 1.25, O: 1.1, E: 1.0}
vis = ["X"] * N


def put(t0, t1, v):
    k0, k1 = int(round(t0 * FPS)), int(round(t1 * FPS))
    for k in range(max(0, k0), min(N, max(k1, k0 + 2))):
        vis[k] = v


for key, runs in RUNS.items():
    for (a, b), syl in runs:
        w = np.array([WEIGHT[s[1]] + (0.35 if s[0] else 0) + (0.3 if s[2] else 0) for s in syl])
        edges = a + (b - a) * np.concatenate([[0], np.cumsum(w) / w.sum()])
        for (on, vw, co), s0, s1 in zip(syl, edges[:-1], edges[1:]):
            d = s1 - s0
            p0 = s0 + (0.24 * d if on else 0)
            p1 = s1 - (0.22 * d if co else 0)
            if on:
                put(to_out(key, s0), to_out(key, p0), on)
            put(to_out(key, p0), to_out(key, p1), vw)
            if co:
                put(to_out(key, p1), to_out(key, s1), co)
vis = vis[1:] + ["X"]

# ---------------------------------------------------------------- plates + kit layers
S = 1080 / 1116
HS = round(2000 * S)
CROP = (HS - 1920) // 2


def to1080(a):
    a = cv2.resize(a, (1080, HS), interpolation=cv2.INTER_AREA)
    return a[CROP:CROP + 1920]


PL = {
    "A": dict(img="lam_ep4_A_faceless.png", soft=1.25,
              G=dict(R=60, eyeL=(555, 785), eyeR=(681, 785), browL=(553, 651), browR=(678, 646), mouth=(621, 882), ms=1.08)),
    "B": dict(img="lam_ep4_B_faceless.png", soft=1.35,
              G=dict(R=90, eyeL=(556, 713), eyeR=(744, 713), browL=(545, 578), browR=(725, 566), mouth=(653, 840), ms=1.12)),
}
GRADE = np.array((0.86, 0.84, 0.88))
NAVY_L = 0.299 * 0x1B + 0.587 * 0x2A + 0.114 * 0x4A
X = lambda eL, eR, bL, bR: dict(eyeL=eL, eyeR=eR, browL=bL, browR=bR, mouth=("none", False))
K.EXPR.update({
    "t_proud":   X((0.06, 0, 0, (0.05, 0.0), 1.05, True), (0.06, 0, 0, (0.05, 0.0), 1.05, True), ("up", -0.10), ("up", -0.12)),
    "t_smug":    X((0.42, -4, 0, (0.10, 0.04), 1, False), (0.32, 4, 0, (0.10, 0.04), 1, False), ("base", 0.02), ("up", -0.12)),
    "t_listen":  X((0.12, 0, 0, (-0.25, -0.25), 1, False), (0.12, 0, 0, (-0.25, -0.25), 1, False), ("soft", -0.04), ("up", -0.04)),
    "t_cal":     X((0.04, 0, 0, (-0.60, -0.05), 0.92, False), (0.04, 0, 0, (-0.60, -0.05), 0.92, False), ("up", -0.10), ("up", -0.10)),
    "t_dartL":   X((0.06, 0, 0, (-0.55, 0.05), 0.9, False), (0.06, 0, 0, (-0.55, 0.05), 0.9, False), ("worried", 0.0), ("worried", 0.0)),
    "t_dartR":   X((0.06, 0, 0, (0.55, 0.05), 0.9, False), (0.06, 0, 0, (0.55, 0.05), 0.9, False), ("worried", 0.0), ("worried", 0.0)),
    "t_nervous": X((0.16, 0, 0, (0.15, 0.0), 0.95, False), (0.16, 0, 0, (0.15, 0.0), 0.95, False), ("worried", -0.04), ("worried", -0.04)),
    "t_book":    X((0.34, 0, 0, (0.0, 0.50), 1, False), (0.34, 0, 0, (0.0, 0.50), 1, False), ("soft", 0.0), ("soft", 0.0)),
    "t_sheep":   X((0.46, -2, 0, (0.05, 0.42), 1, False), (0.44, 2, 0, (0.05, 0.42), 1, False), ("worried", 0.02), ("soft", 0.0)),
    "t_smile":   X((0.20, 0, 0, (0.10, 0.10), 1.02, True), (0.20, 0, 0, (0.10, 0.10), 1.02, True), ("soft", -0.04), ("soft", -0.06)),
})
EXS = {"A": ["t_proud", "t_smug", "t_listen", "t_cal", "t_dartL", "t_dartR", "t_nervous"],
       "B": ["t_book", "t_sheep", "t_smile"]}
RESTS = ["hmm", "forced", "smile_soft", "smirk_wide", "o_small"]


def render_svg(inner, name, W, H):
    p = B / f"_{name}.png"
    html_to_png("<!doctype html><style>html,body{margin:0;background:transparent}</style>" + K.svg_doc(inner, W, H, (0, 0, W, H)), p, W, H)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def build_layers(pk):
    P = PL[pk]; G = P["G"]
    plate0 = cv2.imread(str(EP / P["img"]))[:, :, ::-1].astype(np.float32)
    H0, W0p = plate0.shape[:2]
    LOCAL = cv2.GaussianBlur(plate0, (0, 0), 22)
    soft = P["soft"]

    def grade(lay, seed=1):
        rgb, a = lay[..., :3].copy(), lay[..., 3]
        lum = rgb @ np.array([0.299, 0.587, 0.114])
        nv = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] + 8) & (lum < 150)).astype(np.float32), (0, 0), 0.8)[..., None]
        ratio = np.clip(lum / NAVY_L, 0.45, 1.30)[..., None]
        rgb = rgb * (1 - nv) + np.clip(LOCAL * ratio, 0, 255) * nv
        rgb = cv2.GaussianBlur(rgb * GRADE, (0, 0), soft) + np.random.default_rng(seed).normal(0, 2.0, rgb.shape[:2])[..., None]
        return np.dstack([np.clip(rgb, 0, 255), cv2.GaussianBlur(a, (0, 0), soft * 0.85)])

    def face_inner(ex, closed=False):
        saved = copy.deepcopy(K.EXPR[ex]); e = K.EXPR[ex]
        if closed:
            for side in ("eyeL", "eyeR"):
                l = list(e[side]); l[0], l[2] = 0.97, 0.0; e[side] = tuple(l)
        R = G["R"]; u = lambda p: (p[0] / R, p[1] / R)
        inner = K.face(R, ex, eyeL=u(G["eyeL"]), eyeR=u(G["eyeR"]), browL=u(G["browL"]), browR=u(G["browR"]), mouthc=u(G["mouth"]), mscale=G["ms"])
        K.EXPR[ex] = saved
        return inner

    cache = B / f"layers_{pk}.npz"
    if cache.exists():
        Lr = dict(np.load(cache))
    else:
        Lr = {}
        for ex in EXS[pk]:
            Lr[f"face_{ex}"] = np.clip(to1080(grade(render_svg(face_inner(ex), f"{pk}_{ex}", W0p, H0))), 0, 255).astype(np.uint8)
            Lr[f"blink_{ex}"] = np.clip(to1080(grade(render_svg(face_inner(ex, True), f"{pk}_{ex}_b", W0p, H0))), 0, 255).astype(np.uint8)
        R = G["R"]
        for m in K.MOUTHS:
            inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth(R, m, False, G["ms"])}</g>'
            Lr[f"m_{m}"] = np.clip(to1080(grade(render_svg(inner, f"{pk}_m_{m}", W0p, H0), 3)), 0, 255).astype(np.uint8)
        for kind in RESTS:
            inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth_for_expr(R, (kind, False), G["ms"])}</g>'
            Lr[f"rest_{kind}"] = np.clip(to1080(grade(render_svg(inner, f"{pk}_r_{kind}", W0p, H0), 3)), 0, 255).astype(np.uint8)
        np.savez(cache, **Lr)
    return to1080(plate0), Lr


PLATE_A, LA = build_layers("A")
PLATE_B, LB = build_layers("B")


def over(img, rgba, a=1.0):
    rgba = rgba.astype(np.float32); al = rgba[..., 3:] / 255 * a
    return img * (1 - al) + rgba[..., :3] * al


# ---------------------------------------------------------------- acting
W_ = lambda key, ts: to_out(key, ts)
T_CAL = W_("P1", 0.30)


def act(t):
    if t < S_("L2") - 0.05:
        return "A", "t_proud", "smile_soft"
    if t < S_("P1") - 0.05:
        return "A", "t_smug", "smirk_wide"
    if t < T_CAL + 0.25:
        return "A", "t_listen", "o_small"
    if t < E_("P1") + 0.05:
        return "A", "t_cal", "o_small"
    if t < S_("L3") - 0.02:
        u = (t - E_("P1") - 0.05) / max(0.05, S_("L3") - E_("P1") - 0.07)
        return "A", ("t_dartL" if u < 0.4 else "t_dartR"), "forced"
    if t < T_CLIP:
        return "A", "t_nervous", "forced"
    if t < S_("L4") - 0.05:
        return "B", "t_book", "hmm"
    if t < E_("L4") + 0.15:
        return "B", "t_sheep", "smile_soft"
    return "B", "t_smile", "smile_soft"


BLINKS = [S_("L1") + 1.6, S_("L2") + 0.9, E_("L3") - 0.25 if False else S_("L3") + 1.4, T_B + 0.5, S_("P3") + 1.4, S_("P3") + 3.4]
blink_frames = {int(bt * FPS) + i for bt in BLINKS for i in range(3)}


def face_frame(k, t):
    pk, ex, rest = act(t)
    plate, Lr = (PLATE_A, LA) if pk == "A" else (PLATE_B, LB)
    img = over(plate, Lr[("blink_" if k in blink_frames else "face_") + ex])
    v = vis[k]
    img = over(img, Lr[f"rest_{rest}"] if v == "X" else Lr[f"m_{v}"])
    return img, pk


def clip_at(t):
    """frame of the Flow clip for output time t (T_CLIP <= t < T_B)."""
    u = t - T_CLIP
    if u < SEG1:
        return CLIP[min(JUMP - 1, int(u * SPEED1 * CFPS))].astype(np.float32)
    return CLIP[min(B_SRC, JUMP + int((u - SEG1) * CFPS))].astype(np.float32)


def cam(img, z, fx, fy):
    cw, ch = 1080 / z, 1920 / z
    x0 = float(np.clip(fx - cw / 2, 0, 1080 - cw)); y0 = float(np.clip(fy - ch / 2, 0, 1920 - ch))
    Mx = np.float32([[z, 0, -x0 * z], [0, z, -y0 * z]])
    out = cv2.warpAffine(img, Mx, (1080, 1920), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
    if z > 1.25:
        out = out + 0.3 * (out - cv2.GaussianBlur(out, (0, 0), 1.2))
    return out


def zoom_blur(img, amount):
    """radial zoom blur (whip) — average of a few scaled copies."""
    acc = np.zeros_like(img)
    n = 6
    for i in range(n):
        z = 1 + amount * i / (n - 1)
        acc += cam(img, z, 540, 900)
    return acc / n


FACE_A = (618 * S, 800 * S - CROP)
CAL = (int(125 * S), int(770 * S) - CROP)
SHOTS = [(0.0, S_("P1") - 0.05, 1.00, 1.06, 560, 960),                          # wide: Lam + the stack
         (S_("P1") - 0.05, S_("L3") - 0.04, 1.10, 1.14, 420, 900),              # calendar in frame
         (S_("L3") - 0.04, T_CLIP, 1.42, 1.52, FACE_A[0], FACE_A[1])]           # punch-in: «…پس یکشنبه‌ی بعدش»
SHOT_B = (T_B, DUR, 1.00, 1.05, 560, 860)

hop = SR // FPS
lr = np.array([np.sqrt((lam_tr[k * hop:(k + 1) * hop] ** 2).mean() + 1e-12) for k in range(N)])
lr = np.convolve(lr, np.ones(4) / 4, "same"); BOB = np.clip(lr / (np.percentile(lr[lr > 0.005], 95) + 1e-6), 0, 1)

# ---------------------------------------------------------------- overlays
CSS = (f"@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}"
       "html,body{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}body{font-family:Vaz;direction:rtl}")


def ov(name, body):
    p = B / f"ov_{name}.png"
    html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style>{body}", p, 1080, 1920)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def sub(text, color):
    return (f"<div style='position:absolute;left:50px;right:50px;top:1460px;text-align:center'><span style='display:inline-block;"
            f"background:rgba(14,22,40,.76);border-radius:22px;padding:10px 30px;font-size:56px;font-weight:700;line-height:1.35;color:{color}'>{text}</span></div>")


ICON = (W0 / "app_ref" / "icon-512.png").as_uri()
OV = {
    "label": ov("label", f"<div style='position:absolute;right:46px;top:200px;background:rgba(14,22,40,.72);border:2px solid rgba(201,162,39,.7);"
                         f"border-radius:20px;padding:6px 22px;font-size:38px;font-weight:900;color:{GOLD}'>لَم</div>"),
    "hook": ov("hook", f"<div style='position:absolute;left:60px;right:60px;top:300px;text-align:center'><div style='display:inline-block;"
                       f"background:rgba(14,22,40,.84);border:2px solid rgba(201,162,39,.6);border-radius:28px;padding:20px 44px;font-size:76px;"
                       f"font-weight:800;color:{CREAM}'>لَم برای چالش <span style='color:{GOLD}'>آماده‌ست</span> 📚</div></div>"),
    "x7": ov("x7", f"<div style='position:absolute;left:0;right:0;top:470px;text-align:center'><div style='display:inline-block;background:{GOLD};"
                   f"border-radius:999px;padding:12px 40px;font-size:66px;font-weight:900;color:#1B2A4A;box-shadow:0 10px 40px rgba(0,0,0,.45)'>📚 ×۷</div></div>"),
    "cal": ov("cal", f"<div style='position:absolute;left:{CAL[0] - 34}px;top:{CAL[1] - 34}px;width:68px;height:68px;border-radius:50%;"
                     f"border:6px solid {GOLD};box-shadow:0 0 20px rgba(201,162,39,.85)'></div>"
                     f"<div style='position:absolute;left:{max(10, CAL[0] - 60)}px;top:{CAL[1] - 120}px;background:{GOLD};color:#1B2A4A;border-radius:14px;"
                     f"padding:4px 14px;font-size:36px;font-weight:900;white-space:nowrap;direction:rtl'>یکشنبه <span style='display:inline-block;margin:0 6px'>۱</span> آذر</div>"),
    "L1": ov("L1", sub("هفت تا کتاب! برای چالش!", CREAM)),
    "L2": ov("L2", sub("از یکشنبه شروع می‌کنم.", CREAM)),
    "P1": ov("P1", sub("یکشنبه، اول آذره. شروع چالش.", GOLD)),
    "L3": ov("L3", sub("…پس یکشنبه‌ی بعدش.", CREAM)),
    "P2": ov("P2", sub("یکی کافیه، لَم. شبی ده صفحه.", GOLD)),
    "L4": ov("L4", sub("…این یکی سبکه.", CREAM)),
    "cta": ov("cta", f"<div style='position:absolute;left:50px;right:50px;top:270px;text-align:center'><div style='display:inline-block;"
                     f"background:rgba(14,22,40,.88);border:2px solid rgba(201,162,39,.7);border-radius:30px;padding:22px 40px'>"
                     f"<div style='font-size:58px;font-weight:800;color:{CREAM};line-height:1.4'>هر <span style='color:{GOLD}'>دوشنبه</span> یه قسمت تازه از لَم</div>"
                     f"<div style='font-size:46px;font-weight:900;color:{GOLD};margin-top:8px'>فالو کن که جا نمونی 👇</div></div></div>"
                     f"<div style='position:absolute;left:0;right:0;top:1660px;text-align:center'><div style='display:inline-flex;align-items:center;gap:18px;"
                     f"background:rgba(14,22,40,.80);border-radius:26px;padding:12px 28px 12px 18px'><img src='{ICON}' style='width:80px;height:80px;"
                     f"border-radius:20px;box-shadow:0 0 0 2px {GOLD}'><span style='font-size:48px;font-weight:800;color:{CREAM}'>پله · چالش ۳۰ شب کتاب</span></div></div>"),
}
T_X7 = W_("L1", 0.75)


def pop(img, layer, t0, t, a=1.0, sc=0.18, cx=540, cy=500):
    if t - t0 < 0.3:
        s_ = 1 + sc * np.exp(-((t - t0 - 0.08) / 0.09) ** 2)
        layer = cv2.warpAffine(layer, cv2.getRotationMatrix2D((cx, cy), 0, s_), (1080, 1920), borderValue=(0, 0, 0, 0))
    return over(img, layer, a)


# ---------------------------------------------------------------- render
enc = subprocess.Popen([FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", str(B / "video.mp4")], stdin=subprocess.PIPE)
LAST_A = None
for k in range(N):
    t = k / FPS
    if T_CLIP <= t < T_B:
        img = clip_at(t)                      # hard cut from the punch-in to the wide clip (a crossfade doubled Lam)
        dj = t - T_JUMP
        if -WHIP / 2 <= dj < WHIP / 2:                                  # whip-cut over Flow's jump: zoom blur + slight shake + flash
            w = 1 - abs(dj) / (WHIP / 2)
            img = zoom_blur(img, 0.10 * w)
            img = img + 60 * w
            img = cam(img, 1.0 + 0.03 * w, 540 + 14 * np.sin(k * 2.7) * w, 960 + 10 * np.cos(k * 3.1) * w)
        else:
            img = cam(img, 1.0, 540, 960)
    else:
        img, pk = face_frame(k, t)
        if pk == "B" and t - T_B < 0.15:
            x = (t - T_B) / 0.15
            img = img * x + CLIP[B_SRC].astype(np.float32) * (1 - x)
        sh = next((s for s in SHOTS if s[0] <= t < s[1]), SHOTS[-1]) if pk == "A" else SHOT_B
        uu = np.clip((t - sh[0]) / max(1e-3, sh[1] - sh[0]), 0, 1)
        z = sh[2] + (sh[3] - sh[2]) * uu + 0.007 * BOB[k]
        if pk == "A" and S_("P1") - 0.05 <= t < S_("L3") - 0.04 and t >= T_CAL:     # gold circle lives on the plate (moves with the camera)
            a_ = np.clip(min((t - T_CAL) / 0.12, (S_("L3") - 0.04 - t) / 0.15), 0, 1)
            img = pop(img, OV["cal"], T_CAL, t, a=a_, sc=0.3, cx=CAL[0], cy=CAL[1])
        img = cam(img, z, sh[4], sh[5] - 4 * BOB[k])
        if pk == "A" and abs(t - (S_("L3") - 0.04)) < 0.12:                        # tiny punch shake on the cut-in
            img = cam(img, 1.0, 540 + 6 * np.sin(k * 3), 960)
        if pk == "A":
            LAST_A = img
    img = over(img, OV["label"])
    if t < S_("L2") - 0.1:
        img = over(img, OV["hook"], np.clip((S_("L2") - 0.1 - t) / 0.25, 0, 1))
    if T_X7 <= t < S_("L2") + 0.3:
        img = pop(img, OV["x7"], T_X7, t, a=np.clip((S_("L2") + 0.3 - t) / 0.25, 0, 1), cy=520)
    for key in ("L1", "L2", "P1", "L3", "P2", "L4"):
        if S_(key) - 0.05 <= t < E_(key) + 0.25:
            img = over(img, OV[key], np.clip(min((t - S_(key) + 0.05) / 0.12, (E_(key) + 0.25 - t) / 0.15), 0, 1))
    if t >= T_CTA:
        img = over(img, OV["cta"], np.clip((t - T_CTA) / 0.25, 0, 1))
    if t > DUR - 0.35:
        img = img * (1 - (t - (DUR - 0.35)) / 0.35 * 0.45)
    enc.stdin.write(np.clip(img, 0, 255).astype(np.uint8).tobytes())
enc.stdin.close(); enc.wait()

# ---------------------------------------------------------------- audio
mus = load(W0 / "reel_d010" / "music_leberch_reading.mp3")
mus = mus[int(100.0 * SR):int(100.0 * SR) + NS]; mus = np.pad(mus, (0, max(0, NS - len(mus))))
voice = lam_tr + pel_tr
actv = np.convolve((np.abs(voice) > 0.01).astype(np.float32), np.ones(int(0.25 * SR)) / int(0.25 * SR), "same") > 0.02
duck = np.convolve(np.where(actv, 0.09, 0.20).astype(np.float32), np.ones(int(0.3 * SR)) / int(0.3 * SR), "same")
tt = np.arange(NS) / SR
duck *= np.clip(tt / 0.4, 0, 1) * np.clip((DUR - tt) / 0.7, 0, 1)
mix = voice + mus * duck


def add(x, at, g):
    i = int(at * SR)
    if 0 <= i < NS:
        n = max(0, min(len(x), NS - i)); mix[i:i + n] += x[:n] * g


def thud(f0=95, d=0.22, seed=0):
    n = int(d * SR); tt_ = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    body = np.sin(2 * np.pi * (f0 + 40 * np.exp(-tt_ * 30)) * tt_) * np.exp(-tt_ * 18)
    noise = cv2.GaussianBlur(rng.normal(0, 1, (n, 1)).astype(np.float32), (1, 0), 3).ravel() * np.exp(-tt_ * 40) * 0.5
    return (body + noise).astype(np.float32)


wh = load(W0 / "reel_d013" / "_build" / "sfx_whoosh.wav")
add(wh, SHOTS[2][0] - 0.06, 0.08)
add(wh, T_JUMP - 0.12, 0.12)
for i, dt in enumerate((-0.42, -0.30, -0.21, -0.12, -0.05, 0.02, 0.08)):      # 7 books hitting the floor around the jump
    add(thud(85 + 9 * i, seed=i), T_JUMP + dt, 0.55 - 0.03 * i)
ding_wav(B / "ding.wav", at=0.0, total=2.0, sr=SR)
dg = load(B / "ding.wav")
add(dg[:int(0.6 * SR)], T_X7, 0.22)
add(dg[:int(0.6 * SR)], T_CAL, 0.20)
add(dg, T_CTA + 0.05, 0.5)
mix = mix[:int(DUR * SR)]; mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
with wave.open(str(B / "mix.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype(np.int16).tobytes())


def lufs(path):
    e = subprocess.run([FF, "-hide_banner", "-i", str(path), "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    s_ = e[e.rindex("Summary:"):]
    return float(s_.split("I:")[1].split("LUFS")[0]), float(s_.split("Peak:")[1].split("dBFS")[0])


I0, _ = lufs(B / "mix.wav"); gain = TARGET_I - I0
for _ in range(4):
    subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "mix.wav"), "-af", f"volume={gain:.2f}dB,alimiter=limit=0.84:attack=3:release=60:level=false,aresample=48000",
                    "-ac", "2", str(B / "mix_norm.wav")], check=True)
    I1, tp1 = lufs(B / "mix_norm.wav")
    if abs(I1 - TARGET_I) < 0.3:
        break
    gain += TARGET_I - I1
out = EP / "lam_trial_books.mp4"
subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "video.mp4"), "-i", str(B / "mix_norm.wav"), "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                "-shortest", "-movflags", "+faststart", str(out)], check=True)
subprocess.run([FF, "-y", "-v", "error", "-i", str(out), "-c:v", "libx264", "-preset", "slow", "-b:v", "2000k", "-maxrate", "2600k", "-bufsize", "5200k",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(EP / "lam_trial_books_upload.mp4")], check=True)
subprocess.run([FF, "-y", "-v", "error", "-i", str(out), "-vf", "fps=3,scale=216:384,tile=10x8", "-frames:v", "1", str(B / "check.jpg")], check=True)
json.dump({"segments": {k: [round(v[0], 3), round(v[1], 3)] for k, v in segs.items()}, "T_CLIP": T_CLIP, "T_JUMP": T_JUMP, "T_B": T_B, "T_CTA": T_CTA,
           "DUR": DUR, "jump_frame": JUMP, "loudness": {"input_I": I0, "out_I": I1, "out_TP": tp1}}, open(EP / "timeline.json", "w"), indent=1)
print("done", out, round(DUR, 2), "LUFS", I1)
