"""Copy the changed Lam app assets into the beta deploy bundle and bump LAM_ASSET_VER."""
from pathlib import Path
import re, shutil

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT.parent / "app_assets"
B = ROOT.parents[1] / "dev" / "batch_2026-11-03"
CHANGED = ["acc_L2_scarf", "acc_L3_badge", "sport_gym", "sport_volleyball", "sport_yoga",
           "steps_lit_L1", "steps_lit_L2", "steps_lit_L3", "steps_lit_L4"]
files = [(APP / f"webp{s}" / f"{n}.webp", Path(f"webp{s}") / f"{n}.webp") for n in CHANGED for s in (512, 256)]
files += [(APP / "anim" / "lam_anim_levelup_step.webp", Path("anim") / "lam_anim_levelup_step.webp"),
          (APP / "lam_app_anchors.json", Path("lam_app_anchors.json"))]

targets = [B / "deploy_beta" / "2b_lam_update" / "lam"]
for extra in (B / "patched_beta" / "lam", B / "test_site" / "lam"):
    if extra.exists():
        targets.append(extra)
for t in targets:
    for src, rel in files:
        (t / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, t / rel)
    print("copied", len(files), "->", t)

new_ver = None
for js in (B / "deploy_beta" / "1_web_root" / "peleh-beta.js", B / "patched_beta" / "peleh-beta.js"):
    s = js.read_text(encoding="utf-8")
    m = re.search(r'var LAM_ASSET_VER = "(\d+)";', s)
    old = m.group(1)
    new_ver = new_ver or (str(int(old) + 1) if old != "20261103" else "20261104")
    s = s.replace(m.group(0), f'var LAM_ASSET_VER = "{new_ver}";', 1)
    js.write_text(s, encoding="utf-8")
    print(js, old, "->", new_ver)
shutil.copy2(B / "deploy_beta" / "1_web_root" / "peleh-beta.js", B / "deploy_beta" / "2b_lam_update" / "peleh-beta.js")
test_js = B / "test_site" / "peleh-beta.js"
if test_js.exists():
    s = test_js.read_text(encoding="utf-8")
    s2 = re.sub(r'var LAM_ASSET_VER = "\d+";', f'var LAM_ASSET_VER = "{new_ver}";', s, count=1)
    if s2 != s:
        test_js.write_text(s2, encoding="utf-8"); print("test_site js bumped")
print("2b files:", sum(1 for p in (B / "deploy_beta" / "2b_lam_update").rglob("*") if p.is_file()))
