"""Final assembly of lam_sheet_v2_P1 (14 pages) after Vahid's renders arrived (R1, R3a, R3b, R3c, R4)."""
import re, sys
from PIL import Image
from common import *
import build_pages as BP
from build_pages import TMP, PAGES, KIT, assembled_eyes
from build_grid import spec_grid_page, overlay_pages, inconsist_page, fa
from build_v2r import page_v2r

RV = ROOT.parent / "renders_vahid"
CC = ROOT / "renders_cc"
ST = ROOT / "style_test"
FX = ROOT / "fx"


def crop(src, box, name, size=None):
    q = TMP / f"{name}.png"
    im = Image.open(src).convert("RGB").crop(box)
    if size:
        im = im.resize(size, Image.LANCZOS)
    im.save(q)
    return uri(q)


def cover():
    img = crop(ST / "vr_R3c_E01.png", (40, 160, 1300, 1420), "cov")
    html = BP.cover()
    html = html.replace(uri(REFD / "lam_beanbag_square_profile.jpg"), img).replace("center/112%", "center/100%")
    html = html.replace("تصویر: رندر فعلی پوف (مرجع حال‌وهوا، نه فرم بدن)", "تصویر: رندر R3c وحید + کیت صورت وکتوری (حالت E01) · تست هم‌سبکی")
    return html


def spec_page():
    html = spec_grid_page()
    old = html[html.index("<h3>رندر فعلی با این گرید نمی‌خواند</h3>"):]
    old = old[:old.index("</div>")]
    new = ("<h3>رندرهای وحید هم با ۸:۷ نمی‌خوانند</h3><p>در R1، R3a، R3b و R3c پله‌ی ۱ یک دیوار پهن است و بدن تقریباً مربع "
           "(پهنا:ارتفاع ≈ ۰٫۸۲ تا ۰٫۹۲). وحید <b>v2-R</b> را تأیید کرد (صفحه‌ی بعد)؛ این ۸:۷ فقط برای P2 می‌ماند.</p>")
    html = html.replace(old, new)
    html = html.replace("<span class=\"tag\">وضعیت: پیشنهاد قفل</span>", "<span class=\"tag grey\">منسوخ برای P1 · جایگزین: v2-R (قفل‌شده)</span>")
    html = html.replace("با تأیید وحید ثابت می‌شود؛ تا آن موقع رندر R1/R2 گرفته نشود.", "این صفحه همان مشخصات مشاور است، بدون تغییر عدد؛ برای مقایسه.")
    html = html.replace("قفل فرم و گرید تناسب", "گرید مشخصات (۸:۷)")
    return html


def style_page():
    items = [("vr_R3c_E01", (150, 330, 1000, 1130), "R3c · E01 طعنه‌زن"), ("vr_R3c_E09_planning", (150, 330, 1000, 1130), "R3c · E09 حسابگر (دفترچه)"),
             ("vr_R3a_E01_reading", (380, 560, 950, 1100), "R3a · E01 (نگاه به کتاب)"), ("vr_R3a_E04_excited", (380, 560, 950, 1100), "R3a · E04 ذوق‌زده"),
             ("vr_R3a_mouth_D_AA", (380, 560, 950, 1100), "R3a · دهان D «آ»"), ("vr_R3a_mouth_E_O", (380, 560, 950, 1100), "R3a · دهان E «اُ»"),
             ("vr_R3b_E05_phone", (360, 480, 930, 1020), "R3b · E05 غرغرو (گوشی)"), ("vr_R3b_E06_caught", (360, 480, 930, 1020), "R3b · E06 مچ‌گرفته")]
    tiles = []
    for n, box, lab in items:
        u = crop(ST / f"{n}.png", box, f"st2_{n}")
        tiles.append(f"""<div style="width:304px"><div style="width:304px;height:300px;border-radius:12px;background:url('{u}') center/cover"></div>
<div style="font-size:15px;margin-top:6px;font-weight:700">{lab}</div></div>""")
    old = crop(ST / "test_expr_E01.png", (330, 250, 700, 600), "st2_old")
    body = f"""
<div style="position:absolute;top:122px;right:64px;width:1280px;display:flex;flex-wrap:wrap;gap:26px 18px">{''.join(tiles)}</div>
<div class="card" style="position:absolute;top:122px;left:64px;width:470px;height:854px;padding:20px 24px">
 <h3>نتیجه‌ی تست روی رندرهای بی‌صورت (صادقانه)</h3>
 <p><b style="color:{GOLD}">کلی: هم‌سبک شد.</b> روی بدن بی‌صورت، پلک‌ها و لبه‌ی لب‌ها رنگ موضعی بدن را می‌گیرند (کد خودکار) و صورت «روی» خمیر می‌نشیند، نه مثل برچسب. خیلی بهتر از تست قبلی با inpaint.</p>
 <p style="margin-top:6px"><b style="color:{GOLD}">دهان‌ها و ابروها: خوب.</b> در اندازه‌ی گوشی جدا از رندر دیده نمی‌شوند.</p>
 <p style="margin-top:6px"><b style="color:#F0B5AE">ضعف باقی‌مانده:</b> در زوم ۱۰۰٪ هنوز معلوم است صورت وکتور است؛ در اندازه‌ی گوشی نه.</p>
 <p style="margin-top:6px"><b>جای صورت:</b> کامل روی دیوار پله‌ی ۱. مختصات هر رندر در <span class="ltr">style_test/face_placement_px.json</span>.</p>
 <h3 style="margin-top:14px">پیشنهاد</h3>
 <p>• مسیر «بدن سه‌بعدی بی‌صورت + کیت وکتوری» برای قسمت‌های ۰ تا ۳ <b>تأیید</b>.</p>
 <p>• دور صیقل انجام شد: پلک ضخیم‌تر با لبه‌ی نورگیر، سفیدی چشم گرم‌تر با سایه‌ی کاسه، چشم هلالی هم‌رنگ بدن.</p>
 <div style="display:flex;gap:12px;align-items:center;margin-top:12px"><div style="width:110px;height:104px;border-radius:10px;background:url('{old}') center/cover;flex:none"></div>
 <p style="font-size:14px;color:#AEB4C2">تست اول روی رندر قدیمی پوف با inpaint: چشم‌ها برچسبی‌تر؛ دیگر لازم نیست.</p></div>
 <div style="margin-top:10px"><span class="tag">تأیید برای تست · کیت صیقل‌خورده (پلک ضخیم، سفیدی گرم‌تر)</span></div>
</div>"""
    return page("P1·10", "تست هم‌سبکی: کیت وکتوری روی رندرهای وحید", "Style-match test on R3a · R3b · R3c", body,
                "درجه‌بندی صحنه + رنگ موضعی بدن برای پلک و لب · فایل‌ها: style_test/vr_*.png")


def fx_page():
    frames = sorted(FX.glob("_strip_R3c_*.png"))
    tiles = []
    for i, p in enumerate(frames):
        u = crop(p, (560, 380, 940, 920), f"fx2_{i}")
        tiles.append(f"""<div style="text-align:center"><div style="width:180px;height:256px;border-radius:12px;background:url('{u}') center/cover"></div>
<div class="ltr" style="font-size:12px;color:#AEB4C2;margin-top:4px">f{int(p.stem.split('_')[-1]) - 21:02d}/18</div></div>""")
    lit = crop(FX / "gold_step4_lit_R3c.png", (130, 250, 1230, 1550), "fx2_lit")
    msk = crop(FX / "step_masks_overlay_R3c.png", (130, 250, 1230, 1550), "fx2_msk")
    html = BP.fx_page()
    a = html.index('<div style="display:flex;gap:14px;direction:ltr;margin-top:6px">')
    b = html.index("</div>\n <p style=\"margin-top:14px\">", a)
    html = html[:a] + f'<div style="display:flex;gap:14px;direction:ltr;margin-top:6px">{"".join(tiles)}' + html[b:]
    html = html.replace("fx/lam_fx_gold_step4_demo_v1.mp4", "fx/lam_fx_gold_step4_R3c_demo_v1.mp4 (+ R1)")
    html = re.sub(r"url\('[^']*fx_lit\.png'\) center/cover", f"url('{lit}') center/cover", html)
    html = re.sub(r"url\('[^']*fx_masks\.png'\) center/cover", f"url('{msk}') center/cover", html)
    html = html.replace("پله‌ی ۴ روشن (حالت نگه‌داشت)", "R3c: پله‌ی ۴ روشن + E10").replace("۴ ماسک پله روی رندر فعلی", "۴ ماسک پله روی R3c")
    html = html.replace("• محدودیت رندر فعلی: پله‌ی ۴ کوچک و پشت دست است؛ ستون پله‌ی ۱ و ۲ از روی صورت رد می‌شود. ماسک دقیق بعد از R3 ساخته می‌شود.",
                        "• روی R3c و R1 ماسک ۴ پله ساخته شد؛ پله‌ی ۱ «دیوار صورت» است، پس روشن شدنش زیر کیت صورت انجام می‌شود (چشم و دهان رویش می‌مانند).")
    html = html.replace('<span class="tag">در انتظار رندر R3a</span>', '<span class="tag grey">R3a رسید</span>').replace(
        '<span class="tag">در انتظار رندر R3b</span>', '<span class="tag grey">R3b رسید</span>').replace(
        '<span class="tag">در انتظار رندر R3c</span>', '<span class="tag grey">R3c رسید (نسخه‌ی ۲)</span>')
    html = html.replace("<b>در انتظار رندر R3a / R3b / R3c</b><span>لَم بی‌صورت روی پوف با کتاب، گوشی، دفترچه (پرامپت R3 در prompts/lam_prompts_v1.txt)</span>",
                        "<b>کتاب، گوشی، دفترچه: داخل رندرها</b><span>جدا کردن شیء به لایه‌ی مستقل (prop_*.png) هنوز انجام نشده؛ ساعت دیواری و تیک وکتوری مرحله‌ی بعد</span>")
    html = html.replace("افکت روی رندر فعلی ساخته شده تا روش تأیید شود؛ نسخه‌ی نهایی روی رندرهای جدید", "دموها: fx/lam_fx_gold_step4_R3c_demo_v1.mp4 و _R1_ (با صدای «دینگ» ساخته‌شده در کد)")
    return html


def views_page():
    cut = ROOT / "cutouts"
    rend = [("R1 · بدن روبه‌رو", CC / "lam_r_front_noface_01_v1_cc.png", "کفش اصلاح رنگ شد"), ("R3a · کتاب (قسمت ۱)", RV / "R3a.jpg", "۳ پله دیده می‌شود"),
            ("R3b · گوشی (قسمت ۲)", RV / "R3b.jpg", "بلندتر از پهنا"), ("R3c · دفترچه (قسمت ۳)", RV / "R3c.jpg", "بهترین پایه"),
            ("R4 · اتاق خالی", RV / "R4.jpg", "")]
    t = "".join(f"""<div style="text-align:center"><div style="width:230px;height:345px;border-radius:12px;background:url('{crop(p, (0, 0, 1333, 2000), 'vw_'+str(i), (460, 690))}') center/cover"></div>
<div style="font-size:15px;margin-top:6px;font-weight:700">{a}</div><div style="font-size:12px;color:#AEB4C2">{n}</div></div>""" for i, (a, p, n) in enumerate(rend))
    r2 = crop(CC / "lam_r_34_noface_01_v1_cc.png", (0, 0, 1322, 2000), "vw_r2", (300, 454))
    sneak_b = crop(RV / "R1.jpg", (270, 1480, 1080, 1840), "sn_b", (405, 180))
    sneak_a = crop(CC / "lam_r_front_noface_01_v1_cc.png", (270, 1480, 1080, 1840), "sn_a", (405, 180))
    names = ["lam_v1_view_front", "lam_v1_view_34", "lam_v1_view_side", "lam_v1_view_back", "lam_v1_pose_sarcastic", "lam_v1_pose_tired", "lam_v1_pose_excited", "lam_v1_pose_curious"]
    cu = "".join(f"""<div style="width:96px;height:100px;border-radius:8px;background:#6E7480 url('{uri(cut/(n+'.png'))}') center/contain no-repeat"></div>""" for n in names)
    body = f"""
<div style="position:absolute;top:122px;right:64px;width:1290px;display:flex;gap:22px;justify-content:space-between">{t}</div>
<div class="card" style="position:absolute;top:122px;left:64px;width:470px;height:250px;padding:12px 16px;display:flex;gap:14px;align-items:center"><div style="width:150px;height:226px;border-radius:10px;background:url('{r2}') center/cover;flex:none"></div><div><h3>R2 · سه‌رخ بی‌صورت</h3><p style="font-size:14px">رسید؛ کفش مثل R1 اصلاح رنگ شد (<span class="ltr">#CDAD49 → #B79836</span>). ۴ پله، بلندترین چپ.</p><p class="ltr" style="font-size:12px;color:#8790A6">renders_cc/lam_r_34_noface_01_v1_cc.png</p></div></div>
<div class="card" style="position:absolute;top:392px;left:64px;width:470px;height:250px;padding:14px 20px"><h3>اصلاح رنگ کفش R1</h3>
 <div style="display:flex;gap:10px;direction:ltr"><div><div style="width:205px;height:92px;border-radius:8px;background:url('{sneak_b}') center/cover"></div><div style="font-size:12px;color:#AEB4C2">before <b>#EAC34D</b></div></div>
 <div><div style="width:205px;height:92px;border-radius:8px;background:url('{sneak_a}') center/cover"></div><div style="font-size:12px;color:#AEB4C2">after <b>#D0AB3A</b> → #C9A227</div></div></div>
 <p style="font-size:14px;margin-top:6px">فقط R1 زرد لیمویی بود؛ کفش R3a/b/c در نور صحنه نزدیک پالت است و دست نخورد.</p></div>
<div class="card" style="position:absolute;top:560px;right:64px;width:1290px;height:416px;padding:16px 24px">
 <h3>یادداشت رندرها</h3>
 <p>• <b>R3c</b> روبه‌روی صاف با دیوار تخت چپ: بهترین پایه برای کیت صورت و گرید (صفحه‌ی ۳). • <b>R3a</b> بهتر از همه «خوانده» می‌شود ولی پله‌ی ۴ پشت دست پنهان است.</p>
 <p>• <b>R1</b> و <b>R3b</b> کمی بلندتر از پهنا (۰٫۸۲)؛ با v2-R پذیرفتنی، با ۸:۷ نه. • <b>R3c نسخه‌ی ۱</b> (بدن هرمی) کنار گذاشته شد.</p>
 <p>• نسخه‌ی اصلاح‌شده‌ی همه: <span class="ltr">renders_cc/lam_r_*_v1_cc.png</span> (اصل فایل‌های وحید دست نخورده).</p>
 <h3 style="margin-top:12px;font-size:18px">برش‌های قدیمی شیت v1 (فقط مرجع، فرم منسوخ)</h3>
 <div style="display:flex;gap:12px;direction:ltr">{cu}</div></div>
<div class="card" style="position:absolute;top:662px;left:64px;width:470px;height:314px;padding:14px 20px"><h3>هنوز لازم</h3>
 <p>• حالت‌های دیگر دست (رندر) برای ریگ دست</p><p>• ثبت لایه‌ها روی بوم ۲۱۶۰×۳۸۴۰ (رندرها ۱۳۳۳×۲۰۰۰ هستند؛ بزرگ‌نمایی ۱٫۶۲× یا رندر با وضوح بالاتر)</p><p>• جدا کردن کتاب/گوشی/دفترچه به لایه‌ی مستقل</p></div>"""
    return page("P1·12", "رندرهای وحید و نماها", "All renders received · R1 R2 R3a-c R4", body, "رندرها: renders_vahid/ (اصل) و renders_cc/ (اصلاح رنگ)")


def parts_page():
    html = BP.parts_page()
    html = html.replace("<b>در انتظار رندر R1</b><span>body_front_noface.png و ثبت مختصات چشم/دهان روی آن</span>",
                        "<b>R1 و R3c رسیدند</b><span>مختصات چشم، ابرو و دهان روی هر رندر: style_test/face_placement_px.json</span>")
    html = html.replace("ثبت (registration) روی بوم <span class=\"ltr\">2160×3840</span> بخش ۷ فقط بعد از رندر بی‌صورت <b>R1</b> ممکن است؛ الان قطعه‌ها مستقل‌اند.",
                        "جای صورت روی R1، R3a، R3b و R3c ثبت شد (پیکسل). بوم <span class=\"ltr\">2160×3840</span> بخش ۷ هنوز نه: رندرها ۱۳۳۳×۲۰۰۰اند.")
    return html


def dodont_page():
    html = BP.dodont_page()
    good = crop(ST / "vr_R3c_E01.png", (60, 200, 1260, 1500), "dd_good2")
    html = re.sub(r"url\('[^']*dd_good\.png'\) center/contain no-repeat", f"url('{good}') center/cover no-repeat", html)
    html = html.replace("(چشم در <span class=ltr>4.4G</span>، پیشنهاد)", "(R3c + کیت صورت، v2-R)")
    html = html.replace("پهن‌تر از بلند (۸:۷)", "پهن و جمع‌وجور: پهنا:ارتفاع ≥ ۰٫۸۵ (v2-R، قفل‌شده)")
    return html


def files_page():
    html = BP.files_page()
    rep = {
        '<span style="flex:1;font-size:16px">بدن بی‌صورت روبه‌رو / سه‌رخ</span>\n<span class="tag red">در انتظار رندر R1 · R2</span>':
            '<span style="flex:1;font-size:16px">بدن بی‌صورت روبه‌رو / سه‌رخ</span>\n<span class="tag">R1 و R2 رسید</span>',
        '<span class="tag red">در انتظار رندر R3a · R3b · R3c</span>': '<span class="tag">R3a · R3b · R3c رسید</span>',
        '<span class="tag red">در انتظار رندر R4</span>': '<span class="tag">R4 رسید</span>',
        '<span style="flex:1;font-size:16px">ماسک ۴ پله روی بدن نهایی + ثبت لایه‌ها روی 2160×3840</span>\n<span class="tag red">در انتظار رندر R1</span>':
            '<span style="flex:1;font-size:16px">ماسک ۴ پله + جای صورت روی رندرها</span>\n<span class="tag">آماده (R1، R3c)</span>',
        '<span class="tag">آماده · منتظر تأیید</span>': '<span class="tag">v2-R قفل‌شده</span>',
        '<span class="tag">آماده · نتیجه: نیمه‌تأیید</span>': '<span class="tag">آماده · تأیید برای تست</span>',
    }
    for a, b in rep.items():
        html = html.replace(a, b)
    html = html.replace("grid/        lam_P1_proportion_grid_v1.png  (+ صفحه‌های گرید)", "grid/        lam_P1_proportion_grid_v2R.png · _v1.png (8:7)")
    html = html.replace("style_test/  test_expr_E01.png … test_mouth_G_FV.png", "style_test/  vr_R3c_E01.png … face_placement_px.json")
    html = html.replace("fx/          lam_fx_gold_step4_demo_v1.mp4", "fx/          lam_fx_gold_step4_R3c_demo_v1.mp4")
    html = html.replace("masks/body_step1..4_mask_beanbag.png", "masks/body_step1..4_mask_R3c.png")
    html = html.replace("cutouts/     lam_v1_view_*.png · lam_v1_pose_*.png", "renders_cc/  lam_r_*_v1_cc.png  · cutouts/ (v1)")
    return html


BUILDERS = [cover, spec_page, page_v2r, overlay_pages, inconsist_page, BP.colour_page, BP.expr_page, BP.mouth_page,
            parts_page, style_page, fx_page, views_page, dodont_page, files_page]

if __name__ == "__main__":
    only = set(int(a) for a in sys.argv[1:])
    for old in PAGES.glob("lam_sheet_v2_P1_p*.png"):
        if not only:
            old.unlink()
    outs = []
    for i, b in enumerate(BUILDERS, 1):
        p = PAGES / f"lam_sheet_v2_P1_p{i:02d}.png"
        if not only or i in only:
            html = re.sub(r"P1·\d\d", f"P1·{i:02d}", b(), count=1)
            render_page(html, p)
            print("page", i)
        outs.append(p)
    if not only:
        ims = [Image.open(p).convert("RGB") for p in outs]
        ims[0].save(PAGES / "lam_sheet_v2_P1.pdf", save_all=True, append_images=ims[1:], resolution=96, quality=92)
        print("pdf")
