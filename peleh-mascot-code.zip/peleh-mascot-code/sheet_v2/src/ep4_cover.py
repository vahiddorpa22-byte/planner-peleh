"""Lam ep4 cover in the Lam series layout (same as ep2/ep3): character on top, «لَم · قسمت ۴» pill, the line on the navy band.
Face = kit layers (sleepy) on the faceless plate A."""
from pathlib import Path
import numpy as np, cv2
from PIL import Image
from render_util import html_to_png, FONT

EP = Path(__file__).resolve().parents[2] / "ep4"
B = EP / "_build"
S = 1080 / 1116; HS = round(2000 * S); CROP = (HS - 1920) // 2
plate = cv2.imread(str(EP / "lam_ep4_A_faceless.png"))[:, :, ::-1].astype(np.float32)
plate = cv2.resize(plate, (1080, HS), interpolation=cv2.INTER_AREA)[CROP:CROP + 1920]
L = dict(np.load(B / "layers_A.npz"))


def over(img, rgba):
    a = rgba[..., 3:].astype(np.float32) / 255
    return img * (1 - a) + rgba[..., :3].astype(np.float32) * a


img = over(over(plate, L["face_w_sleepy"]), L["rest_smile_soft"])
Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).save(B / "cover_base.png")
base = (B / "cover_base.png").as_uri()
html = f"""<!doctype html><meta charset='utf-8'><style>
@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}
html,body{{margin:0;width:1080px;height:1920px;overflow:hidden;background:#1B2A4A;font-family:Vaz;direction:rtl}}
.pic{{position:absolute;left:0;top:-120px;width:1080px;height:1920px;background:url('{base}') center/cover}}
.fade{{position:absolute;left:0;right:0;top:1060px;height:260px;background:linear-gradient(180deg,rgba(27,42,74,0),#1B2A4A)}}
.band{{position:absolute;left:0;right:0;top:1300px;bottom:0;background:#1B2A4A}}
.pill{{position:absolute;right:62px;top:110px;border:3px solid #C9A227;border-radius:26px;padding:14px 30px;background:rgba(14,22,40,.55);
  font-size:56px;font-weight:900;color:#F3F0E8}} .pill b{{color:#C9A227}}
.t{{position:absolute;left:40px;right:40px;top:1370px;text-align:center;font-size:96px;white-space:nowrap;font-weight:900;color:#F3F0E8;line-height:1.25}}
.t g{{color:#C9A227}}
.s{{position:absolute;left:40px;right:40px;top:1570px;text-align:center;font-size:62px;font-weight:800;color:#C9A227}}
</style><div class='pic'></div><div class='fade'></div><div class='band'></div>
<div class='pill'>لَم · <b>قسمت ۴</b></div>
<div class='t'>زمستون یعنی <g>خواب</g>؟</div><div class='s'>…یا پتو، چای و ۱۰ صفحه 📖</div>"""
html_to_png(html, EP / "cover_lam_ep4.png", 1080, 1920)
print("ok")
