﻿"""Gold-step light-up effect for LAM (spec §6): 18 frames / 0.6 s, navy -> #C9A227 keeping clay texture,
soft gold glow (sigma ~0.4G), 3-5 rising particles, 3% body squash timed with a soft 'ding'.

Usage (any render + its step masks):
    from gold_step import light_up_frame, ding_wav
    frame = light_up_frame(base_rgb, step_mask, body_mask, t, G=105, ground_y=600)
Rule (Vahid, 2026-11-02): ONE step lights per episode and is dark again in the next episode (not cumulative).
"""
from pathlib import Path
import math, subprocess, wave
import numpy as np, cv2
import imageio_ffmpeg

GOLD = np.array([0xC9, 0xA2, 0x27], np.float32)
DUR = 0.6          # seconds
FPS = 30


def _ease_out(x):
    x = min(max(x, 0.0), 1.0)
    return 1 - (1 - x) ** 3


def navy_pixels(rgb):
    """Body-coloured pixels only (excludes cream eyes, brown brows, dark mouth) so the face survives on step 1/2."""
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    s = rgb.sum(-1)
    return ((b > r + 6) & (s > 60) & (s < 560)).astype(np.float32)


def recolor_gold(rgb, m):
    """Multiply (gold x clay luminance) then a light screen pass so shading + micro-texture stay visible."""
    lum = rgb.mean(-1, keepdims=True)
    ref = np.median(lum[m > 0.5]) if (m > 0.5).any() else 50.0
    shade = np.clip(lum / ref, 0.30, 1.6) ** 0.8
    mult = GOLD * 0.60 * shade
    scr = 255 - (255 - mult) * (255 - GOLD * 0.10) / 255
    return np.clip(scr, 0, 255)


def light_up_frame(base, step_mask, body_mask, t, G=105.0, ground_y=600, seed=3, hold_glow=0.22):
    """base: float32 RGB HxWx3; step_mask/body_mask: float32 0..1. t: seconds since start (>=0.6 = lit hold)."""
    H, W = base.shape[:2]
    p = t / DUR
    a = _ease_out(p / 0.85)                                   # colour fade-in
    m = cv2.GaussianBlur(step_mask * navy_pixels(base), (0, 0), 1.2)[..., None]
    gold = recolor_gold(base, m[..., 0])
    out = base * (1 - m * a) + gold * (m * a)
    # glow: rises to a peak at ~55% then settles to a gentle hold level
    gpk = math.exp(-((p - 0.55) / 0.25) ** 2) if p < 1 else 0
    gl = (hold_glow * a + 0.55 * gpk) * (0.92 + 0.08 * math.sin(t * 5.0) if p >= 1 else 1)
    glow = cv2.GaussianBlur(step_mask, (0, 0), 0.4 * G)[..., None] * gl
    out = 255 - (255 - out) * (1 - glow * GOLD / 255 * 0.85)
    # particles: 4 small gold specks rising from the step top
    rng = np.random.default_rng(seed)
    ys, xs = np.nonzero(step_mask > 0.5)
    if len(xs) and 0.25 < p < 1.6:
        top = ys.min()
        lay = np.zeros((H, W), np.float32)
        for i in range(4):
            x0 = rng.uniform(xs.min() + 5, xs.max() - 5)
            st = 0.25 + i * 0.12
            q = (p - st) / 0.9
            if 0 < q < 1:
                y = top + 10 - q * 1.1 * G
                x = x0 + 6 * math.sin(q * 6 + i)
                cv2.circle(lay, (int(x), int(y)), max(2, int(G * 0.035)), 1.0 * (1 - q) ** 0.7, -1, cv2.LINE_AA)
        lay = cv2.GaussianBlur(lay, (0, 0), 1.5) + cv2.GaussianBlur(lay, (0, 0), 6) * 1.5
        out = 255 - (255 - out) * (1 - np.clip(lay, 0, 1)[..., None] * (GOLD + 40) / 255)
    # squash 3% on the 'ding' (p 0.15..0.55), anchored at the ground
    if 0.15 < p < 0.55:
        s = 0.03 * math.sin(math.pi * (p - 0.15) / 0.40)
        sy, sx = 1 - s, 1 + s * 0.5
        wgt = cv2.GaussianBlur(body_mask, (0, 0), 18)
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        ys_, xs_ = np.nonzero(body_mask > 0.5)
        cx = xs_.mean()
        srcy = ground_y + (yy - ground_y) / sy
        srcx = cx + (xx - cx) / sx
        mx = (xx * (1 - wgt) + srcx * wgt).astype(np.float32)
        my = (yy * (1 - wgt) + srcy * wgt).astype(np.float32)
        out = cv2.remap(out.astype(np.float32), mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    return np.clip(out, 0, 255)


def ding_wav(path, at=0.1, total=3.0, sr=44100):
    """Soft synthetic 'ding' (no external audio needed)."""
    n = int(total * sr)
    t = np.arange(n) / sr
    y = np.zeros(n)
    tt = t - at
    on = tt >= 0
    env = np.where(on, np.exp(-np.clip(tt, 0, None) / 0.45) * (1 - np.exp(-np.clip(tt, 0, None) / 0.004)), 0)
    for f0, amp in ((1318.5, 0.5), (1975.5, 0.25), (2637.0, 0.12), (3951, 0.05)):
        y += amp * np.sin(2 * np.pi * f0 * tt) * env
    sh = np.where(on, np.exp(-np.clip(tt, 0, None) / 0.9), 0) * 0.04 * np.sin(2 * np.pi * 5274 * tt) * (1 + np.sin(2 * np.pi * 7 * tt))
    y = (y + sh) * 0.35
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((np.clip(y, -1, 1) * 32767).astype(np.int16).tobytes())


# ------------------------------------------------------------------ masks for the existing bean-bag render
STEP_POLYS_BEANBAG = {   # square 1024 render; columns = tread + front face + visible riser side face
    1: [(372, 250), (555, 182), (590, 195), (600, 222), (598, 600), (400, 600), (400, 385), (372, 385)],
    2: [(598, 278), (660, 276), (690, 282), (697, 300), (697, 384), (657, 384), (657, 600), (598, 600)],
    3: [(657, 384), (733, 383), (744, 398), (745, 498), (718, 498), (718, 600), (657, 600)],
    4: [(718, 498), (792, 497), (804, 514), (806, 546), (760, 560), (718, 560)],
}


def poly_mask(shape, pts, fade=(520, 600)):
    m = np.zeros(shape, np.uint8)
    cv2.fillPoly(m, [np.array(pts, np.int32)], 255)
    m = m.astype(np.float32) / 255
    y = np.arange(shape[0], dtype=np.float32)[:, None]
    return m * np.clip((fade[1] - y) / (fade[1] - fade[0]), 0, 1)   # soft fade where the body sinks into the bean bag


if __name__ == "__main__":
    ROOT = Path(__file__).resolve().parents[1]
    REF = ROOT.parent / "ref" / "lam_beanbag_square_profile.jpg"
    OUT = ROOT / "fx"
    (OUT / "masks").mkdir(parents=True, exist_ok=True)
    base = cv2.imread(str(REF))[:, :, ::-1].astype(np.float32)
    H, W = base.shape[:2]
    masks = {k: poly_mask((H, W), v) for k, v in STEP_POLYS_BEANBAG.items()}
    # protect: eyes+lids (face kit sits on top in production) and the mug in front of steps 2-3
    prot = np.zeros((H, W), np.uint8)
    cv2.circle(prot, (458, 398), 66, 255, -1); cv2.circle(prot, (577, 399), 68, 255, -1)
    cv2.rectangle(prot, (604, 556), (722, 700), 255, -1)
    prot = cv2.GaussianBlur(prot.astype(np.float32) / 255, (0, 0), 2)
    masks = {k: m * (1 - prot) for k, m in masks.items()}
    body = np.clip(sum(masks.values()), 0, 1)
    for k, m in masks.items():
        cv2.imwrite(str(OUT / "masks" / f"body_step{k}_mask_beanbag.png"), (m * 255).astype(np.uint8))
    # stills: each step lit (for the sheet) + mask overlay
    for k, m in masks.items():
        f = light_up_frame(base, m, body, 1.2, ground_y=600)
        cv2.imwrite(str(OUT / f"gold_step{k}_lit_beanbag.png"), f[:, :, ::-1].astype(np.uint8))
    ov = base.copy()
    cols = {1: (231, 76, 60), 2: (46, 204, 113), 3: (52, 152, 219), 4: (241, 196, 15)}
    for k, m in masks.items():
        ov = ov * (1 - 0.45 * m[..., None]) + np.array(cols[k]) * 0.45 * m[..., None]
    cv2.imwrite(str(OUT / "step_masks_overlay_beanbag.png"), ov[:, :, ::-1].astype(np.uint8))
    # demo MP4: 0.5 s still, step 4 lights (0.6 s), 1.6 s hold  (one step per episode)
    fr = OUT / "_frames"
    fr.mkdir(exist_ok=True)
    pre, hold = 0.5, 1.6
    N = int((pre + DUR + hold) * FPS)
    for i in range(N):
        t = i / FPS - pre
        img = base if t < 0 else light_up_frame(base, masks[4], body, t, ground_y=600)
        img = cv2.resize(img.astype(np.uint8), (1080, 1080), interpolation=cv2.INTER_CUBIC)
        cv2.imwrite(str(fr / f"{i:04d}.png"), img[:, :, ::-1])
        if 0 <= t < DUR and i % 3 == 0:
            cv2.imwrite(str(OUT / f"_strip_{i:04d}.png"), img[:, :, ::-1])
    ding_wav(OUT / "_ding.wav", at=pre + 0.15 * DUR, total=N / FPS)
    ff = imageio_ffmpeg.get_ffmpeg_exe()
    subprocess.run([ff, "-y", "-framerate", str(FPS), "-i", str(fr / "%04d.png"), "-i", str(OUT / "_ding.wav"),
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-c:a", "aac", "-b:a", "160k", "-shortest",
                    str(OUT / "lam_fx_gold_step4_demo_v1.mp4")], check=True, capture_output=True)
    for p in fr.glob("*.png"):
        p.unlink()
    fr.rmdir()
    print("done", N, "frames")
