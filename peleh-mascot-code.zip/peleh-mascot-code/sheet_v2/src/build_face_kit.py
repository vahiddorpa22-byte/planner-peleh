"""Export the LAM face kit: SVG + transparent PNG per part, expression previews, combined kit SVG."""
from pathlib import Path
import lam_facekit as K
from render_util import render_sprites

OUT = Path(__file__).resolve().parents[1] / "face_kit"
SVG, PNG = OUT / "svg", OUT / "png"
for d in (SVG, PNG):
    d.mkdir(parents=True, exist_ok=True)

R = 140
parts = []  # (relative name, svg)


def add(name, inner, w, h, vb=None):
    doc = K.svg_doc(inner, w, h, vb)
    parts.append((name, doc))


EW = 360
add("eyes/eye_L_white", K.eye_white(R), EW, EW)
add("eyes/eye_R_white", K.eye_white(R), EW, EW)
add("eyes/pupil", K.pupil(R, highlight=False), EW, EW)
add("eyes/eye_highlight", K.eye_highlight(R), EW, EW)
add("eyes/eye_highlight_double", K.eye_highlight(R, double=True), EW, EW)
for pct in (0, 20, 35, 55, 100):
    add(f"eyes/lid_L_{pct:03d}", K.lid(R, pct / 100, -3), EW, EW)
    add(f"eyes/lid_R_{pct:03d}", K.lid(R, pct / 100, 3), EW, EW)
add("eyes/lid_R_squint_lower", K.lid(R, 0.42, -6, 0.22), EW, EW)
add("eyes/eye_happy_arc", K.eye_happy(R), EW, EW)
# assembled eye previews (white+pupil+lid) for the sheet
add("eyes/_preview_eye_default", K.eye(R, 0.35, -3, (0.3, 0.06)), EW, EW)

for shape in K.BROW_SHAPES:
    add(f"brows/brow_L_{shape}", K.brow(R, shape, "L"), EW, 240, (-180, -120, 360, 240))
    add(f"brows/brow_R_{shape}", K.brow(R, shape, "R"), EW, 240, (-180, -120, 360, 240))

for m in K.MOUTHS:
    for fr in (False, True):
        add(f"mouth/mouth_{m}_{'frown' if fr else 'neutral'}", K.mouth(R, m, fr), 360, 300, (-180, -110, 360, 300))

# expressions: transparent + preview on clay face plate
ER = 90
for ex in K.EXPR:
    inner = K.face(ER, ex)
    vb = (-260, -230, 520, 560)
    add(f"expr/expr_{ex}", inner, 520, 560, vb)
    plate = f'<g transform="translate(0,50)">{K.faceplate(500, 540, 46)}</g>'
    add(f"expr/expr_{ex}_preview", plate + inner, 520, 560, vb)

# write SVGs
for name, doc in parts:
    p = SVG / f"{name}.svg"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(doc, encoding="utf-8")

# combined kit svg (each part as a named group on one canvas)
cols, cw, ch = 8, 520, 560
groups = []
for i, (name, doc) in enumerate(parts):
    x, y = (i % cols) * cw, (i // cols) * ch
    gid = name.split("/")[-1]
    groups.append(f'<g id="{gid}" transform="translate({x},{y})">{doc}</g>')
rows = (len(parts) + cols - 1) // cols
(OUT / "lam_face_kit.svg").write_text(
    f'<svg xmlns="http://www.w3.org/2000/svg" width="{cols*cw}" height="{rows*ch}">{"".join(groups)}</svg>', encoding="utf-8")

# render PNGs by cell size groups
by_size = {}
for name, doc in parts:
    import re
    w = int(re.search(r'width="(\d+)"', doc).group(1)); h = int(re.search(r'height="(\d+)"', doc).group(1))
    by_size.setdefault((w, h), []).append((f"{name}.png", doc))
for (w, h), items in by_size.items():
    render_sprites(items, PNG, (w, h), cols=8, name=f"s{w}x{h}")
print(len(parts), "parts")
