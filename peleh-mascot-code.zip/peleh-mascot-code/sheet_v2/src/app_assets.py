"""Lam app assets: transparent base + face states + aligned accessory layers + previews + animated WebP.
All layers share one square canvas (CANVAS px) derived from R1 (colour-corrected); exported at 512 and 256."""
from pathlib import Path
import copy, json
import numpy as np, cv2
from PIL import Image
import lam_facekit as K
from render_util import html_to_png

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
OUT = MASCOT / "app_assets"
for d in ("layers_png", "png512", "png256", "webp512", "webp256", "preview", "anim", "_work"):
    (OUT / d).mkdir(parents=True, exist_ok=True)
WORK = OUT / "_work"
CANVAS = 1720
OX, OY = (CANVAS - 1333) // 2, -120          # canvas = R1 coords + (OX, OY)
NAVY, GOLD, CREAM = "#1B2A4A", "#C9A227", "#F3F0E8"
GOLDV = np.array([0xC9, 0xA2, 0x27], np.float32)

r1 = cv2.imread(str(ROOT / "renders_cc" / "lam_r_front_noface_01_v1_cc.png"))[:, :, ::-1].astype(np.float32)
H1, W1 = r1.shape[:2]


def to_canvas(img, fill=0):
    c = np.full((CANVAS, CANVAS) + img.shape[2:], fill, img.dtype)
    ys, ye = max(0, -OY), min(H1, CANVAS - OY)
    c[ys + OY:ye + OY, OX:OX + W1] = img[ys:ye]
    return c


# ----------------------------------------------------------------- 1. body cut-out
cache = WORK / "body_alpha.png"
if cache.exists():
    alpha = cv2.imread(str(cache), 0).astype(np.float32) / 255
else:
    yy, xx = np.mgrid[0:H1, 0:W1]
    bgm = np.zeros((H1, W1), bool)
    bgm[:240] = True; bgm[:, :110] = True; bgm[:, 1250:] = True
    bgm[1850:] = True
    gx, gy = xx / W1 - .5, yy / H1 - .5
    A = np.stack([np.ones_like(gx), gx, gy, gx * gx, gx * gy, gy * gy, gy ** 3, gx * gx * gy], -1).astype(np.float32)
    idx = np.nonzero(bgm.ravel())[0][::5]
    bgfit = np.zeros_like(r1)
    for ch in range(3):
        coef, *_ = np.linalg.lstsq(A.reshape(-1, 8)[idx], r1[..., ch].ravel()[idx], rcond=None)
        bgfit[..., ch] = A @ coef
    diff = np.linalg.norm(r1 - bgfit, axis=2)
    gc = np.full((H1, W1), cv2.GC_BGD, np.uint8)
    gc[250:1840, 100:1260] = cv2.GC_PR_BGD
    gc[(diff > 30) & (gc == cv2.GC_PR_BGD)] = cv2.GC_PR_FGD
    gc[(diff > 70) & (gc != cv2.GC_BGD)] = cv2.GC_FGD
    cv2.fillPoly(gc, [np.array([(300, 420), (1000, 760), (1080, 1250), (300, 1250)], np.int32)], cv2.GC_FGD)
    s8 = cv2.resize(r1.astype(np.uint8)[:, :, ::-1], (W1 // 2, H1 // 2))
    gs = cv2.resize(gc, (W1 // 2, H1 // 2), interpolation=cv2.INTER_NEAREST)
    cv2.grabCut(s8, gs, None, np.zeros((1, 65)), np.zeros((1, 65)), 6, cv2.GC_INIT_WITH_MASK)
    fg = cv2.resize(np.isin(gs, (1, 3)).astype(np.uint8), (W1, H1), interpolation=cv2.INTER_LINEAR)
    # floor shadow: dark, low-chroma, near the ground and not part of the shoes
    shadow = (yy > 1700) & (r1.sum(2) < 380) & (np.abs(r1[..., 2] - r1[..., 0]) < 45)
    fg[shadow] = 0
    low = yy > 1690                                    # below the knees only the two shoes survive (kills floor reflection)
    shoes = ((xx > 280) & (xx < 665)) | ((xx > 720) & (xx < 1060))
    fg[low & ~shoes] = 0
    fg[yy > 1812] = 0
    n, lbl, st, _ = cv2.connectedComponentsWithStats(fg)
    keep = [j for j in range(1, n) if st[j, cv2.CC_STAT_AREA] > 4000]
    fg = np.isin(lbl, keep).astype(np.uint8)
    fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    ff = fg.copy(); cv2.floodFill(ff, np.zeros((H1 + 2, W1 + 2), np.uint8), (0, 0), 1)
    holes = (ff == 0).astype(np.uint8)
    nh, lh, sh, _ = cv2.connectedComponentsWithStats(holes)
    for j in range(1, nh):
        hm = lh == j
        if sh[j, cv2.CC_STAT_AREA] < 1500 or diff[hm].mean() > 25:
            fg[hm] = 1
    alpha = cv2.GaussianBlur(fg.astype(np.float32), (0, 0), 1.0)
    cv2.imwrite(str(cache), (alpha * 255).astype(np.uint8))

# decontaminate edges: pull edge colour toward interior navy
inner = cv2.erode((alpha > 0.5).astype(np.uint8), np.ones((5, 5), np.uint8)).astype(np.float32)
blurc = cv2.GaussianBlur(r1 * inner[..., None], (0, 0), 4) / np.maximum(cv2.GaussianBlur(inner, (0, 0), 4), 1e-3)[..., None]
edgew = np.clip((alpha - inner) * 1.0, 0, 1)[..., None] * 0.7
body_rgb = r1 * (1 - edgew) + blurc * edgew

# contact shadow (soft ellipse under the shoes)
shadow = np.zeros((H1, W1), np.float32)
cv2.ellipse(shadow, (670, 1805), (470, 42), 0, 0, 360, 1.0, -1)
shadow = cv2.GaussianBlur(shadow, (0, 0), 22) * 0.45

BODY = np.dstack([to_canvas(body_rgb), to_canvas(alpha)[..., None] * 255])
SHADOW = np.dstack([np.zeros((CANVAS, CANVAS, 3), np.float32) + np.array([8, 12, 24], np.float32), to_canvas(shadow)[..., None] * 255])

# ----------------------------------------------------------------- face states (polished kit, graded on R1)
G = dict(R=80, eyeL=(345, 640), eyeR=(515, 640), browL=(340, 524), browR=(508, 528), mouth=(462, 768), ms=1.18)
LOCAL = cv2.GaussianBlur(to_canvas(r1), (0, 0), 22)
NAVY_L = 0.299 * 0x1B + 0.587 * 0x2A + 0.114 * 0x4A


def render_svg(inner, name):
    p = WORK / f"_{name}.png"
    html_to_png("<!doctype html><style>html,body{margin:0;background:transparent}</style>" + K.svg_doc(inner, CANVAS, CANVAS, (0, 0, CANVAS, CANVAS)), p, CANVAS, CANVAS)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def grade(lay):
    rgb, a = lay[..., :3].copy(), lay[..., 3]
    lum = rgb @ np.array([0.299, 0.587, 0.114])
    nv = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] + 8) & (lum < 150)).astype(np.float32), (0, 0), 0.8)[..., None]
    ratio = np.clip(lum / NAVY_L, 0.45, 1.30)[..., None]
    rgb = rgb * (1 - nv) + np.clip(LOCAL * ratio, 0, 255) * nv
    rgb = cv2.GaussianBlur(rgb * np.array([0.97, 0.95, 0.93]), (0, 0), 0.6)
    return np.dstack([np.clip(rgb, 0, 255), cv2.GaussianBlur(a, (0, 0), 0.5)])


def face(ex, closed=False):
    saved = copy.deepcopy(K.EXPR[ex]); e = K.EXPR[ex]
    for side in ("eyeL", "eyeR"):
        if e[side] != "happy":
            l = list(e[side]); l[3] = (0.05, 0.08)
            if closed:
                l[0], l[2] = 0.97, 0.0
            e[side] = tuple(l)
    if ex == "E10":
        e["mouth"] = ("smirk_wide", False)
    R = G["R"]; u = lambda p: ((p[0] + OX) / R, (p[1] + OY) / R)
    inner = K.face(R, ex, eyeL=u(G["eyeL"]), eyeR=u(G["eyeR"]), browL=u(G["browL"]), browR=u(G["browR"]), mouthc=u(G["mouth"]), mscale=G["ms"])
    K.EXPR[ex] = saved
    return grade(render_svg(inner, f"face_{ex}{'_blink' if closed else ''}"))


FACES = {"E01_smirk": "E01", "E10_happy": "E10", "E03_curious": "E03", "E08_kind": "E08"}
FACE = {k: face(v) for k, v in FACES.items()}
BLINK = face("E01", closed=True)

# ----------------------------------------------------------------- steps lit (warm glaze, same look as ep1)
STEPMASK = {}
for k in range(1, 5):
    m = cv2.imread(str(ROOT / "fx" / "masks" / f"body_step{k}_mask_R1.png"), 0).astype(np.float32) / 255
    STEPMASK[k] = to_canvas(m) * to_canvas(alpha)
BODY_LUM = BODY[..., :3] @ np.array([0.299, 0.587, 0.114], np.float32)


def glaze_layer(steps, amount=1.0):
    m = np.clip(sum(STEPMASK[s] for s in steps), 0, 1)
    if m.max() == 0:
        return np.zeros((CANVAS, CANVAS, 4), np.float32)
    ys = np.nonzero(m > 0.5)[0]
    yy = np.arange(CANVAS, dtype=np.float32)[:, None]
    grad = np.zeros_like(m)
    for s in steps:                                    # per-step vertical falloff (top of each step brightest)
        sm = STEPMASK[s]
        sy = np.nonzero(sm > 0.5)[0]
        if len(sy):
            grad = np.maximum(grad, sm * np.clip((sy.max() - yy) / (sy.max() - sy.min()), 0, 1))
    er = cv2.erode((m > 0.5).astype(np.uint8), np.ones((13, 13), np.uint8)).astype(np.float32)
    rim = np.clip(cv2.GaussianBlur((m > 0.5).astype(np.float32) - er, (0, 0), 3) * 1.4, 0, 1) * m
    w = np.clip(cv2.GaussianBlur(m, (0, 0), 3) * (0.50 + 0.38 * grad) + rim * 0.30, 0, 0.95) * 0.86 * amount
    w *= to_canvas(alpha)
    ref = np.median(BODY_LUM[m > 0.5]) if (m > 0.5).any() else 50.0
    shade = np.clip(BODY_LUM / ref, 0.45, 1.6) ** 0.8
    base = BODY[..., :3]
    lb = BODY_LUM[..., None]
    gcol = GOLDV[None, None, :] * np.array([1.12, 0.93, 0.60], np.float32) * shade[..., None] * 1.02
    gl = (gcol @ np.array([0.299, 0.587, 0.114], np.float32))[..., None]
    W3 = w[..., None]
    L = lb * (1 - W3 * 0.92) + gl * W3 * 0.92                 # lift brightness only partly -> clay shading + texture stay
    tex = (BODY_LUM - cv2.GaussianBlur(BODY_LUM, (0, 0), 3))[..., None]                # micro texture back on top
    out = L + (base - lb) * (1 - W3) ** 2 + (gcol - gl) * W3 * 1.0 + tex * 0.9
    out = np.clip(out, 0, 255)
    # express as a layer over the body: alpha = w, rgb chosen so body*(1-w)+rgb*w == out
    rgb = np.clip((out - base * (1 - W3)) / np.maximum(W3, 1e-3), 0, 255)
    return np.dstack([rgb, w * 255])


LEVEL_STEPS = {1: [4], 2: [4, 3], 3: [4, 3, 2], 4: [4, 3, 2, 1]}
STEPS = {f"steps_lit_L{l}": glaze_layer(s) for l, s in LEVEL_STEPS.items()}

# ----------------------------------------------------------------- accessories (SVG, clay shading), drawn in R1 coords
def X(x): return x + OX
def Y(y): return y + OY


def defs_common():
    return """<defs>
<filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur in="SourceAlpha" stdDeviation="9"/><feOffset dx="6" dy="12"/>
<feComponentTransfer><feFuncA type="linear" slope=".45"/></feComponentTransfer><feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge></filter>
<filter id="sb"><feGaussianBlur stdDeviation="3"/></filter><filter id="sb2"><feGaussianBlur stdDeviation="8"/></filter>
<radialGradient id="gGold" cx=".32" cy=".25" r=".9"><stop offset="0" stop-color="#F3DC8A"/><stop offset=".45" stop-color="#C9A227"/><stop offset="1" stop-color="#7A5E12"/></radialGradient>
<radialGradient id="gCream" cx=".32" cy=".25" r=".95"><stop offset="0" stop-color="#FFFBF2"/><stop offset=".55" stop-color="#EDE3CF"/><stop offset="1" stop-color="#B9AB8E"/></radialGradient>
<radialGradient id="gNavy" cx=".3" cy=".25" r=".95"><stop offset="0" stop-color="#4A5A88"/><stop offset=".55" stop-color="#1B2A4A"/><stop offset="1" stop-color="#0E1730"/></radialGradient>
<radialGradient id="gBall" cx=".33" cy=".28" r=".85"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".6" stop-color="#E4E6EA"/><stop offset="1" stop-color="#9DA3AE"/></radialGradient>
<linearGradient id="gMetal" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8A93A6"/><stop offset=".45" stop-color="#3A4256"/><stop offset="1" stop-color="#1A1F2C"/></linearGradient>
<linearGradient id="gRib" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8E6E14"/><stop offset=".5" stop-color="#D9B444"/><stop offset="1" stop-color="#8E6E14"/></linearGradient>
</defs>"""


def svg(inner):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{CANVAS}" height="{CANVAS}">{defs_common()}{inner}</svg>'


EL, ER_, EY = (345, 640), (515, 640), 640
ACC = {}
# L1 glasses: round, thin gold-brown clay frames
gl = []
for (cx, cy) in (EL, ER_):
    gl.append(f'<circle cx="{X(cx)}" cy="{Y(cy)}" r="98" fill="#FFFFFF" fill-opacity=".07"/>'
              f'<circle cx="{X(cx)}" cy="{Y(cy)}" r="98" fill="none" stroke="#5A3E1A" stroke-width="15"/>'
              f'<circle cx="{X(cx)}" cy="{Y(cy)}" r="98" fill="none" stroke="url(#gGold)" stroke-width="10"/>'
              f'<path d="M{X(cx)-70},{Y(cy)-55} A90,90 0 0 1 {X(cx)+10},{Y(cy)-95}" fill="none" stroke="#FFF6D0" stroke-width="4" stroke-linecap="round" opacity=".8" filter="url(#sb)"/>'
              f'<ellipse cx="{X(cx)-38}" cy="{Y(cy)-40}" rx="26" ry="12" fill="#fff" opacity=".18" transform="rotate(-30 {X(cx)-38} {Y(cy)-40})"/>')
gl.append(f'<path d="M{X(EL[0])+96},{Y(EY)-12} Q{X(430)},{Y(EY)-38} {X(ER_[0])-96},{Y(EY)-12}" fill="none" stroke="url(#gGold)" stroke-width="10" stroke-linecap="round"/>')
gl.append(f'<path d="M{X(EL[0])-98},{Y(EY)-10} L{X(252)},{Y(EY)-22}" stroke="#5A3E1A" stroke-width="10" stroke-linecap="round"/>')
ACC["acc_L1_glasses"] = svg(f'<g filter="url(#sh)">{"".join(gl)}</g>')

# L2 scarf: knitted cream band with gold stripes around the lower body + hanging tail on the left
band_y0, band_y1 = 1080, 1185
stripes = "".join(f'<rect x="{X(235)}" y="{Y(band_y0 + 18 + i*30)}" width="{1135-235}" height="9" fill="{GOLD}" opacity=".85"/>' for i in range(3))
knit = "".join(f'<path d="M{X(x)},{Y(band_y0+6)} q8,14 0,28 q-8,14 0,28 q8,14 0,28" fill="none" stroke="#C9BCA0" stroke-width="3" opacity=".45"/>' for x in range(255, 1130, 34))
ACC["acc_L2_scarf"] = svg(f'''<g filter="url(#sh)">
<path d="M{X(232)},{Y(band_y0)} Q{X(690)},{Y(band_y0-22)} {X(1140)},{Y(band_y0)} L{X(1140)},{Y(band_y1)} Q{X(690)},{Y(band_y1-16)} {X(232)},{Y(band_y1)} Z" fill="url(#gCream)"/>
{stripes}{knit}
<path d="M{X(232)},{Y(band_y0)} Q{X(690)},{Y(band_y0-22)} {X(1140)},{Y(band_y0)}" fill="none" stroke="#FFFDF6" stroke-width="5" opacity=".7" filter="url(#sb)"/>
<path d="M{X(300)},{Y(band_y1-10)} C{X(290)},{Y(1260)} {X(270)},{Y(1330)} {X(285)},{Y(1420)} L{X(375)},{Y(1410)} C{X(365)},{Y(1330)} {X(380)},{Y(1260)} {X(395)},{Y(band_y1-8)} Z" fill="url(#gCream)"/>
<rect x="{X(282)}" y="{Y(1300)}" width="94" height="10" fill="{GOLD}" opacity=".85" transform="rotate(-3 {X(330)} {Y(1305)})"/>
<g stroke="{GOLD}" stroke-width="6" stroke-linecap="round"><path d="M{X(292)},{Y(1418)} v34"/><path d="M{X(312)},{Y(1418)} v40"/><path d="M{X(332)},{Y(1417)} v36"/><path d="M{X(352)},{Y(1415)} v40"/><path d="M{X(370)},{Y(1413)} v32"/></g>
</g>''')

# L3 chest badge: gold round medal with a navy staircase emblem (on step 1, below the face)
bx, by, br = 418, 905, 60
emb = f'M{X(bx)-34},{Y(by)+26} h68 v-68 h-17 v17 h-17 v17 h-17 v17 h-17 Z'
ACC["acc_L3_badge"] = svg(f'''<g filter="url(#sh)">
<circle cx="{X(bx)}" cy="{Y(by)}" r="{br+7}" fill="#0B1328"/><circle cx="{X(bx)}" cy="{Y(by)}" r="{br}" fill="url(#gGold)"/><circle cx="{X(bx)}" cy="{Y(by)}" r="{br-9}" fill="none" stroke="#8E6E14" stroke-width="4" opacity=".7"/>
<path d="{emb}" fill="{NAVY}"/><path d="{emb}" fill="none" stroke="#0B1328" stroke-width="2"/>
<ellipse cx="{X(bx)-22}" cy="{Y(by)-30}" rx="20" ry="10" fill="#FFF6D0" opacity=".55" transform="rotate(-30 {X(bx)-22} {Y(by)-30})" filter="url(#sb)"/></g>''')

# L4 hat: soft cream beret with gold band + stem, tilted on the step-1 top (slant ~ -10 deg)
hx, hy = 455, 318
ACC["acc_L4_beret"] = svg(f'''<g filter="url(#sh)" transform="rotate(-11 {X(hx)} {Y(hy)})">
<path d="M{X(hx)-215},{Y(hy)+30} C{X(hx)-250},{Y(hy)-70} {X(hx)-90},{Y(hy)-150} {X(hx)+40},{Y(hy)-140} C{X(hx)+200},{Y(hy)-130} {X(hx)+270},{Y(hy)-40} {X(hx)+230},{Y(hy)+30} Z" fill="url(#gCream)"/>
<path d="M{X(hx)-210},{Y(hy)+18} Q{X(hx)+10},{Y(hy)+52} {X(hx)+228},{Y(hy)+18} L{X(hx)+226},{Y(hy)+44} Q{X(hx)+10},{Y(hy)+80} {X(hx)-212},{Y(hy)+44} Z" fill="url(#gGold)"/>
<path d="M{X(hx)-150},{Y(hy)-70} C{X(hx)-80},{Y(hy)-125} {X(hx)+40},{Y(hy)-128} {X(hx)+110},{Y(hy)-100}" fill="none" stroke="#FFFFFF" stroke-width="10" opacity=".55" filter="url(#sb2)"/>
<path d="M{X(hx)+30},{Y(hy)-138} q6,-30 26,-34" fill="none" stroke="#B9AB8E" stroke-width="12" stroke-linecap="round"/>
</g>''')

# sports (ground / hand slots only)
fbx, fby, fbr = 1175, 1728, 92
pent = lambda cx, cy, r, rot: " ".join(f"{cx + r*np.cos(np.radians(rot + 72*i - 90)):.1f},{cy + r*np.sin(np.radians(rot + 72*i - 90)):.1f}" for i in range(5))
patches = f'<polygon points="{pent(X(fbx), Y(fby), 30, 8)}" fill="#3B4252"/>' + "".join(
    f'<polygon points="{pent(X(fbx) + 70*np.cos(np.radians(a)), Y(fby) + 70*np.sin(np.radians(a)), 24, a)}" fill="#3B4252" opacity=".9"/>' for a in (-90, -18, 54, 126, 198))
ACC["sport_football"] = svg(f'''<ellipse cx="{X(fbx)}" cy="{Y(fby)+fbr-6}" rx="{fbr*0.95}" ry="16" fill="#0A1020" opacity=".35" filter="url(#sb2)"/>
<defs><clipPath id="cb"><circle cx="{X(fbx)}" cy="{Y(fby)}" r="{fbr}"/></clipPath></defs>
<circle cx="{X(fbx)}" cy="{Y(fby)}" r="{fbr}" fill="url(#gBall)"/><g clip-path="url(#cb)">{patches}
<circle cx="{X(fbx)+30}" cy="{Y(fby)+38}" r="{fbr}" fill="#0A1020" opacity=".18" filter="url(#sb2)"/></g>
<ellipse cx="{X(fbx)-30}" cy="{Y(fby)-36}" rx="26" ry="14" fill="#fff" opacity=".7" filter="url(#sb)"/>''')

hxr, hyr = 1118, 1455
ACC["sport_gym"] = svg(f'''<g filter="url(#sh)" transform="rotate(-8 {X(hxr)} {Y(hyr)})">
<rect x="{X(hxr)-120}" y="{Y(hyr)-11}" width="240" height="22" rx="11" fill="url(#gMetal)"/>
<rect x="{X(hxr)-150}" y="{Y(hyr)-58}" width="44" height="116" rx="16" fill="url(#gNavy)"/><rect x="{X(hxr)+106}" y="{Y(hyr)-58}" width="44" height="116" rx="16" fill="url(#gNavy)"/>
<rect x="{X(hxr)-178}" y="{Y(hyr)-44}" width="30" height="88" rx="12" fill="url(#gNavy)"/><rect x="{X(hxr)+148}" y="{Y(hyr)-44}" width="30" height="88" rx="12" fill="url(#gNavy)"/>
<rect x="{X(hxr)-146}" y="{Y(hyr)-52}" width="10" height="104" rx="5" fill="{GOLD}" opacity=".85"/><rect x="{X(hxr)+136}" y="{Y(hyr)-52}" width="10" height="104" rx="5" fill="{GOLD}" opacity=".85"/>
<rect x="{X(hxr)-140}" y="{Y(hyr)-50}" width="16" height="40" rx="8" fill="#fff" opacity=".18"/><rect x="{X(hxr)+116}" y="{Y(hyr)-50}" width="16" height="40" rx="8" fill="#fff" opacity=".18"/>
</g>''')

vbx, vby, vbr = 205, 1330, 98
ACC["sport_volleyball"] = svg(f'''<g filter="url(#sh)"><defs><clipPath id="cv"><circle cx="{X(vbx)}" cy="{Y(vby)}" r="{vbr}"/></clipPath></defs>
<circle cx="{X(vbx)}" cy="{Y(vby)}" r="{vbr}" fill="url(#gBall)"/>
<g clip-path="url(#cv)" fill="none" stroke="#8A93A6" stroke-width="6" opacity=".85">
<path d="M{X(vbx)-100},{Y(vby)-20} C{X(vbx)-30},{Y(vby)-60} {X(vbx)+40},{Y(vby)-40} {X(vbx)+100},{Y(vby)+20}"/>
<path d="M{X(vbx)-70},{Y(vby)+80} C{X(vbx)-50},{Y(vby)+10} {X(vbx)-10},{Y(vby)-50} {X(vbx)+10},{Y(vby)-100}"/>
<path d="M{X(vbx)+30},{Y(vby)+100} C{X(vbx)+20},{Y(vby)+30} {X(vbx)+50},{Y(vby)-20} {X(vbx)+100},{Y(vby)-50}"/>
<circle cx="{X(vbx)+30}" cy="{Y(vby)+40}" r="{vbr}" fill="#0A1020" stroke="none" opacity=".16" filter="url(#sb2)"/></g>
<ellipse cx="{X(vbx)-32}" cy="{Y(vby)-40}" rx="26" ry="14" fill="#fff" opacity=".75" filter="url(#sb)"/></g>''')

mx0, mx1, my, mr = 1035, 1310, 1752, 50
ACC["sport_yoga"] = svg(f'''<ellipse cx="{X((mx0+mx1)/2)}" cy="{Y(my)+mr}" rx="{(mx1-mx0)/2+10}" ry="14" fill="#0A1020" opacity=".35" filter="url(#sb2)"/>
<g filter="url(#sh)"><rect x="{X(mx0)}" y="{Y(my)-mr}" width="{mx1-mx0}" height="{2*mr}" rx="{mr}" fill="url(#gCream)"/>
<rect x="{X(mx0)+70}" y="{Y(my)-mr}" width="22" height="{2*mr}" fill="{GOLD}" opacity=".9"/><rect x="{X(mx1)-110}" y="{Y(my)-mr}" width="22" height="{2*mr}" fill="{GOLD}" opacity=".9"/>
<ellipse cx="{X(mx0)+12}" cy="{Y(my)}" rx="22" ry="{mr}" fill="#E8DCC2"/>
<path d="M{X(mx0)+12},{Y(my)} m0,-34 a14,34 0 1 1 0,68 a10,24 0 1 1 0,-48 a6,14 0 1 1 0,28" fill="none" stroke="#B9AB8E" stroke-width="4"/>
<rect x="{X(mx0)+30}" y="{Y(my)-mr+8}" width="{mx1-mx0-60}" height="16" rx="8" fill="#fff" opacity=".35" filter="url(#sb)"/></g>''')

LAYERS = {}
for k, s in ACC.items():
    p = WORK / f"_{k}.png"
    html_to_png(f"<!doctype html><style>html,body{{margin:0;background:transparent}}</style>{s}", p, CANVAS, CANVAS)
    LAYERS[k] = np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)

for _k, _f in (("acc_L2_scarf", "scarf"), ("sport_gym", "gym"), ("sport_volleyball", "volleyball"), ("sport_yoga", "yoga")):
    LAYERS[_k] = np.asarray(Image.open(WORK / f"prop_{_f}.png").convert("RGBA")).astype(np.float32)

# running sneakers: recolour gold panels -> navy sport panels + gold sole line (shoe region only)
hsv = cv2.cvtColor(r1.astype(np.uint8)[:, :, ::-1], cv2.COLOR_BGR2HSV).astype(np.float32)
yyr = np.mgrid[0:H1, 0:W1][0]
shoe_zone = (yyr > 1500) & (alpha > 0.5)
goldm = cv2.GaussianBlur((shoe_zone & (np.abs(hsv[..., 0] * 2 - 46) < 16) & (hsv[..., 1] > 70)).astype(np.float32), (0, 0), 1.2)
creamm = shoe_zone & (hsv[..., 1] < 70) & (hsv[..., 2] > 150)
lum1 = (r1 @ np.array([0.299, 0.587, 0.114], np.float32))[..., None]
navyp = np.clip(np.array([0x2C, 0x45, 0x86], np.float32) / 70.0 * lum1 * 0.55, 0, 255)
run = r1.copy()
run = run * (1 - goldm[..., None]) + navyp * goldm[..., None]
# gold sole stripe: lowest band of cream pixels per column (sole top edge)
sole = np.zeros((H1, W1), np.float32)
for x in range(250, 1080):
    col = np.nonzero(creamm[:, x])[0]
    if len(col) > 20:
        b = col.max()
        sole[b - 46:b - 36, x] = 1
sole = cv2.GaussianBlur(sole, (0, 0), 1.2)
run = run * (1 - sole[..., None]) + (GOLDV * np.clip(lum1 / 200, 0.6, 1.1)) * sole[..., None]
run_a = np.clip(goldm + sole, 0, 1) * (alpha > 0.5)
LAYERS["sport_running_shoes"] = np.dstack([to_canvas(run), to_canvas(run_a)[..., None] * 255])

# ----------------------------------------------------------------- export
def over(img, rgba):
    a = rgba[..., 3:] / 255
    return np.dstack([img[..., :3] * (1 - a) + rgba[..., :3] * a * 1, 255 - (255 - img[..., 3:]) * (1 - a)])


def over_rgba(dst, src):
    """Porter-Duff source-over on straight-alpha float RGBA."""
    sa, da = src[..., 3:] / 255, dst[..., 3:] / 255
    oa = sa + da * (1 - sa)
    rgb = (src[..., :3] * sa + dst[..., :3] * da * (1 - sa)) / np.maximum(oa, 1e-6)
    return np.dstack([rgb, oa * 255])


def premul_resize(rgba, size):
    a = rgba[..., 3:] / 255
    pm = np.dstack([rgba[..., :3] * a, rgba[..., 3:]])
    r = cv2.resize(pm, (size, size), interpolation=cv2.INTER_AREA)
    a2 = r[..., 3:] / 255
    rgb = r[..., :3] / np.maximum(a2, 1e-6)
    return np.clip(np.dstack([rgb, r[..., 3:]]), 0, 255).astype(np.uint8)


sizes = {}


def export(name, rgba, q=82):
    big = np.clip(rgba, 0, 255).astype(np.uint8)
    Image.fromarray(big, "RGBA").save(OUT / "layers_png" / f"{name}_{CANVAS}.png", optimize=True)
    for s in (512, 256):
        im = Image.fromarray(premul_resize(rgba, s), "RGBA")
        im.save(OUT / f"png{s}" / f"{name}.png", optimize=True)
        im.save(OUT / f"webp{s}" / f"{name}.webp", quality=q, method=6, exact=False)
        sizes[f"webp{s}/{name}.webp"] = (OUT / f"webp{s}" / f"{name}.webp").stat().st_size


export("lam_shadow", SHADOW)
export("lam_body", BODY)
for k, f in FACE.items():
    export(f"lam_face_{k}", f)
export("lam_face_E01_blink", BLINK)
for k, v in STEPS.items():
    export(k, v)
for k, v in LAYERS.items():
    export(k, v)

ORDER = ["lam_shadow", "lam_body", "steps_lit_L*", "sport_running_shoes", "lam_face_*", "acc_L2_scarf", "acc_L3_badge", "acc_L1_glasses", "acc_L4_beret",
         "sport_football | sport_volleyball | sport_gym | sport_yoga"]


def comp(face_k="E01_smirk", level=0, sport=None):
    img = over_rgba(SHADOW.copy(), BODY)
    if level:
        img = over_rgba(img, STEPS[f"steps_lit_L{level}"])
    if sport == "running":
        img = over_rgba(img, LAYERS["sport_running_shoes"])
    img = over_rgba(img, FACE[face_k] if face_k != "blink" else BLINK)
    for lv, name in ((2, "acc_L2_scarf"), (3, "acc_L3_badge"), (1, "acc_L1_glasses"), (4, "acc_L4_beret")):
        if level >= lv:
            img = over_rgba(img, LAYERS[name])
    if sport and sport != "running":
        img = over_rgba(img, LAYERS[f"sport_{sport}"])
    return img


# full composites for the 4 base face states
for k in FACE:
    export(f"lam_full_{k}", comp(k))

json.dump({
    "canvas_px": CANVAS, "export_sizes": [512, 256],
    "note": "all layers share the same square canvas; stack in this order with no offsets (left:0;top:0;width:100%)",
    "layer_order_bottom_to_top": ORDER,
    "levels": {"L1": ["steps_lit_L1", "acc_L1_glasses"], "L2": ["steps_lit_L2", "acc_L1_glasses", "acc_L2_scarf"],
               "L3": ["steps_lit_L3", "acc_L1_glasses", "acc_L2_scarf", "acc_L3_badge"], "L4": ["steps_lit_L4", "acc_L1_glasses", "acc_L2_scarf", "acc_L3_badge", "acc_L4_beret"]},
    "slots": {"face": "acc_L1_glasses", "chest_band": "acc_L2_scarf", "chest": "acc_L3_badge", "head": "acc_L4_beret",
              "feet": "sport_running_shoes", "ground_right": ["sport_football", "sport_yoga"], "hand_right": "sport_gym", "hand_left": "sport_volleyball"},
    "rule": "sport = exactly one of the sport_* layers, never on head/face/neck/chest; reading accessories are cumulative",
    "anchors_canvas_px": {k: [round(v[0] + OX), round(v[1] + OY)] for k, v in {
        "eye_L": EL, "eye_R": ER_, "mouth": G["mouth"], "head_top": (hx, hy), "chest_badge": (bx, by), "scarf_band_center": (690, 1100),
        "hand_L": (215, 1455), "hand_R": (1110, 1455), "foot_L": (470, 1720), "foot_R": (890, 1730), "ground_right": (fbx, fby)}.items()},
    "anchors_normalized_0_1": {k: [round((v[0] + OX) / CANVAS, 4), round((v[1] + OY) / CANVAS, 4)] for k, v in {
        "eye_L": EL, "eye_R": ER_, "mouth": G["mouth"], "head_top": (hx, hy), "chest_badge": (bx, by), "hand_L": (205, 1400), "hand_R": (hxr, hyr),
        "foot_L": (470, 1720), "foot_R": (890, 1730)}.items()},
}, open(OUT / "lam_app_anchors.json", "w"), indent=1)

# ----------------------------------------------------------------- preview sheet
tiles = [("پایه · E01", comp()), ("E10", comp("E10_happy")), ("E03", comp("E03_curious")), ("E08", comp("E08_kind")),
         ("L1", comp(level=1)), ("L2", comp(level=2)), ("L3", comp(level=3)), ("L4", comp("E10_happy", 4)),
         ("فوتبال", comp(sport="football")), ("باشگاه", comp(sport="gym")), ("دویدن", comp(sport="running")),
         ("والیبال", comp(sport="volleyball")), ("یوگا", comp(sport="yoga")),
         ("L2 + فوتبال", comp(level=2, sport="football")), ("L4 + باشگاه", comp("E10_happy", 4, "gym"))]
T = 300
cols = 5
rows = (len(tiles) + cols - 1) // cols
sheet = np.zeros((rows * (T + 46) + 20, cols * (T + 20) + 20, 3), np.uint8)
sheet[:] = (0x14, 0x1F, 0x38)
labels = []
for i, (lab, im) in enumerate(tiles):
    x, y = 20 + (i % cols) * (T + 20), 20 + (i // cols) * (T + 46)
    card = np.zeros((T, T, 3), np.float32) + np.array([0xF3, 0xF0, 0xE8], np.float32) if i % 2 == 0 else np.zeros((T, T, 3), np.float32) + np.array([0x24, 0x33, 0x5C], np.float32)
    s = premul_resize(im, T).astype(np.float32)
    a = s[..., 3:] / 255
    sheet[y:y + T, x:x + T] = (card * (1 - a) + s[..., :3] * a).astype(np.uint8)
    labels.append((lab, x, y + T + 34))
pv = OUT / "preview" / "lam_app_preview_sheet.png"
Image.fromarray(sheet).save(pv)
# Persian labels via Edge overlay
from render_util import FONT
lab_html = "".join(f"<div style='position:absolute;left:{x}px;top:{y-30}px;width:{T}px;text-align:center;color:#F3F0E8;font:600 22px Vaz'>{l}</div>" for l, x, y in labels)
lp = WORK / "_labels.png"
H_, W_ = sheet.shape[:2]
html_to_png(f"<!doctype html><meta charset='utf-8'><style>@font-face{{font-family:Vaz;src:url('{FONT}')}}html,body{{margin:0;background:transparent;direction:rtl}}</style>{lab_html}", lp, W_, H_)
la = np.asarray(Image.open(lp).convert("RGBA")).astype(np.float32)
sheet = (sheet * (1 - la[..., 3:] / 255) + la[..., :3] * la[..., 3:] / 255).astype(np.uint8)
Image.fromarray(sheet).save(pv)
# phone-size check (tiles at ~120 px like a card in the app)
small = np.zeros((170, 20 + len(tiles[:8]) * 140, 3), np.uint8) + np.array([0xF3, 0xF0, 0xE8], np.uint8)
for i, (lab, im) in enumerate(tiles[:4] + tiles[7:8] + tiles[8:9] + tiles[13:15]):
    s = premul_resize(im, 128).astype(np.float32); a = s[..., 3:] / 255
    x = 20 + i * 140
    small[20:148, x:x + 128] = (small[20:148, x:x + 128] * (1 - a) + s[..., :3] * a).astype(np.uint8)
Image.fromarray(small).save(OUT / "preview" / "lam_app_phone_size_check.png")

# ----------------------------------------------------------------- animated WebP (512, ≤2 s loops)
def anim(name, frames, dur_ms):
    ims = [Image.fromarray(premul_resize(f, 512), "RGBA") for f in frames]
    p = OUT / "anim" / f"{name}.webp"
    ims[0].save(p, save_all=True, append_images=ims[1:], duration=dur_ms, loop=0, quality=72, method=6, allow_mixed=False)
    sizes[f"anim/{name}.webp"] = p.stat().st_size


base_open = comp()
base_blink = comp("blink")
half = over_rgba(comp(), np.dstack([BLINK[..., :3], BLINK[..., 3:] * 0.55]))
blink_frames = [base_open] * 1 + [half, base_blink, half] + [base_open]
anim("lam_anim_idle_blink", blink_frames, [1500, 50, 70, 50, 330])

# level-up: step 4 (level 1) glazes in with a soft pulse, 1.6 s @ 12 fps
from gold_step import GOLD as _g  # noqa
lvl = []
for i in range(20):
    t = i / 12
    amt = 1 - (1 - min(t / 0.6, 1)) ** 3
    pulse = np.exp(-((t - 0.55) / 0.25) ** 2)
    img = over_rgba(SHADOW.copy(), BODY)
    img = over_rgba(img, glaze_layer([4], amt))
    gm = cv2.GaussianBlur(STEPMASK[4], (0, 0), 40)[..., None] * (0.25 * amt + 0.6 * pulse)
    glow = np.dstack([np.zeros((CANVAS, CANVAS, 3), np.float32) + GOLDV, np.clip(gm, 0, 1) * 255 * 0.7])
    img = over_rgba(img, glow)
    img = over_rgba(img, FACE["E10_happy"] if t > 0.3 else FACE["E01_smirk"])
    lvl.append(img)
anim("lam_anim_levelup_step", lvl, [83] * 19 + [700])

json.dump(sizes, open(OUT / "sizes.json", "w"), indent=1)
print("max webp512", max(v for k, v in sizes.items() if k.startswith("webp512")), "anims", {k: v for k, v in sizes.items() if k.startswith("anim")})
