"""«بهانه‌های لَم» episode 1 — v3 tighter cut (2026-11-07).
Same layers / voices / music as v2 (ep1_assemble_v2.py), rebuilt with:
  * word-group audio cuts with exact boundaries (no dead air), voices re-timed with pitch-preserving atempo,
  * a camera change every ~2-3 s (push-ins, book close-up, face punch-ins, Flow reading bridge with page badges),
  * hook from frame 0 inside the safe zone, CTA overlaid on the gold-step payoff instead of a separate end card.
Usage: python ep1_assemble_v3.py [full|short]   (short = drops the bookmark exchange; option only)
Outputs ep1/lam_ep1_final_v3.mp4 (or _v3_short.mp4). v2 files are not touched.
"""
from pathlib import Path
import copy, json, subprocess, sys, wave
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
import lam_facekit as K
from render_util import html_to_png, FONT
from gold_step import ding_wav

VARIANT = sys.argv[1] if len(sys.argv) > 1 else "full"
TAG = "v3" if VARIANT == "full" else "v3_short"
ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
W0 = MASCOT.parent                                   # peleh_work
EP = MASCOT / "ep1"
BUILD = EP / "_build"
B3 = EP / "_build_v3"
B3.mkdir(exist_ok=True)
FF = imageio_ffmpeg.get_ffmpeg_exe()
FPS, SR = 30, 44100
NAVY, GOLD, CREAM = "#1B2A4A", "#C9A227", "#F3F0E8"
TEMPO = 1.12 if VARIANT == "full" else 1.10
TARGET_I = -14.0


# =============================================================== audio
def load(p, sr=SR):
    raw = subprocess.run([FF, "-v", "quiet", "-i", str(p), "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768


def rms_frames(x, hop):
    n = len(x) // hop
    return np.sqrt((x[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12)


def fade(x, ms=15):
    n = int(SR * ms / 1000)
    x = x.copy()
    x[:n] *= np.linspace(0, 1, n)
    x[-n:] *= np.linspace(1, 0, n)
    return x


def tempo(y, f):
    if abs(f - 1) < 1e-3:
        return y
    out = subprocess.run([FF, "-v", "quiet", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "-", "-af", f"atempo={f}", "-f", "f32le", "-"],
                         input=y.astype(np.float32).tobytes(), capture_output=True).stdout
    return np.frombuffer(out, np.float32).copy()


lam = load(EP / "voice" / "lam_ep1_lam.mp3")
pel = load(EP / "voice" / "lam_ep1_peleh.mp3")
# (key, speaker, src start, src end, gap before) — boundaries read from a 20 ms energy/centroid profile;
# every word kept (v2 started «یه صفحه…» at 13.32 and clipped «یه»; here it starts at 13.04).
ITEMS = [
    ("a1", "L", 0.06, 3.38, 0.03),    # سه ماهه کتابم رو صفحه‌ی دوازده مونده.
    ("a2", "L", 4.54, 5.78, 0.11),    # ولی نشونه‌ش…
    ("a3", "L", 5.95, 6.93, 0.08),    # خیلی قشنگه.
    ("p1", "P", 0.30, 1.40, 0.06),    # قشنگه.
    ("p2", "P", 1.99, 3.64, 0.08),    # صفحه‌ی سیزده چطوره؟
    ("b1", "L", 8.72, 10.24, 0.06),   # سیزده…
    ("b2", "L", 10.92, 11.62, 0.12),  # نحسه.
    ("p3", "P", 4.98, 6.38, 0.06),    # فقط یه صفحه.
    ("p4", "P", 6.86, 8.30, 0.08),    # نحسیش با من.
    ("c1", "L", 13.04, 15.12, 0.07),  # یه صفحه که حساب نمی‌شه…
    ("c2", "L", 17.94, 18.50, 0.10),  # خب…
    ("c3", "L", 18.88, 20.12, 0.10),  # چهارده‌م خوندم.
]
if VARIANT == "short":
    ITEMS = [it for it in ITEMS if it[0] not in ("a2", "a3", "p1")]
    ITEMS = [(k, s, a, b, (0.08 if k == "p2" else g)) for k, s, a, b, g in ITEMS]
segs, t = {}, 0.0
for key, spk, a, b, gap in ITEMS:
    src = lam if spk == "L" else pel
    y = fade(tempo(fade(src[int(a * SR):int(b * SR)]), TEMPO))
    t += gap
    segs[key] = (t, t + len(y) / SR, y, spk)
    t += len(y) / SR
S_ = lambda k: segs[k][0]
E_ = lambda k: segs[k][1]
CTA_LEN = 1.05
T_GOLD = S_("c3") + 0.05
T_CTA = E_("c3") + 0.08
DUR = T_CTA + CTA_LEN
# reading bridge (Flow clip): E05 grumble shot for the first 0.55 s of c1, then the page-turn clip until «خب…»
BR0 = S_("c1") + 0.55
BR_END = S_("c2") - 0.04
BR_LEN = BR_END - BR0
FLOW_OUT = 7.30
FLOW_SPEED = float(np.clip(2.80 / BR_LEN, 1.10, 1.50))
FLOW_IN = FLOW_OUT - BR_LEN * FLOW_SPEED - 0.05
src_t = lambda s: BR0 + (s - FLOW_IN) / FLOW_SPEED
T_P14 = min(src_t(7.00), BR_END - 0.45)                 # keep «۱۴» readable before the cut back
T_P13 = min(src_t(5.70), T_P14 - 0.55)
print({k: (round(v[0], 2), round(v[1], 2)) for k, v in segs.items()})
print("bridge", round(BR0, 2), round(BR_END, 2), "speed", round(FLOW_SPEED, 2), "p13", round(T_P13, 2), "p14", round(T_P14, 2),
      "gold", round(T_GOLD, 2), "cta", round(T_CTA, 2), "DUR", round(DUR, 2))

N = int(round(DUR * FPS))
NS = int(DUR * SR) + SR
lam_tr, pel_tr = np.zeros(NS, np.float32), np.zeros(NS, np.float32)
for key, (a, b, y, spk) in segs.items():
    tr = lam_tr if spk == "L" else pel_tr
    i = int(a * SR); tr[i:i + len(y)] += y[:max(0, min(len(y), NS - i))]

# =============================================================== lip-sync (same as v2)
hop = SR // FPS


def frame_feats(x):
    rms, cen = [], []
    win = np.hanning(2048)
    f = np.fft.rfftfreq(2048, 1 / SR)
    for k in range(N):
        c = int((k + 0.5) * hop)
        seg = x[max(0, c - 1024):c + 1024]
        if len(seg) < 2048:
            seg = np.pad(seg, (0, 2048 - len(seg)))
        rms.append(np.sqrt((x[k * hop:(k + 1) * hop] ** 2).mean() + 1e-12))
        sp = np.abs(np.fft.rfft(seg * win))
        cen.append((sp * f).sum() / (sp.sum() + 1e-9))
    return np.array(rms), np.array(cen)


lr, lc = frame_feats(lam_tr)
lr = np.convolve(lr, [0.25, 0.5, 0.25], "same")
p95 = np.percentile(lr[lr > 0.01], 95)


def viseme(k):
    o = min(1.0, lr[k] / (0.65 * p95))
    c = lc[k]
    if o < 0.13:
        return "X"
    if o < 0.30:
        return "A_MBP" if c < 1300 else "B_SSH"
    if c > 3400:
        return "B_SSH"
    if c > 2300:
        return "EE_wide" if o > 0.55 else "C_E"
    if c < 1050:
        return "E_O" if o > 0.5 else "F_OO"
    if 1600 < c < 2000 and o < 0.5:
        return "H_L"
    return "D_AA" if o > 0.72 else "C_E"


vis = [viseme(k) for k in range(N)]
for k in range(1, N - 1):
    if vis[k] != vis[k - 1] and vis[k] != vis[k + 1]:
        vis[k] = vis[k - 1]

# =============================================================== layers (cached from v2 build, read-only)
base = cv2.imread(str(MASCOT / "renders_vahid" / "R3a.jpg"))[:, :, ::-1].astype(np.float32)
H0, W0p = base.shape[:2]
NAVY_L = 0.299 * 0x1B + 0.587 * 0x2A + 0.114 * 0x4A
S = 1080 / W0p
HS = round(H0 * S)
PAD_T = (1920 - HS) // 2
L = dict(np.load(BUILD / "layers.npz"))
BASE = cv2.resize(base, (1080, HS), interpolation=cv2.INTER_AREA)
LOCAL_S = cv2.GaussianBlur(BASE, (0, 0), 18)


def over(img, rgba):
    rgba = rgba.astype(np.float32)
    a = rgba[..., 3:] / 255
    return img * (1 - a) + rgba[..., :3] * a


def pad_canvas(small):
    out = np.zeros((1920, 1080, 3), np.float32)
    out[PAD_T:PAD_T + HS] = small
    def ext(up, n):
        band = (small[:120] if up else small[-120:])[::-1]
        rep = np.concatenate([band] * (n // 120 + 2), 0)[:n]
        rep = cv2.GaussianBlur(rep, (0, 0), 28) * np.linspace(1.0, 0.82, n)[:, None, None]
        return rep[::-1] if up else rep
    out[:PAD_T] = ext(True, PAD_T)
    out[PAD_T + HS:] = ext(False, 1920 - PAD_T - HS)
    bl = cv2.GaussianBlur(out, (0, 0), 8)
    ys = np.arange(1920)[:, None, None]
    w = np.zeros((1920, 1, 1), np.float32)
    for y0 in (PAD_T, PAD_T + HS):
        w = np.maximum(w, np.clip(1 - np.abs(ys - y0) / 36.0, 0, 1))
    return out * (1 - w) + bl * w


PAD_BG = pad_canvas(BASE)
yy, xx = np.mgrid[0:HS, 0:1080].astype(np.float32)
cx, cy, rr = 670 * S, 760 * S, 435 * S
d = np.abs(np.hypot(xx - cx, yy - cy) - rr)
warm = (BASE[..., 0] > 150) & (BASE[..., 0] > BASE[..., 2] + 20)
ring = cv2.GaussianBlur(((d < 26) & warm).astype(np.float32), (0, 0), 10)
ring = ring / (ring.max() + 1e-6)

P1 = np.array([(480, 618), (496, 598), (688, 576), (698, 584), (826, 606), (832, 732), (700, 740), (700, 1010), (478, 1010)], np.float32) * S
sm = np.zeros((HS, 1080), np.uint8); cv2.fillPoly(sm, [P1.astype(np.int32)], 255)
cv2.circle(sm, (int(662 * S), int(802 * S)), int(64 * S), 255, -1)
STEP = cv2.GaussianBlur(sm.astype(np.float32) / 255, (0, 0), 1.0) * np.clip((1010 * S - yy) / (90 * S), 0, 1)

# =============================================================== Flow clip (page turn)
raw = subprocess.run([FF, "-v", "quiet", "-ss", f"{FLOW_IN:.3f}", "-t", f"{FLOW_OUT - FLOW_IN + 0.15:.3f}", "-i", str(EP / "flow" / "ep1_flow_pageturn.mp4"),
                      "-vf", f"setpts=PTS/{FLOW_SPEED:.4f},fps=30,scale=1080:1920:flags=lanczos", "-an", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                     capture_output=True).stdout
FLOW = np.frombuffer(raw, np.uint8).reshape(-1, 1920, 1080, 3)
print("flow frames", len(FLOW), "src", round(FLOW_IN, 2), "->", FLOW_OUT)

# =============================================================== overlays (Edge, Vazirmatn). Safe zone: nothing above y=220 or below y=1540.
CSS = (f"@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}"
       "html,body{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}"
       "body{font-family:Vaz;direction:rtl}")


def overlay(name, body, folder=BUILD):
    p = folder / f"ov_{name}.png"
    if not p.exists():
        html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style>{body}", p, 1080, 1920)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def badge(num, spark=False):
    sp = (f"<span style='position:absolute;left:-46px;top:-30px;font-size:64px;font-weight:900;color:{GOLD};text-shadow:0 0 18px rgba(201,162,39,.9)'>!</span>"
          f"<span style='position:absolute;left:-14px;top:-44px;font-size:34px;color:#FFE59A'>✦</span>") if spark else ""
    return (f"<div style='position:absolute;left:0;right:0;top:300px;text-align:center'><div style='display:inline-block;position:relative;"
            f"background:rgba(14,22,40,.82);border:3px solid {GOLD};border-radius:34px;padding:14px 46px;font-size:84px;font-weight:800;color:{CREAM}'>"
            f"صفحه‌ی <span style='color:{GOLD}'>{num}</span>{sp}</div></div>")


OV = {   # subtitle overlays are the v2 PNGs (same text, same style)
    "L1b": overlay("L1b", ""), "P1": overlay("P1", ""), "L2": overlay("L2", ""), "P2": overlay("P2", ""),
    "L3a": overlay("L3a", ""), "L3b1": overlay("L3b1", ""), "L3b2": overlay("L3b2", ""),
    "b12": overlay("b12", ""), "b13": overlay("b13", ""), "b14": overlay("b14", ""),
}
OV["hook"] = overlay("hook_v3", f"<div style='position:absolute;left:60px;right:60px;top:252px;text-align:center'>"
                                f"<div style='display:inline-block;background:rgba(14,22,40,.82);border:2px solid rgba(201,162,39,.6);border-radius:28px;padding:20px 38px;"
                                f"font-size:70px;font-weight:800;line-height:1.42;color:{CREAM}'>۳ ماهه کتابم رو<br>صفحه‌ی <span style='color:{GOLD}'>۱۲</span> مونده.</div></div>", B3)
OV["b14s"] = overlay("b14s_v3", f"<div style='position:absolute;right:46px;top:250px;background:rgba(14,22,40,.78);border:2px solid {GOLD};border-radius:22px;"
                                f"padding:6px 22px;font-size:40px;font-weight:800;color:{CREAM}'>صفحه‌ی <span style='color:{GOLD}'>۱۴</span></div>", B3)
ICON = (W0 / "app_ref" / "icon-512.png").as_uri()
OV["cta"] = overlay("cta_v3", f"<div style='position:absolute;left:50px;right:50px;top:250px;text-align:center'>"
                              f"<div style='display:inline-block;background:rgba(14,22,40,.86);border:2px solid rgba(201,162,39,.7);border-radius:30px;padding:22px 44px'>"
                              f"<div style='font-size:76px;font-weight:800;color:{CREAM};line-height:1.35'>بهانه‌ی خودت چیه؟</div>"
                              f"<div style='font-size:40px;font-weight:600;color:{GOLD};margin-top:6px'>بنویس، شاید قسمت بعدی مال تو باشه.</div></div></div>"
                              f"<div style='position:absolute;left:0;right:0;top:1400px;text-align:center'>"
                              f"<div style='display:inline-flex;align-items:center;gap:18px;background:rgba(14,22,40,.80);border-radius:26px;padding:12px 28px 12px 18px'>"
                              f"<img src='{ICON}' style='width:84px;height:84px;border-radius:20px;box-shadow:0 0 0 2px {GOLD}'>"
                              f"<span style='font-size:50px;font-weight:800;color:{CREAM}'>پله</span></div></div>", B3)


# =============================================================== shots: (from, kind, face, frown, rest, z0, z1, fx, fy, subtitle)
def mid(a, b):
    return (E_(a) + S_(b)) / 2


SHOTS = []
if VARIANT == "full":
    SHOTS += [(0.0, "talk", "E01cam", 0, "X", 1.00, 1.07, 540, 900, None),
              (mid("a1", "a2"), "talk", "E01book", 0, "X", 1.62, 1.72, 380, 1010, "L1b"),     # cut: book / bookmark close-up
              (mid("a3", "p1"), "listen", "E08", 0, "rest_smile_soft", 1.16, 1.24, 540, 860, "P1")]
else:
    SHOTS += [(0.0, "talk", "E01cam", 0, "X", 1.00, 1.07, 540, 900, None),
              (mid("a1", "p2"), "listen", "E08", 0, "rest_smile_soft", 1.62, 1.72, 380, 1010, "P1s")]
    OV["P1s"] = overlay("P1s_v3", f"<div style='position:absolute;left:50px;right:50px;top:1432px;text-align:center'>"
                                  f"<span style='display:inline-block;background:rgba(14,22,40,.72);border-radius:22px;padding:10px 30px;"
                                  f"font-size:58px;font-weight:700;line-height:1.35;color:{GOLD}'>صفحه‌ی سیزده چطوره؟</span></div>", B3)
SHOTS += [(mid("p2", "b1"), "talk", "E03", 0, "X", 1.55, 1.62, 490, 840, "L2"),               # punch-in on the face: the excuse
          (S_("b2") - 0.04, "talk", "E03", 0, "X", 1.90, 1.95, 490, 850, "L2"),               # tighter punch on «نحسه»
          (mid("b2", "p3"), "listen", "E08", 0, "rest_smile_soft", 1.08, 1.15, 540, 880, "P2"),
          (mid("p4", "c1"), "talk", "E05", 1, "X", 1.36, 1.40, 500, 860, "L3a"),
          (BR0, "flow", None, 0, None, 1.04, 1.12, 540, 960, "L3a"),
          (BR_END, "talk", "E10", 0, "rest_smirk_wide", 1.26, 1.10, 530, 880, "L3b1"),        # slow pull-out on the payoff
          (S_("c3") - 0.04, "talk", "E10", 0, "rest_smirk_wide", 1.26, 1.10, 530, 880, "L3b2")]


def shot_at(t):
    i = max(j for j, s in enumerate(SHOTS) if s[0] <= t + 1e-6)
    s = SHOTS[i]
    # payoff pull-out runs across both c2/c3 shots as one move
    if s[1] == "talk" and s[2] == "E10":
        a0, a1 = BR_END, DUR
    else:
        a0, a1 = s[0], (SHOTS[i + 1][0] if i + 1 < len(SHOTS) else DUR)
    u = np.clip((t - a0) / max(1e-3, a1 - a0), 0, 1)
    u = u * u * (3 - 2 * u) if s[2] == "E10" else u
    return i, s, s[5] + (s[6] - s[5]) * u


def cam(img, z, fx, fy):
    cw, ch = 1080 / z, 1920 / z
    x0 = float(np.clip(fx - cw / 2, 0, 1080 - cw)); y0 = float(np.clip(fy - ch / 2, 0, 1920 - ch))
    M = np.float32([[z, 0, -x0 * z], [0, z, -y0 * z]])
    out = cv2.warpAffine(img, M, (1080, 1920), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
    if z > 1.3:
        out = out + 0.35 * (out - cv2.GaussianBlur(out, (0, 0), 1.2))
    return out


GOLDV = np.array([0xC9, 0xA2, 0x27], np.float32)
_er = cv2.erode((STEP > 0.5).astype(np.uint8), np.ones((15, 15), np.uint8)).astype(np.float32)
RIM = np.clip(cv2.GaussianBlur((STEP > 0.5).astype(np.float32) - _er, (0, 0), 3) * 1.6, 0, 1)
ys_ = np.nonzero(STEP > 0.5)[0]
xs_all = np.nonzero(STEP > 0.5)[1]
RIM = RIM * cv2.GaussianBlur(((yy < ys_.min() + 45) | (xx < xs_all.min() + 22)).astype(np.float32), (0, 0), 6)
GRAD = np.clip((ys_.max() - yy) / (ys_.max() - ys_.min()), 0, 1)
_soft = cv2.GaussianBlur(STEP, (0, 0), 14)
GLAZE_W = np.clip(_soft * (0.38 + 0.42 * GRAD) + RIM * 0.40, 0, 0.92)[..., None]
GLOW = cv2.GaussianBlur(STEP, (0, 0), 0.4 * 160 * S)[..., None]


def glaze_amount(dt):
    x = np.clip(dt / 0.6, 0, 1)
    return 1 - (1 - x) ** 3


def glaze(img, dt):
    a = glaze_amount(dt)
    lum = (img @ np.array([0.299, 0.587, 0.114], np.float32))[..., None]
    gold_col = np.clip(GOLDV / 159.6 * lum * 1.85 * np.array([1.18, 0.96, 0.62], np.float32), 0, 255)
    s = GLAZE_W * 0.62 * a
    out = img * (1 - s) + gold_col * s
    peak = np.exp(-((dt - 0.45) / 0.22) ** 2)
    g = GLOW * (0.10 * a + 0.22 * peak)
    out = 255 - (255 - out) * (1 - g * GOLDV / 255)
    if 0.15 < dt < 1.4:
        rng = np.random.default_rng(5)
        xs_ = np.nonzero(STEP[int(ys_.min()) + 5] > 0.5)[0]
        lay = np.zeros(img.shape[:2], np.float32)
        for i in range(4):
            q = (dt - 0.15 - i * 0.1) / 0.9
            if 0 < q < 1:
                x0 = rng.uniform(xs_.min() + 10, xs_.max() - 10)
                cv2.circle(lay, (int(x0 + 5 * np.sin(q * 6 + i)), int(ys_.min() + 8 - q * 110)), 3, float((1 - q) ** 0.7), -1, cv2.LINE_AA)
        lay = cv2.GaussianBlur(lay, (0, 0), 1.3) + cv2.GaussianBlur(lay, (0, 0), 5) * 1.4
        out = 255 - (255 - out) * (1 - np.clip(lay, 0, 1)[..., None] * (GOLDV + 40) / 255)
    return out


def warm_lids(rgba, a, glazed):
    f = rgba.astype(np.float32).copy()
    rgb = f[..., :3]
    lum = rgb @ np.array([0.299, 0.587, 0.114], np.float32)
    nv = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] - 6) & (lum < 165) & (np.abs(rgb[..., 0] - rgb[..., 1]) < 60)).astype(np.float32), (0, 0), 0.8)
    nv = (nv * cv2.GaussianBlur(STEP, (0, 0), 14))[..., None]
    localg = cv2.GaussianBlur(glazed, (0, 0), 18)
    ratio = np.clip(lum / NAVY_L, 0.45, 1.30)[..., None] / np.clip((LOCAL_S @ np.array([0.299, 0.587, 0.114], np.float32))[..., None] / NAVY_L, 0.5, 3)
    tgt = np.clip(localg * np.clip(ratio, 0.4, 1.4), 0, 255)
    k = nv * 0.6 * a
    f[..., :3] = rgb * (1 - k) + tgt * k
    return f


blink_frames = set()
for bt in np.arange(1.7, DUR, 3.1):
    for k in range(3):
        blink_frames.add(int(bt * FPS) + k)
LISTEN = [(S_(a), E_(b)) for a, b in (([("p1", "p2")] if VARIANT == "full" else [("p2", "p2")]) + [("p3", "p4")])]


def plate(t, k, face, frown, rest, kind):
    inner = BASE.copy()
    if t >= T_GOLD:
        inner = glaze(inner, t - T_GOLD)
    fkey = ("blink_" if (k in blink_frames and t < T_GOLD - 0.3) else "face_") + face   # no blink on the payoff / last frame
    flay = warm_lids(L[fkey], glaze_amount(t - T_GOLD), inner) if t >= T_GOLD else L[fkey]
    inner = over(inner, flay)
    v = vis[k]
    if kind == "listen" or v == "X":
        inner = over(inner, L[rest] if rest.startswith("rest_") else L[f"m_X_rest_{frown}"])
    else:
        inner = over(inner, L[f"m_{v}_{frown}"])
    if kind == "listen":
        for a0, a1 in LISTEN:
            if a0 - 0.3 <= t <= a1 + 0.3:
                env = np.clip(min(t - a0 + 0.3, a1 + 0.3 - t) / 0.4, 0, 1)
                pulse = env * (0.55 + 0.45 * np.sin(2 * np.pi * (t - a0) / 1.3))
                inner = 255 - (255 - inner) * (1 - ring[..., None] * pulse * 0.55 * np.array([1.0, 0.85, 0.45]))
    img = PAD_BG.copy()
    img[PAD_T:PAD_T + HS] = inner
    return img


enc = subprocess.Popen([FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", str(B3 / f"video_{TAG}.mp4")], stdin=subprocess.PIPE)
last_talk = None
for k in range(N):
    t = k / FPS
    i, s, z = shot_at(t)
    _, kind, face, frown, rest, _, _, fx, fy, subk = s
    if kind == "flow":
        fi = min(len(FLOW) - 1, int((t - BR0) * FPS))
        img = cam(FLOW[fi].astype(np.float32), z, fx, fy)     # hard cuts in/out (a dissolve between different framings ghosts)
    else:
        img = cam(plate(t, k, face, frown, rest, kind), z, fx, fy)
    if BR0 + 0.05 <= t < BR_END + 0.12:                     # page badges during the reading bridge
        a = np.clip(min((t - BR0 - 0.05) / 0.2, (BR_END + 0.12 - t) / 0.2), 0, 1)
        key, tick = ("b12", None) if t < T_P13 else (("b13", T_P13) if t < T_P14 else ("b14", T_P14))
        b = OV[key].copy(); b[..., 3] *= a
        if tick is not None and t - tick < 0.3:
            sc = 1 + 0.16 * np.exp(-((t - tick) / 0.09) ** 2)
            M = cv2.getRotationMatrix2D((540, 360), 0, sc)
            b = cv2.warpAffine(b, M, (1080, 1920), flags=cv2.INTER_LINEAR, borderValue=(0, 0, 0, 0))
        img = over(img, b)
    if BR_END + 0.12 <= t < T_CTA:                          # small «۱۴» tag during the payoff
        b = OV["b14s"].copy(); b[..., 3] *= np.clip((t - BR_END - 0.12) / 0.2, 0, 1); img = over(img, b)
    if t < S_(ITEMS[1][0]) - 0.05:                          # hook from frame 0
        a = np.clip((S_(ITEMS[1][0]) - 0.05 - t) / 0.2, 0, 1)
        ov = OV["hook"].copy(); ov[..., 3] *= a; img = over(img, ov)
    elif subk and t < T_CTA:
        img = over(img, OV[subk])
    if t >= T_CTA:
        a = np.clip((t - T_CTA) / 0.2, 0, 1)
        ov = OV["cta"].copy(); ov[..., 3] *= a; img = over(img, ov)
    enc.stdin.write(np.clip(img, 0, 255).astype(np.uint8).tobytes())
enc.stdin.close(); enc.wait()

# =============================================================== audio mix
mus = load(W0 / "reel_d010" / "music_leberch_reading.mp3")
mus = mus[int(2.0 * SR):int(2.0 * SR) + NS]
mus = np.pad(mus, (0, max(0, NS - len(mus))))
voice = lam_tr + pel_tr
act = np.convolve((np.abs(voice) > 0.01).astype(np.float32), np.ones(int(0.25 * SR)) / int(0.25 * SR), "same") > 0.02
duck = np.where(act, 0.09, 0.20).astype(np.float32)
duck = np.convolve(duck, np.ones(int(0.3 * SR)) / int(0.3 * SR), "same")
tt = np.arange(NS) / SR
duck *= np.clip(tt / 0.4, 0, 1) * np.clip((DUR - tt) / 0.7, 0, 1)
mix = voice * 1.0 + mus * duck


def add(x, at, g):
    i = int(at * SR)
    if 0 <= i < NS:
        n = max(0, min(len(x), NS - i)); mix[i:i + n] += x[:n] * g


pt = load(W0 / "audio" / "page_turn.wav")
pt = pt[:int(0.9 * SR)] * np.linspace(1, 0.0, int(0.9 * SR)) ** 0.5
for tk in (T_P13 - 0.35, T_P14 - 0.35):
    add(pt, tk, 0.45)
wh = load(W0 / "reel_d013" / "_build" / "sfx_whoosh.wav")
add(wh, BR0 - 0.05, 0.18)
add(wh, SHOTS[[s[2] for s in SHOTS].index("E03")][0] - 0.06, 0.08)      # soft whoosh on the face punch-in
ding_wav(B3 / "ding.wav", at=0.0, total=2.0, sr=SR)
add(load(B3 / "ding.wav"), T_GOLD + 0.09, 0.85)
mix = mix[:int(DUR * SR)]
mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
with wave.open(str(B3 / f"mix_{TAG}.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((mix * 32767).astype(np.int16).tobytes())


def lufs(path):
    e = subprocess.run([FF, "-hide_banner", "-i", str(path), "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    s = e[e.rindex("Summary:"):]
    return float(s.split("I:")[1].split("LUFS")[0]), float(s.split("Peak:")[1].split("dBFS")[0])


I0, _ = lufs(B3 / f"mix_{TAG}.wav")
gain = TARGET_I - I0
for it in range(4):
    af = f"volume={gain:.2f}dB,alimiter=limit=0.84:attack=3:release=60:level=false,aresample=48000"
    subprocess.run([FF, "-y", "-v", "error", "-i", str(B3 / f"mix_{TAG}.wav"), "-af", af, "-ac", "2", str(B3 / f"mix_{TAG}_norm.wav")], check=True)
    I1, tp1 = lufs(B3 / f"mix_{TAG}_norm.wav")
    if abs(I1 - TARGET_I) < 0.3:
        break
    gain += TARGET_I - I1
# speech-over-music check: voice-only vs music-only RMS (dB) during speech
vm = act[:len(mix)]
sp_db = 20 * np.log10(np.sqrt((voice[:len(mix)][vm] ** 2).mean()) + 1e-9)
mu_db = 20 * np.log10(np.sqrt(((mus * duck)[:len(mix)][vm] ** 2).mean()) + 1e-9)
js = {"input_I": I0, "gain_dB": round(gain, 2), "out_I": I1, "out_TP": tp1, "speech_minus_music_dB": round(sp_db - mu_db, 1)}
out = EP / f"lam_ep1_final_{TAG}.mp4"
subprocess.run([FF, "-y", "-v", "error", "-i", str(B3 / f"video_{TAG}.mp4"), "-i", str(B3 / f"mix_{TAG}_norm.wav"), "-c:v", "copy",
                "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", str(out)], check=True)
print("loudness", js)
json.dump({"variant": VARIANT, "tempo": TEMPO, "segments": {k: [round(v[0], 3), round(v[1], 3)] for k, v in segs.items()},
           "shots": [[round(s[0], 2), s[1], s[2], s[5], s[6]] for s in SHOTS], "BR0": BR0, "BR_END": BR_END, "flow_speed": FLOW_SPEED,
           "T_P13": T_P13, "T_P14": T_P14, "T_GOLD": T_GOLD, "T_CTA": T_CTA, "DUR": DUR, "loudness": js},
          open(EP / f"lam_ep1_timeline_{TAG}.json", "w"), indent=1)
print("done", out, round(DUR, 2))
