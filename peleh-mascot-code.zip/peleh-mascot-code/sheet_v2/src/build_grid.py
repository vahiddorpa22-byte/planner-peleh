﻿"""Proportion grid (spec §1) + G-grid overlays on the existing renders, flagging v1 inconsistencies."""
from pathlib import Path
import lam_facekit as K
from common import *

OUT = ROOT / "grid"
OUT.mkdir(exist_ok=True)
FA = str.maketrans("0123456789.", "۰۱۲۳۴۵۶۷۸۹٫")


def fa(s):
    return str(s).translate(FA)


# ------------------------------------------------------------------ spec schematic (front + 3/4)
STEPS = [(0, 2, 7), (2, 4, 6), (4, 6, 5), (6, 8, 4)]   # (x0, x1, height) step 1..4


def body_path(G, X, Y, d=0.25, sx=1.0):
    pts = [(d, d), (8 - d, d), (8 - d, 4 - d), (6 - d, 4 - d), (6 - d, 5 - d), (4 - d, 5 - d), (4 - d, 6 - d),
           (2 - d, 6 - d), (2 - d, 7 - d), (d, 7 - d)]
    return "M" + " L".join(f"{X(x*sx):.1f},{Y(y):.1f}" for x, y in pts) + "Z"


def schematic_front(G, ox, oy, flags=True, grid=True, face=True, eye_y=5.0):
    X = lambda x: ox + x * G
    Y = lambda y: oy - y * G
    s = []
    if grid:
        for i in range(-3, 9):
            s.append(f'<line x1="{X(-2.2)}" y1="{Y(i)}" x2="{X(10.2)}" y2="{Y(i)}" stroke="#fff" stroke-opacity="{.28 if i==0 else .12}" stroke-width="1"/>')
            s.append(f'<text x="{X(-2.45)}" y="{Y(i)+5}" font-size="14" fill="#E6E8EE" fill-opacity=".7" text-anchor="end" font-family="Vaz" direction="ltr">{i}G</text>')
        s.append(f'<line x1="{X(-2.2)}" y1="{Y(-3.5)}" x2="{X(10.2)}" y2="{Y(-3.5)}" stroke="#fff" stroke-opacity=".35" stroke-dasharray="6 5"/>')
        for i in range(-2, 11):
            s.append(f'<line x1="{X(i)}" y1="{Y(-3.6)}" x2="{X(i)}" y2="{Y(7.6)}" stroke="#fff" stroke-opacity=".10"/>')
    # legs + shoes
    for lx in (2.75, 5.75):
        s.append(f'<rect x="{X(lx-.25)}" y="{Y(0.2)}" width="{.5*G}" height="{2.7*G}" rx="{.25*G}" fill="url(#navyV)"/>')
        s.append(f'<rect x="{X(lx-.75)}" y="{Y(-2.5)}" width="{1.5*G}" height="{1.0*G}" rx="{.42*G}" fill="url(#cream)"/>'
                 f'<rect x="{X(lx-.75)}" y="{Y(-2.5)+.25*G}" width="{1.5*G}" height="{.42*G}" fill="{GOLD}" opacity=".9" rx="{.12*G}"/>'
                 f'<rect x="{X(lx-.8)}" y="{Y(-3.3)}" width="{1.6*G}" height="{.22*G}" rx="{.1*G}" fill="#E4DDCB"/>')
    # arms (0.45G thick, out of the side at 3G)
    for side in (-1, 1):
        x0 = 0.15 if side < 0 else 7.85
        ex = x0 + side * 1.05
        s.append(f'<path d="M{X(x0)},{Y(3.1)} C{X(x0+side*0.95)},{Y(3.0)} {X(ex+side*.15)},{Y(2.0)} {X(ex)},{Y(0.6)}" fill="none" stroke="url(#navyV)" stroke-width="{.45*G}" stroke-linecap="round"/>')
        s.append(f'<ellipse cx="{X(ex)}" cy="{Y(0.25)}" rx="{.52*G}" ry="{.5*G}" fill="#22325A"/>')
    # body
    s.append(f'<path d="{body_path(G, X, Y)}" fill="url(#navyB)" stroke="url(#navyB)" stroke-width="{.5*G}" stroke-linejoin="round"/>')
    # step numbers + height dims
    for k, (a, b, h) in enumerate(STEPS, 1):
        cx = X((a + b) / 2)
        s.append(f'<circle cx="{cx}" cy="{Y(0.7)}" r="{.32*G}" fill="{GOLD}"/>'
                 f'<text x="{cx}" y="{Y(0.7)+7}" font-size="{.38*G}" font-weight="800" fill="{NAVY}" text-anchor="middle" font-family="Vaz">{fa(k)}</text>')
        s.append(f'<text x="{cx}" y="{Y(h)-.55*G}" font-size="16" font-weight="700" fill="{NAVY}" fill-opacity=".75" text-anchor="middle" font-family="Vaz" direction="ltr">{h}G</text>')
    # width / height dims
    s.append(f'<path d="M{X(0)},{Y(-0.0)+.5*G} v8 M{X(0)},{Y(0)+.5*G+4} H{X(8)} M{X(8)},{Y(0)+.5*G} v8" stroke="{GOLD}" fill="none" stroke-width="1.5"/>')
    s.append(f'<text x="{X(4)}" y="{Y(0)+.5*G+24}" font-size="17" fill="{GOLD}" text-anchor="middle" font-family="Vaz" font-weight="700" direction="ltr">8G</text>')
    s.append(f'<path d="M{X(-1.75)},{Y(0)} h-8 M{X(-1.75)-4},{Y(0)} V{Y(7)} M{X(-1.75)},{Y(7)} h-8" stroke="{GOLD}" fill="none" stroke-width="1.5"/>')
    s.append(f'<text x="{X(-1.75)-12}" y="{Y(3.5)}" font-size="17" fill="{GOLD}" text-anchor="end" font-family="Vaz" font-weight="700" direction="ltr">7G</text>')
    s.append(f'<path d="M{X(9.6)},{Y(7)} h8 M{X(9.6)+4},{Y(7)} V{Y(-3.5)} M{X(9.6)},{Y(-3.5)} h8" stroke="{CREAM}" stroke-opacity=".6" fill="none" stroke-width="1.5"/>')
    s.append(f'<text x="{X(9.6)+12}" y="{Y(1.75)}" font-size="16" fill="{CREAM}" fill-opacity=".8" font-family="Vaz" direction="ltr">10.5G</text>')
    if face:
        R = 0.9 * G
        fc = K.face(R, "E01", eyeL=(1.0 / .9, -eye_y / .9), eyeR=(3.0 / .9, -eye_y / .9),
                    browL=(0.98 / .9, -(eye_y + 1.05) / .9), browR=(3.02 / .9, -(eye_y + 1.05) / .9),
                    mouthc=(2.35 / .9, -(eye_y - 1.9) / .9), mscale=1.2 / 1.33)
        s.append(f'<g transform="translate({X(0)},{Y(0)})">{fc}</g>')
    if flags:
        # brow over step 2 sticks out of the silhouette; left eye nearly touches the edge
        s.append(f'<rect x="{X(2.0)}" y="{Y(6.6)}" width="{2.05*G}" height="{.75*G}" rx="8" fill="none" stroke="{RED}" stroke-width="3" stroke-dasharray="7 5"/>'
                 f'<circle cx="{X(4.25)}" cy="{Y(6.6)}" r="15" fill="{RED}"/><text x="{X(4.25)}" y="{Y(6.6)+6}" font-size="17" font-weight="800" fill="#fff" text-anchor="middle" font-family="Vaz">!</text>')
        s.append(f'<rect x="{X(-0.15)}" y="{Y(5.95)}" width="{.5*G}" height="{1.9*G}" rx="6" fill="none" stroke="{RED}" stroke-width="3" stroke-dasharray="7 5"/>')
    return "".join(s)


def schematic_34(G, ox, oy):
    """Oblique 3/4 schematic: extruded staircase, depth 3G, no steps in depth."""
    sx = 0.82
    dx, dy = 0.42 * G, -0.26 * G       # per 1G of depth
    D = 3
    X = lambda x: ox + x * G * sx
    Y = lambda y: oy - y * G
    P = lambda x, y, z=0: f"{X(x)+z*dx:.1f},{Y(y)+z*dy:.1f}"
    s = []
    # floor ellipse shadow
    s.append(f'<ellipse cx="{X(4)+1.5*dx}" cy="{Y(-3.45)+1.5*dy}" rx="{5.2*G}" ry="{.55*G}" fill="#000" opacity=".22"/>')
    for lx, z in ((2.75, 1.0), (5.75, 1.0)):
        s.append(f'<rect x="{X(lx)+z*dx-.25*G}" y="{Y(0.2)+z*dy}" width="{.5*G}" height="{2.7*G}" rx="{.25*G}" fill="url(#navyV)"/>'
                 f'<rect x="{X(lx)+z*dx-.6*G}" y="{Y(-2.5)+z*dy}" width="{1.7*G}" height="{1.0*G}" rx="{.42*G}" fill="url(#cream)"/>'
                 f'<rect x="{X(lx)+z*dx-.6*G}" y="{Y(-2.5)+z*dy+.25*G}" width="{1.7*G}" height="{.42*G}" fill="{GOLD}" rx="{.12*G}"/>')
    # tops and risers (back-to-front)
    for k, (a, b, h) in enumerate(STEPS):
        s.append(f'<polygon points="{P(a,h)} {P(b,h)} {P(b,h,D)} {P(a,h,D)}" fill="#4A5C92"/>')
        nh = STEPS[k + 1][2] if k < 3 else 0
        s.append(f'<polygon points="{P(b,nh)} {P(b,h)} {P(b,h,D)} {P(b,nh,D)}" fill="#30416F"/>')
    # front face
    pts = [(0, 0), (8, 0), (8, 4), (6, 4), (6, 5), (4, 5), (4, 6), (2, 6), (2, 7), (0, 7)]
    s.append(f'<polygon points="{" ".join(P(x, y) for x, y in pts)}" fill="url(#navyB)" stroke="#5A6CA0" stroke-width="2" stroke-linejoin="round"/>')
    # arm on the visible side
    s.append(f'<path d="M{X(8)+1.5*dx},{Y(3.1)+1.5*dy} C{X(8.9)+1.5*dx},{Y(3.0)+1.5*dy} {X(9.2)+1.5*dx},{Y(2.0)+1.5*dy} {X(9.05)+1.5*dx},{Y(0.6)+1.5*dy}" fill="none" stroke="url(#navyV)" stroke-width="{.45*G}" stroke-linecap="round"/>'
             f'<ellipse cx="{X(9.05)+1.5*dx}" cy="{Y(0.25)+1.5*dy}" rx="{.5*G}" ry="{.5*G}" fill="#22325A"/>')
    for k, (a, b, h) in enumerate(STEPS, 1):
        cx, cy = X((a + b) / 2) + 1.5 * dx, Y(h) + 1.5 * dy
        s.append(f'<circle cx="{cx}" cy="{cy}" r="{.27*G}" fill="{GOLD}"/><text x="{cx}" y="{cy+6}" font-size="{.32*G}" font-weight="800" fill="{NAVY}" text-anchor="middle" font-family="Vaz">{fa(k)}</text>')
    # depth dim
    s.append(f'<path d="M{X(8)},{Y(0)+14} L{X(8)+D*dx},{Y(0)+D*dy+14}" stroke="{GOLD}" stroke-width="1.5"/>'
             f'<text x="{X(8)+1.5*dx+14}" y="{Y(0)+1.5*dy+30}" font-size="16" fill="{GOLD}" font-family="Vaz" font-weight="700" direction="ltr">3G</text>')
    return "".join(s)


DEFS = f"""<defs>
<linearGradient id="navyB" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2E3E6C"/><stop offset=".55" stop-color="{NAVY}"/><stop offset="1" stop-color="#121B33"/></linearGradient>
<linearGradient id="navyV" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2A3A66"/><stop offset="1" stop-color="#16213D"/></linearGradient>
<linearGradient id="cream" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FBF8F0"/><stop offset="1" stop-color="#D9D0BC"/></linearGradient>
</defs>"""


def spec_grid_page():
    G = 52
    body = f"""
<div style="position:absolute;top:120px;right:64px;width:1210px;height:900px;background:{GREY};border-radius:22px;overflow:hidden">
<svg width="1210" height="900" style="direction:ltr">{DEFS}
<text x="300" y="44" font-size="22" font-weight="800" fill="{NAVY}" text-anchor="middle" font-family="Vaz">نمای روبه‌رو · Front</text>
<text x="905" y="44" font-size="22" font-weight="800" fill="{NAVY}" text-anchor="middle" font-family="Vaz">نمای سه‌رخ (شماتیک) · 3/4</text>
<g>{schematic_front(G, 180, 560)}</g>
<g>{schematic_34(G, 760, 600)}</g>
</svg></div>
<div style="position:absolute;top:120px;left:64px;width:560px;height:900px;display:flex;flex-direction:column;gap:16px">
 <div class="card" style="padding:22px 26px">
  <h3>قفل فرم: واحد G = ارتفاع یک پله</h3>
  <p>۴ پله‌ی هم‌پهنا (هر کدام <span class="ltr">2G</span>) · ارتفاع پله‌ها از چپ: <span class="ltr">7G · 6G · 5G · 4G</span> · پهنا <span class="ltr">8G</span> : ارتفاع <span class="ltr">7G</span> (پهن‌تر از بلند) · عمق <span class="ltr">3G</span>، بدون پله در عمق · گردی لبه <span class="ltr">0.25G</span> · قد کل <span class="ltr">10.5G</span></p>
  <p style="margin-top:8px">چشم <span class="ltr">Ø1.8G</span> با فاصله‌ی <span class="ltr">0.2G</span> · ابرو <span class="ltr">0.3G</span> · دهان <span class="ltr">1.2G</span> · دست <span class="ltr">0.45G</span> از ارتفاع <span class="ltr">3G</span> · پا <span class="ltr">0.5G × 2.5G</span> · کفش <span class="ltr">1G × 2G</span></p>
 </div>
 <div class="card" style="padding:22px 26px;border-color:rgba(226,87,76,.5)">
  <h3 style="color:#F08A80">دو تناقض در خود عددهای مشخصات (کادر قرمز)</h3>
  <p>۱. با مرکز چشم در <span class="ltr">5G</span>، بالای چشم راست <span class="ltr">5.9G</span> است و ابرویش (<span class="ltr">6.2–6.5G</span>) از سقف پله‌ی ۲ (<span class="ltr">6G</span>) <b>بیرون می‌زند</b>.</p>
  <p>۲. دو چشم <span class="ltr">1.8G</span> + فاصله = <span class="ltr">3.8G</span>؛ چشم چپ فقط <span class="ltr">0.1G</span> با لبه‌ی بدن فاصله دارد.</p>
  <p style="margin-top:6px;color:{CREAM}"><b>پیشنهاد تیم گرافیک:</b> مرکز چشم <span class="ltr">4.4G</span> (ابرو تا <span class="ltr">5.9G</span>)، یا چشم <span class="ltr">Ø1.6G</span>. تصمیم با وحید / مشاور.</p>
 </div>
 <div class="card" style="padding:22px 26px">
  <h3>رندر فعلی با این گرید نمی‌خواند</h3>
  <p>در رندر پوف، ارتفاع پله‌ها ≈ <span class="ltr">1G</span> هست (درست)، اما پهنای پله‌ها <span class="ltr">2.1 / 0.55 / 0.57 / 0.69G</span> و کل بدن ≈ <span class="ltr">4.1G</span> است، نه <span class="ltr">8G</span>. یعنی پله‌های شیت پهن و کم‌شیب‌اند و رندر جدید R1 کمی «پهن‌تر و تخت‌تر» از لَمِ فعلی می‌شود. صفحه‌ی بعد اندازه‌ها را نشان می‌دهد.</p>
 </div>
 <div class="card" style="padding:18px 26px;display:flex;align-items:center;gap:14px">
  <span class="tag">وضعیت: پیشنهاد قفل</span><p style="font-size:16px">با تأیید وحید ثابت می‌شود؛ تا آن موقع رندر R1/R2 گرفته نشود.</p>
 </div>
</div>"""
    return page("P1·02", "قفل فرم و گرید تناسب", "Form lock · G grid (proposal)", body,
                "گرید از مشخصات بخش ۱ کشیده شده؛ صورت با همین کیت وکتوری (حالت E01)")


def overlay_pages():
    bb = uri(REFD / "lam_beanbag_square_profile.jpg")
    sh = uri(REFD / "lam_character_sheet_v1.jpg")
    # bean-bag: image 1024 shown at 860 (scale .84) ; crop region 300..900 x 120..720 -> show 600px region at 1.4x
    sc = 1.45
    cx0, cy0 = 330, 140
    T = lambda x, y: ((x - cx0) * sc, (y - cy0) * sc)
    steps_y = [(1, 182), (2, 278), (3, 385), (4, 500)]
    xs = [372, 598, 657, 718, 792]
    Gp = 107
    lines = []
    for k, y in steps_y:
        a, b = T(340, y), T(900, y)
        lines.append(f'<line x1="{a[0]}" y1="{a[1]}" x2="{b[0]}" y2="{b[1]}" stroke="#FFFFFF" stroke-opacity=".75" stroke-width="2" stroke-dasharray="10 6"/>')
        lines.append(f'<g transform="translate({b[0]-40},{a[1]-16})"><circle r="15" fill="#FFFFFF"/><text y="6" font-size="17" font-weight="800" fill="{NAVY}" text-anchor="middle" font-family="Vaz">{fa(k)}</text></g>')
    for (k1, y1), (k2, y2) in zip(steps_y, steps_y[1:]):
        a, b = T(860, y1), T(860, y2)
        lines.append(f'<path d="M{a[0]},{a[1]} V{b[1]}" stroke="{CREAM}" stroke-width="2"/><text x="{a[0]+8}" y="{(a[1]+b[1])/2+6}" font-size="17" fill="{CREAM}" font-family="Vaz" direction="ltr">{(y2-y1)/Gp:.2f}G</text>')
    for x in xs:
        a, b = T(x, 150), T(x, 640)
        lines.append(f'<line x1="{a[0]}" y1="{a[1]}" x2="{b[0]}" y2="{b[1]}" stroke="#7FD3FF" stroke-width="1.5" stroke-opacity=".8"/>')
    for x1, x2 in zip(xs, xs[1:]):
        a = T((x1 + x2) / 2, 620)
        lines.append(f'<text x="{a[0]}" y="{a[1]}" font-size="16" fill="#7FD3FF" text-anchor="middle" font-family="Vaz" font-weight="700" direction="ltr">{(x2-x1)/Gp:.2f}G</text>')
    a, b = T(402, 462), T(515, 462)
    lines.append(f'<path d="M{a[0]},{a[1]} H{b[0]}" stroke="{RED}" stroke-width="3"/><text x="{(a[0]+b[0])/2}" y="{a[1]+24}" font-size="16" fill="#FFB3AC" text-anchor="middle" font-family="Vaz" font-weight="700" direction="ltr">eye ≈ 1.07G   (spec 1.8G)</text>')
    # spec ghost at the same G (riser-matched), anchored at step-4 top = 4G
    gx = lambda xg: 372 + xg * Gp
    gy = lambda yg: 500 + (4 - yg) * Gp
    ghost = [(0, 0), (8, 0), (8, 4), (6, 4), (6, 5), (4, 5), (4, 6), (2, 6), (2, 7), (0, 7)]
    gp = " ".join("%.1f,%.1f" % T(gx(x), gy(y)) for x, y in ghost)
    lines.append(f'<polygon points="{gp}" fill="none" stroke="{GOLD}" stroke-width="3" stroke-opacity=".9" stroke-dasharray="3 7" stroke-linecap="round"/>')
    W1, H1 = 600 * sc, 600 * sc
    left = f"""<div style="position:absolute;top:120px;right:64px;width:{W1:.0f}px;height:860px;border-radius:20px;overflow:hidden;background:#000">
<div style="position:absolute;left:{-cx0*sc}px;top:{-cy0*sc}px;width:{1024*sc}px;height:{1024*sc}px;background:url('{bb}') 0 0/100% 100%"></div>
<svg width="{W1:.0f}" height="860" style="position:absolute;left:0;top:0;direction:ltr">{''.join(lines)}</svg>
<div style="position:absolute;right:16px;top:14px" class="tag">رندر پوف · <span class="ltr">G ≈ 107px</span> (ارتفاع پله)</div>
<div style="position:absolute;left:16px;bottom:14px;max-width:420px;font-size:14px;color:{GOLD};background:rgba(10,16,30,.75);padding:8px 12px;border-radius:10px">خط‌چین سفید = سقف پله‌های رندر · نقطه‌چین طلایی = فرم شیت v2 با همین G (بدن <span class="ltr">8G</span>، بیرون از کادر ادامه دارد)</div>
</div>"""
    # v1 front crop
    sc2 = 2.05
    fx0, fy0 = 300, 20
    T2 = lambda x, y: ((x - fx0) * sc2, (y - fy0) * sc2)
    sil = [(350, 270), (350, 162), (380, 162), (380, 108), (415, 108), (415, 55), (505, 42), (505, 90), (560, 90), (560, 270)]
    l2 = [f'<polygon points="{" ".join("%.1f,%.1f" % T2(x, y) for x, y in sil)}" fill="none" stroke="#7FD3FF" stroke-width="3"/>']
    G2 = (270 - 42) / 7
    gh = [(350 + x * G2, 270 - y * G2) for x, y in ghost]
    l2.append(f'<polygon points="{" ".join("%.1f,%.1f" % T2(x, y) for x, y in gh)}" fill="none" stroke="{GOLD}" stroke-width="3" stroke-dasharray="3 7" stroke-linecap="round"/>')
    for i, (x, y) in enumerate([(365, 162), (397, 108), (460, 46), (532, 90)], 1):
        p = T2(x, y)
        l2.append(f'<g transform="translate({p[0]},{p[1]-20})"><circle r="14" fill="#7FD3FF"/><text y="6" font-size="15" font-weight="800" fill="{NAVY}" text-anchor="middle" font-family="Vaz">{fa(i)}</text></g>')
    a, b = T2(350, 285), T2(560, 285)
    l2.append(f'<path d="M{a[0]},{a[1]} H{b[0]}" stroke="#7FD3FF" stroke-width="2"/><text x="{(a[0]+b[0])/2}" y="{a[1]+22}" font-size="16" fill="#7FD3FF" text-anchor="middle" font-family="Vaz" font-weight="700" direction="ltr">W 210 : H 228 px</text>')
    W2 = 330 * sc2
    right = f"""<div style="position:absolute;top:120px;left:64px;width:{W2:.0f}px;height:540px;border-radius:20px;overflow:hidden;background:#000">
<div style="position:absolute;left:{-fx0*sc2}px;top:{-fy0*sc2}px;width:{1536*sc2}px;height:{1024*sc2}px;background:url('{sh}') 0 0/100% 100%"></div>
<svg width="{W2:.0f}" height="540" style="position:absolute;left:0;top:0;direction:ltr">{''.join(l2)}</svg>
<div style="position:absolute;right:14px;top:12px" class="tag">نمای روبه‌روی شیت v1</div></div>
<div class="card" style="position:absolute;top:676px;left:64px;width:{W2:.0f}px;height:304px;padding:18px 24px">
<h3>آنچه گرید نشان می‌دهد</h3>
<p>• <b>v1 روبه‌رو:</b> ۴ سطح، ولی قله وسطِ چپ است و از دو طرف پایین می‌آید (۲ پله چپ + ۱ راست)، نه پلکان یک‌طرفه‌ی ۴تایی. پهنا ۲۱۰ : ارتفاع ۲۲۸ = <b>بلندتر از پهنا</b>.</p>
<p>• <b>رندر پوف:</b> ۴ پله‌ی شمردنی و جهت درست (بلندترین چپ)، ارتفاع پله‌ها یکسان ≈ <span class="ltr">1G</span>؛ اما پله‌ها باریک‌اند و بدن <span class="ltr">≈4.1G</span> پهنا دارد.</p>
<p>• خط‌چین طلایی = فرم پیشنهادی شیت v2 با همان مقیاس.</p></div>"""
    body = left + right
    return page("P1·03", "گرید روی تصویرهای فعلی", "G-grid overlay · measured", body,
                "اندازه‌ها با پیکسل‌شماری روی فایل‌های ref (برآورد ±۵٪)")


def inconsist_page():
    sh = uri(REFD / "lam_character_sheet_v1.jpg")
    sc = 1180 / 1536
    T = lambda x, y: (x * sc, y * sc)
    notes = [
        ((455, 30), (330, 40, 260, 250), "۱", "روبه‌رو: قله وسط، ۳ سطح دیده می‌شود (نه ۴ پله‌ی یک‌طرفه)"),
        ((760, 30), (640, 40, 200, 250), "۴", "کنار: در عمق هم پله دارد؛ با بدن اکسترودشده جور نیست"),
        ((1035, 30), (885, 35, 300, 250), "۳", "پشت: قرینه (پله در هر دو طرف)؛ باید آینه‌ی روبه‌رو باشد"),
        ((455, 300), (340, 40, 230, 240), "۲", "نسبت بدن: ۲۱۰×۲۲۸ ← بلندتر از پهنا (قانون: پهن‌تر)"),
    ]
    svg = []
    boxes = [(330, 38, 240, 240), (645, 45, 185, 240), (890, 40, 305, 245), (1225, 45, 260, 240)]
    labels = ["۱", "۴", "۳", "۵"]
    for (x, y, w, h), lab in zip(boxes, labels):
        a = T(x, y)
        svg.append(f'<rect x="{a[0]}" y="{a[1]}" width="{w*sc}" height="{h*sc}" rx="10" fill="none" stroke="{RED}" stroke-width="3" stroke-dasharray="8 6"/>'
                   f'<g transform="translate({a[0]+w*sc-6},{a[1]+6})"><rect x="-36" y="-2" width="40" height="28" rx="14" fill="{RED}"/><text x="-16" y="18" font-size="16" font-weight="800" fill="#fff" text-anchor="middle" font-family="Vaz">{lab}</text></g>')
    body = f"""<div style="position:absolute;top:120px;right:64px;width:1180px;height:787px;border-radius:18px;overflow:hidden;background:url('{sh}') 0 0/100% 100%">
<svg width="1180" height="787" style="direction:ltr">{''.join(svg)}</svg></div>
<div style="position:absolute;top:120px;left:64px;width:560px;display:flex;flex-direction:column;gap:14px">
<div class="card" style="padding:20px 24px"><h3>۵ ناسازگاری شیت v1 (طبق مشخصات)</h3>
<p><b>۱. تعداد پله:</b> روبه‌رو ~۳ سطح، پوف ۴ پله. قانون برند: <b>۴ پله</b>.</p>
<p><b>۲. نسبت بدن:</b> شیت بلندتر از پهنا (۲۱۰:۲۲۸)، پوف پهن‌تر. قانون: <b>پهن، نه ستون</b>.</p>
<p><b>۳. پشت قرینه:</b> باید آینه‌ی روبه‌رو باشد (بلندترین سمت راست بیننده).</p>
<p><b>۴. پله در عمق (نمای کنار):</b> بدن اکسترودشده در عمق پله ندارد.</p>
<p><b>۵. جهت پله در پرامپت قدیمی:</b> «ascending left to right» ولی در همه‌ی تصویرها بلندترین سمت <b>چپ</b> است. قفل: بلندترین چپ، پایین‌رونده به راست.</p></div>
<div class="card" style="padding:18px 24px"><h3>قانون رفرنس</h3><p>از این به بعد فقط <span class="ltr">lam_P1_proportion_grid.png</span> (بعد از تأیید) و شیت v2 رفرنس مولد تصویر است. تصویر پوف برای فرم بدن داده نشود.</p></div>
</div>
<div style="position:absolute;top:925px;right:64px;width:1180px;font-size:15px;color:#AEB4C2">کادر ۵ (سه‌رخ): پله‌ها در عمق و قله‌ی وسط؛ همان مشکل ۱ و ۴ از زاویه‌ی دیگر.</div>"""
    return page("P1·04", "ناسازگاری‌های شیت نسخه‌ی ۱", "v1 inconsistencies", body, "مرجع: بخش ۰ مشخصات فنی شیت لَم")


def grid_only_png():
    """Clean deliverable named in spec: lam_P1_proportion_grid.png (grey bg, front + 3/4)."""
    G = 64
    W, H = 1800, 1000
    svg = (f'<svg width="{W}" height="{H}" style="direction:ltr">{DEFS}<rect width="{W}" height="{H}" fill="{GREY}"/>'
           f'<text x="60" y="60" font-size="30" font-weight="800" fill="{NAVY}" font-family="Vaz">lam_P1_proportion_grid · v1 · proposal (awaiting Vahid)</text>'
           f'<g>{schematic_front(G, 230, 660, flags=True)}</g><g>{schematic_34(G, 1060, 700)}</g></svg>')
    html = f"<!doctype html><meta charset='utf-8'><style>{CSS} html,body{{width:{W}px;height:{H}px}}</style>{svg}"
    html_to_png(html, OUT / "lam_P1_proportion_grid_v1.png", W, H, transparent=False)
    svg2 = (f'<svg width="{W}" height="{H}" style="direction:ltr">{DEFS}<rect width="{W}" height="{H}" fill="{GREY}"/>'
            f'<text x="60" y="60" font-size="30" font-weight="800" fill="{NAVY}" font-family="Vaz">lam_P1_proportion_grid · ALT: eye centre 4.4G (team proposal)</text>'
            f'<g>{schematic_front(G, 230, 660, flags=False, eye_y=4.4)}</g><g>{schematic_34(G, 1060, 700)}</g></svg>')
    html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS} html,body{{width:{W}px;height:{H}px}}</style>{svg2}",
                OUT / "lam_P1_proportion_grid_v1_alt_eye44.png", W, H, transparent=False)


if __name__ == "__main__":
    grid_only_png()
    render_page(spec_grid_page(), OUT / "page_02_form_lock.png")
    render_page(overlay_pages(), OUT / "page_03_grid_overlays.png")
    render_page(inconsist_page(), OUT / "page_04_v1_inconsistencies.png")
    print("ok")
