﻿"""Story · ۱ آذر «آذرجشن مبارک! … امشب: گوشی خاموش، شمع روشن.» (Lam talks on plate A with the face kit, then Vahid's
silent Flow clip: phone off, candle lit). Fixes in the take: the bad gap inside «آذر|جشن» is cut; the soft second half
(«امشب…», ~13 dB lower) is levelled to the first; long pauses tightened.
Output: ep3/azarjashn_story.mp4 (+ _build/az_check.jpg)
"""
from pathlib import Path
import copy, subprocess, wave
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
import lam_facekit as K
from render_util import html_to_png, FONT

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
W0 = MASCOT.parent
EP = MASCOT / "ep3"
B = EP / "_build"
FF = imageio_ffmpeg.get_ffmpeg_exe()
FPS, SR = 30, 44100
GOLD, CREAM = "#C9A227", "#F3F0E8"


def load(p):
    raw = subprocess.run([FF, "-v", "quiet", "-i", str(p), "-ac", "1", "-ar", str(SR), "-f", "s16le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768


def fade(x, ms=12):
    n = int(SR * ms / 1000); x = x.copy(); x[:n] *= np.linspace(0, 1, n); x[-n:] *= np.linspace(1, 0, n); return x


src = load(EP / "azarjashn_lam.mp3")
XF = int(0.012 * SR)
# (key, start, end, cuts, gap before)
ITEMS = [("A", 0.08, 1.92, [(0.67, 0.84)], 0.30),                     # آذرجشن مبارک!  (gap inside «آذر|جشن» removed)
         ("B", 2.70, 3.47, [], 0.30),                                 # امشب:            (on Lam's face)
         ("B2", 3.70, 5.17, [], None),                                # گوشی خاموش…     (VO on the phone going down)
         ("B3", 5.40, 6.47, [], None)]                                # شمع روشن.        (VO on the candle catching fire)
CLIP_SRC_END = 4.75          # clip used 0 → 4.75 s, then its last frame held (Vahid prefers this natural pursed-lips ending)
END_HOLD = 1.9
USE_PLATE_D = False          # the face-kit ending on plate D was tried and rejected (2026-11-12)
IGNITE = 4.20                # candle catches fire at 4.2 s of the clip
CANDLE_OUT = 2.92            # the (wrongly pre-lit) candle leaves the frame at 2.9 s — flame painted out before that
segs, t = {}, 0.0
rms = lambda y: np.sqrt(np.mean(y[np.abs(y) > 0.01] ** 2) + 1e-12)
for key, a, b, cuts, gap in ITEMS:
    pieces, p0 = [], a
    for c0, c1 in cuts + [(b, b)]:
        pieces.append(src[int(p0 * SR):int(c0 * SR)].copy()); p0 = c1
    y = pieces[0]
    for pc in pieces[1:]:
        r = np.linspace(0, 1, XF, dtype=np.float32)
        y = np.concatenate([y[:-XF], y[-XF:] * (1 - r) + pc[:XF] * r, pc[XF:]])
    if key == "B2":
        t = segs["B"][1] + 0.25 + 0.55            # clip starts 0.25 s after «امشب», phone goes down ~0.6 s in
    elif key == "B3":
        t = segs["B"][1] + 0.25 + IGNITE - 0.12   # «شمع روشن» right on the flame
    else:
        t += gap
    segs[key] = [t, t + len(y) / SR, fade(y), a, cuts]
    t += len(y) / SR
ref = rms(segs["A"][2])
for k in ("B", "B2", "B3"):
    segs[k][2] = segs[k][2] * min(5.0, ref / rms(segs[k][2]) * 0.92)      # level the soft half
S_ = lambda k: segs[k][0]
E_ = lambda k: segs[k][1]


def to_out(key, ts):
    a, cuts = segs[key][3], segs[key][4]
    rm = sum((c1 - c0) if ts >= c1 else max(0, ts - c0) for c0, c1 in cuts)
    return segs[key][0] + (ts - a - rm)


T_CLIP = E_("B") + 0.25
CLIP_LEN = CLIP_SRC_END
T_END = T_CLIP + CLIP_LEN
DUR = T_END + END_HOLD
N = int(round(DUR * FPS)); NS = int(DUR * SR) + SR
voice = np.zeros(NS, np.float32)
for key, (a, b, y, *_r) in segs.items():
    i = int(a * SR); voice[i:i + len(y)] += y[:max(0, min(len(y), NS - i))]
print({k: (round(v[0], 2), round(v[1], 2)) for k, v in segs.items()}, "clip", round(T_CLIP, 2), "DUR", round(DUR, 2))

# ---------------------------------------------------------------- visemes (syllables over the voiced runs, source time)
M, T, L_, AA, E, I, U, O = "A_MBP", "B_SSH", "H_L", "D_AA", "C_E", "EE_wide", "F_OO", "E_O"
RUNS = {"A": [((0.12, 0.66), [(None, AA, None), (T, E, L_)]),                        # آ ذَر
              ((0.86, 1.18), [(T, E, L_)]),                                         # جَشن
              ((1.26, 1.86), [(M, O, None), (M, AA, None), (L_, E, T)])],           # مُ با رَک
        "B": [((2.75, 3.34), [(None, E, M), (T, E, M)])]}                          # اِم شَب  (the rest is voice-over on the clip)
WEIGHT = {AA: 1.35, U: 1.3, I: 1.25, O: 1.1, E: 1.0}
vis = ["X"] * N


def put(t0, t1, v):
    k0, k1 = int(round(t0 * FPS)), int(round(t1 * FPS))
    for k in range(max(0, k0), min(N, max(k1, k0 + 2))):
        vis[k] = v


for key, runs in RUNS.items():
    for (a, b), syl in runs:
        w = np.array([WEIGHT[s[1]] + (0.35 if s[0] else 0) + (0.3 if s[2] else 0) for s in syl])
        edges = a + (b - a) * np.concatenate([[0], np.cumsum(w) / w.sum()])
        for (on, vw, co), s0, s1 in zip(syl, edges[:-1], edges[1:]):
            d = s1 - s0; p0 = s0 + (0.24 * d if on else 0); p1 = s1 - (0.22 * d if co else 0)
            if on: put(to_out(key, s0), to_out(key, p0), on)
            put(to_out(key, p0), to_out(key, p1), vw)
            if co: put(to_out(key, p1), to_out(key, s1), co)
vis = vis[1:] + ["X"]

# ---------------------------------------------------------------- plate A + kit
S = 1080 / 1116; HS = round(2000 * S); CROP = (HS - 1920) // 2
to1080 = lambda a: cv2.resize(a, (1080, HS), interpolation=cv2.INTER_AREA)[CROP:CROP + 1920]
G = dict(R=48, eyeL=(540, 834), eyeR=(641, 837), browL=(543, 761), browR=(638, 757), mouth=(591, 908), ms=1.05)
plate0 = cv2.imread(str(EP / "lam_ep3_C_faceless.png"))[:, :, ::-1].astype(np.float32)
_pm = np.zeros(plate0.shape[:2], np.uint8)                      # the candle on the still is already lit → paint the flame out
cv2.ellipse(_pm, (1012, 1236), (11, 24), 0, 0, 360, 255, -1)
plate0 = cv2.inpaint(plate0.astype(np.uint8), cv2.dilate(_pm, np.ones((5, 5), np.uint8)), 5, cv2.INPAINT_TELEA).astype(np.float32)
H0, W0p = plate0.shape[:2]
LOCAL = cv2.GaussianBlur(plate0, (0, 0), 22)
GRADE = np.array((0.86, 0.84, 0.88)); NAVY_L = 0.299 * 0x1B + 0.587 * 0x2A + 0.114 * 0x4A
X = lambda eL, eR, bL, bR: dict(eyeL=eL, eyeR=eR, browL=bL, browR=bR, mouth=("none", False))
K.EXPR.update({
    "z_cheer": X((0.14, 0, 0, (0.04, 0.02), 1.04, True), (0.14, 0, 0, (0.04, 0.02), 1.04, True), ("up", -0.06), ("up", -0.08)),
    "z_cheer2": X((0.20, 0, 0, (0.04, 0.04), 1.04, True), (0.20, 0, 0, (0.04, 0.04), 1.04, True), ("soft", -0.10), ("soft", -0.12)),
    "z_cozy": X((0.36, -3, 0, (-0.30, 0.30), 1, False), (0.30, 3, 0, (-0.30, 0.30), 1, False), ("soft", 0.02), ("up", -0.06)),
})


def render_svg(inner, name):
    p = B / f"_{name}.png"
    html_to_png("<!doctype html><style>html,body{margin:0;background:transparent}</style>" + K.svg_doc(inner, W0p, H0, (0, 0, W0p, H0)), p, W0p, H0)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def grade(lay, seed=1):
    rgb, a = lay[..., :3].copy(), lay[..., 3]
    lum = rgb @ np.array([0.299, 0.587, 0.114])
    nv = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] + 8) & (lum < 150)).astype(np.float32), (0, 0), 0.8)[..., None]
    rgb = rgb * (1 - nv) + np.clip(LOCAL * np.clip(lum / NAVY_L, 0.45, 1.30)[..., None], 0, 255) * nv
    rgb = cv2.GaussianBlur(rgb * GRADE, (0, 0), 0.7) + np.random.default_rng(seed).normal(0, 2.0, rgb.shape[:2])[..., None]
    return np.dstack([np.clip(rgb, 0, 255), cv2.GaussianBlur(a, (0, 0), 0.6)])


def face_inner(ex, closed=False):
    saved = copy.deepcopy(K.EXPR[ex]); e = K.EXPR[ex]
    if closed:
        for side in ("eyeL", "eyeR"):
            l = list(e[side]); l[0], l[2] = 0.97, 0.0; e[side] = tuple(l)
    R = G["R"]; u = lambda p: (p[0] / R, p[1] / R)
    inner = K.face(R, ex, eyeL=u(G["eyeL"]), eyeR=u(G["eyeR"]), browL=u(G["browL"]), browR=u(G["browR"]), mouthc=u(G["mouth"]), mscale=G["ms"])
    K.EXPR[ex] = saved
    return inner


cache = B / "layers_A_az.npz"
if cache.exists():
    L = dict(np.load(cache))
else:
    L = {}
    for ex in ("z_cheer", "z_cheer2", "z_cozy"):
        L[f"face_{ex}"] = np.clip(to1080(grade(render_svg(face_inner(ex), "az_" + ex))), 0, 255).astype(np.uint8)
        L[f"blink_{ex}"] = np.clip(to1080(grade(render_svg(face_inner(ex, True), "az_" + ex + "_b"))), 0, 255).astype(np.uint8)
    np.savez(cache, **L)
LA = dict(np.load(B / "layers_A.npz"))          # mouths from the episode build (same plate, same anchors)
PLATE = to1080(plate0)


def over(img, rgba, a=1.0):
    al = rgba[..., 3:].astype(np.float32) / 255 * a
    return img * (1 - al) + rgba[..., :3].astype(np.float32) * al


def act(t):
    if t < to_out("A", 1.26):
        return "z_cheer", "smile_soft"
    if t < E_("A") + 0.2:
        return "z_cheer2", "smile_soft"
    return "z_cozy", "smile_soft"


blink = {int(bt * FPS) + i for bt in (E_("A") + 0.12,) for i in range(3)}

raw = subprocess.run([FF, "-v", "quiet", "-i", str(EP / "az2_clip.mp4"), "-vf", "fps=30,scale=1080:1920:flags=lanczos", "-an",
                      "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
CLIP = np.frombuffer(raw, np.uint8).reshape(-1, 1920, 1080, 3).copy(); CN = len(CLIP)
# paint the pre-lit flame out of the clip until the candle leaves the frame (track the jar rim by template matching)
F0 = CLIP[0]
FLAME0 = (980, 1183)                                   # flame centre on frame 0 (1080x1920 space)
TPL = cv2.cvtColor(F0[1196:1262, 930:1040], cv2.COLOR_RGB2GRAY)
for fi in range(min(CN, int(CANDLE_OUT * 30) + 1)):
    fr = CLIP[fi]
    g = cv2.cvtColor(fr, cv2.COLOR_RGB2GRAY)
    best = None
    for sc in (1.0, 1.04, 1.08, 1.12, 1.16):
        tp = cv2.resize(TPL, None, fx=sc, fy=sc)
        res = cv2.matchTemplate(g, tp, cv2.TM_CCOEFF_NORMED)
        _, mv, _, ml = cv2.minMaxLoc(res)
        if best is None or mv > best[0]:
            best = (mv, ml, sc)
    mv, (x, y), sc = best
    if mv >= 0.6 and x + 110 * sc <= 1078:
        cx = int(x + (FLAME0[0] - 930) * sc); cy = int(y + (FLAME0[1] - 1196) * sc)
        if fi and "_last" in dir():
            _vel = (cx - _last[0], cy - _last[1], sc)
        _last = (cx, cy, sc)
    elif "_last" in dir():                                # jar half out of frame: keep moving with the last velocity
        v = _vel if "_vel" in dir() else (0, 0, _last[2])
        cx, cy = _last[0] + v[0], _last[1] + v[1]; sc = _last[2]
        _last = (cx, cy, sc)
        if cx - 20 > 1080:
            continue
    else:
        continue
    mk = np.zeros(g.shape, np.uint8)
    cv2.ellipse(mk, (cx, cy), (int(15 * sc), int(36 * sc)), 0, 0, 360, 255, -1)
    CLIP[fi] = cv2.inpaint(fr, mk, 6, cv2.INPAINT_TELEA)

# safety net (frames where the hand hides the jar rim and tracking drifts): any small near-white blob above the table
# on the right side is the pre-lit flame → paint it out too
for fi in range(min(CN, int(CANDLE_OUT * 30) + 1)):
    fr = CLIP[fi]; f32 = fr.astype(np.int16)
    reg = np.zeros(fr.shape[:2], bool); reg[1000:1420, 820:1080] = True
    hot = reg & (f32.sum(2) > 690) & (f32[..., 0] >= f32[..., 2])
    if not hot.any():
        continue
    n, lab, st, _ = cv2.connectedComponentsWithStats(hot.astype(np.uint8))
    mk = np.zeros(fr.shape[:2], np.uint8)
    for j in range(1, n):
        if st[j, cv2.CC_STAT_AREA] < 900 and st[j, cv2.CC_STAT_HEIGHT] >= st[j, cv2.CC_STAT_WIDTH]:
            mk[lab == j] = 255
    if mk.any():
        CLIP[fi] = cv2.inpaint(fr, cv2.dilate(mk, np.ones((15, 15), np.uint8)), 6, cv2.INPAINT_TELEA)


# ---------------------------------------------------------------- end plate D (clip @4.25 s, faceless) + its kit layers
GD = dict(R=76, eyeL=(485, 722), eyeR=(653, 724), browL=(474, 582), browR=(645, 566), mouth=(575, 870), ms=1.22)
plateD0 = cv2.imread(str(EP / "lam_ep3_D_faceless.png"))[:, :, ::-1].astype(np.float32)
LOCAL_D = cv2.GaussianBlur(plateD0, (0, 0), 22)
K.EXPR["z_end"] = X((0.24, -2, 0, (0.30, 0.40), 1.02, True), (0.22, 2, 0, (0.30, 0.40), 1.02, True), ("soft", -0.02), ("soft", -0.06))


def grade_d(lay, seed=1):
    rgb, a = lay[..., :3].copy(), lay[..., 3]
    lum = rgb @ np.array([0.299, 0.587, 0.114])
    nv = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] + 8) & (lum < 150)).astype(np.float32), (0, 0), 0.8)[..., None]
    rgb = rgb * (1 - nv) + np.clip(LOCAL_D * np.clip(lum / NAVY_L, 0.45, 1.30)[..., None], 0, 255) * nv
    rgb = cv2.GaussianBlur(rgb * GRADE, (0, 0), 1.3) + np.random.default_rng(seed).normal(0, 1.6, rgb.shape[:2])[..., None]
    return np.dstack([np.clip(rgb, 0, 255), cv2.GaussianBlur(a, (0, 0), 1.1)])


def face_inner_d(ex, closed=False):
    saved = copy.deepcopy(K.EXPR[ex]); e = K.EXPR[ex]
    if closed:
        for side in ("eyeL", "eyeR"):
            l = list(e[side]); l[0], l[2] = 0.97, 0.0; e[side] = tuple(l)
    R = GD["R"]; u = lambda p: (p[0] / R, p[1] / R)
    inner = K.face(R, ex, eyeL=u(GD["eyeL"]), eyeR=u(GD["eyeR"]), browL=u(GD["browL"]), browR=u(GD["browR"]), mouthc=u(GD["mouth"]), mscale=GD["ms"])
    K.EXPR[ex] = saved
    return inner


cacheD = B / "layers_D_az.npz"
if cacheD.exists():
    LD = dict(np.load(cacheD))
else:
    LD = {"face": np.clip(to1080(grade_d(render_svg(face_inner_d("z_end"), "azD_face"))), 0, 255).astype(np.uint8),
          "blink": np.clip(to1080(grade_d(render_svg(face_inner_d("z_end", True), "azD_blink"))), 0, 255).astype(np.uint8)}
    inner = f'<g transform="translate({GD["mouth"][0]},{GD["mouth"][1]})">{K.mouth_for_expr(GD["R"], ("smile_soft", False), GD["ms"])}</g>'
    LD["mouth"] = np.clip(to1080(grade_d(render_svg(inner, "azD_mouth"), 3)), 0, 255).astype(np.uint8)
    np.savez(cacheD, **LD)
PLATE_D = to1080(plateD0)
# flames (candle + match) on plate D: warm bright pixels → gentle flicker so the ending is alive, not a freeze
_w = (PLATE_D[..., 0] > 200) & (PLATE_D[..., 1] > 150) & (PLATE_D[..., 2] < 210) & (np.mgrid[0:1920, 0:1080][0] > 780)
FLAME_D = cv2.GaussianBlur(_w.astype(np.float32), (0, 0), 6)[..., None]
_rng = np.random.default_rng(5)
FLICK = np.convolve(_rng.normal(0, 1, 400), np.ones(4) / 4, "same")


def end_frame(k, t_in):
    img = PLATE_D * (1 + FLAME_D * 0.10 * FLICK[k % 400])
    blink_now = 1.05 <= t_in < 1.15
    img = over(img, LD["blink" if blink_now else "face"])
    return over(img, LD["mouth"])


def cam(img, z, fx, fy):
    cw, ch = 1080 / z, 1920 / z
    x0 = float(np.clip(fx - cw / 2, 0, 1080 - cw)); y0 = float(np.clip(fy - ch / 2, 0, 1920 - ch))
    return cv2.warpAffine(img, np.float32([[z, 0, -x0 * z], [0, z, -y0 * z]]), (1080, 1920), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)


CSS = (f"@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}"
       "html,body{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}body{font-family:Vaz;direction:rtl}")


def ov(name, body):
    p = B / f"az_ov_{name}.png"
    html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style>{body}", p, 1080, 1920)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


OV = {
    "title": ov("title", f"<div style='position:absolute;left:60px;right:60px;top:250px;text-align:center'><div style='display:inline-block;"
                         f"background:rgba(14,22,40,.82);border:2px solid rgba(201,162,39,.65);border-radius:30px;padding:18px 44px'>"
                         f"<div style='font-size:86px;font-weight:900;color:{CREAM}'>آذرجشن <span style='color:{GOLD}'>مبارک</span> 🔥</div>"
                         f"<div style='font-size:38px;font-weight:700;color:#D9CFB0;margin-top:6px'>جشن ایرانی آتش · اول آذر</div></div></div>"),
    "sub": ov("sub", f"<div style='position:absolute;left:50px;right:50px;top:1440px;text-align:center'><span style='display:inline-block;"
                     f"background:rgba(14,22,40,.74);border-radius:22px;padding:10px 30px;font-size:56px;font-weight:700;color:{CREAM}'>"
                     f"امشب: گوشی خاموش… <span style='color:{GOLD}'>شمع روشن.</span></span></div>"),
    "end": ov("end", f"<div style='position:absolute;left:60px;right:60px;top:260px;text-align:center'><div style='display:inline-block;"
                     f"background:rgba(14,22,40,.86);border:2px solid rgba(201,162,39,.7);border-radius:28px;padding:18px 40px'>"
                     f"<div style='font-size:62px;font-weight:900;color:{CREAM}'>شب اول چالش ۳۰ شب 🌙</div>"
                     f"<div style='font-size:44px;font-weight:800;color:{GOLD};margin-top:6px'>۹:۳۰ · گروه تلگرام پله</div></div></div>"),
}

enc = subprocess.Popen([FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", str(B / "az2_video.mp4")], stdin=subprocess.PIPE)
for k in range(N):
    t = k / FPS
    if t < T_CLIP:
        ex, rest = act(t)
        img = over(PLATE, L[("blink_" if k in blink else "face_") + ex])
        img = over(img, LA[f"rest_{rest}"] if vis[k] == "X" else LA[f"m_{vis[k]}"])
        u = t / T_CLIP
        img = cam(img, 1.00 + 0.10 * u, 560, 940 - 20 * u)
    else:
        ts = t - T_CLIP
        hold = max(0.0, t - T_END) / max(1e-3, DUR - T_END)
        if ts < CLIP_SRC_END or not USE_PLATE_D:
            img = CLIP[min(CN - 1, int(min(ts, CLIP_SRC_END) * 30))].astype(np.float32)
        else:
            img = end_frame(k, ts - CLIP_SRC_END)
            xf = (ts - CLIP_SRC_END) / 0.15                       # 0.15 s crossfade from the clip's last frame into plate D
            if xf < 1:
                img = img * xf + CLIP[min(CN - 1, int(CLIP_SRC_END * 30))].astype(np.float32) * (1 - xf)
        img = cam(img, 1.02 + 0.04 * hold, 540, 940)
        if t > DUR - 0.5:                                         # soft fade to navy at the very end
            fa = (t - (DUR - 0.5)) / 0.5
            img = img * (1 - fa) + np.array([27, 42, 74], np.float32) * fa
    a_t = np.clip(min(t / 0.25, (T_CLIP + 1.2 - t) / 0.3), 0, 1)
    img = over(img, OV["title"], a_t)
    if S_("B") - 0.05 <= t < E_("B3") + 0.3:
        img = over(img, OV["sub"], np.clip(min((t - S_("B") + 0.05) / 0.12, (E_("B3") + 0.3 - t) / 0.2), 0, 1))
    if t >= E_("B3") + 0.25:
        img = over(img, OV["end"], np.clip((t - E_("B3") - 0.25) / 0.25, 0, 1))
    enc.stdin.write(np.clip(img, 0, 255).astype(np.uint8).tobytes())
enc.stdin.close(); enc.wait()

# audio: voice + soft music + a match strike under the candle
mus = load(W0 / "reel_d010" / "music_leberch_reading.mp3")[int(60 * SR):int(60 * SR) + NS]
mus = np.pad(mus, (0, max(0, NS - len(mus))))
tt = np.arange(NS) / SR
mix = voice + mus * 0.12 * np.clip(tt / 0.5, 0, 1) * np.clip((DUR - tt) / 1.4, 0, 1)
mix = mix[:int(DUR * SR)]; mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
with wave.open(str(B / "az2_mix.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype(np.int16).tobytes())
subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "az2_video.mp4"), "-i", str(B / "az2_mix.wav"), "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                "-c:v", "libx264", "-preset", "slow", "-b:v", "2200k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-ar", "48000",
                "-shortest", "-movflags", "+faststart", str(EP / "azarjashn_story_v2.mp4")], check=True)
subprocess.run([FF, "-y", "-v", "error", "-i", str(EP / "azarjashn_story_v2.mp4"), "-vf", "fps=3,scale=216:384,tile=8x4", "-frames:v", "1",
                str(B / "az2_check.jpg")], check=True)
print("done", round(DUR, 2))



