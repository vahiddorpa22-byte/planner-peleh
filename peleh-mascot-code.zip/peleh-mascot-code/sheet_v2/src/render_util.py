"""Headless-Edge rendering helpers (same approach as peleh_work/build_reel_d009.py)."""
import subprocess, tempfile, os
from pathlib import Path
from PIL import Image

EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
ROOT = Path(__file__).resolve().parents[1]
FONT = (ROOT.parents[1] / "app_ref" / "Vazirmatn-Variable.woff2").as_uri()


def html_to_png(html, png, w, h, scale=1, transparent=True):
    png = Path(png)
    png.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.gettempdir()) / f"lam_{os.getpid()}_{png.stem}.html"
    tmp.write_text(html, encoding="utf-8")
    args = [EDGE, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run",
            f"--window-size={w},{h}", f"--force-device-scale-factor={scale}",
            f"--screenshot={png}", tmp.as_uri()]
    if transparent:
        args.insert(4, "--default-background-color=00000000")
    subprocess.run(args, check=True, capture_output=True, timeout=180)
    im = Image.open(png)
    if im.size != (w * scale, h * scale):
        im.crop((0, 0, w * scale, h * scale)).save(png)
    return png


def render_sprites(items, out_dir, cell=(400, 400), cols=8, name="sprite"):
    """items: list of (filename, svg_string sized cell). Renders all in one Edge call and crops."""
    out_dir = Path(out_dir)
    rows = (len(items) + cols - 1) // cols
    W, H = cell[0] * cols, cell[1] * rows
    divs = []
    for i, (_, svg) in enumerate(items):
        x, y = (i % cols) * cell[0], (i // cols) * cell[1]
        divs.append(f'<div style="position:absolute;left:{x}px;top:{y}px;width:{cell[0]}px;height:{cell[1]}px">{svg}</div>')
    html = ("<!doctype html><meta charset='utf-8'><style>html,body{margin:0;background:transparent}</style>"
            + "".join(divs))
    sheet = out_dir / f"_{name}.png"
    html_to_png(html, sheet, W, H)
    im = Image.open(sheet).convert("RGBA")
    for i, (fn, _) in enumerate(items):
        x, y = (i % cols) * cell[0], (i // cols) * cell[1]
        p = out_dir / fn
        p.parent.mkdir(parents=True, exist_ok=True)
        im.crop((x, y, x + cell[0], y + cell[1])).save(p)
    sheet.unlink()
