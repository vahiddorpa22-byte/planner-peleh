"""«بهانه‌های لَم» episode 2 «وقت ندارم» (2026-11-11).
Inputs (from Vahid): ep2/lam_ep2_start.jpg (still), ep2/lam_ep2_flow_clip.mp4 (10 s Flow clip),
                     ep2/lam_ep2_lam.mp3 (Danesh, 2 takes), ep2/lam_ep2_peleh.mp3 (Sara, 2 takes).
No face kit for this pose → no lip-sync; Lam "talks" with a tiny head-bob driven by his voice energy, plus subtitles.
Order: L1 «وقتِ کتاب ندارم» · P1 «چهل و هفت دقیقه؟» · L2 «[آه] اونا حساب نیست» · P2 «پونزده دقیقه‌ش مالِ کتاب» · reading + CTA.
Output: ep2/lam_ep2_final.mp4 (+ _upload.mp4), ep2/lam_ep2_timeline.json, ep2/check_sheet_ep2.jpg, ep2/frame0_lam_ep2.jpg
"""
from pathlib import Path
import json, subprocess, wave
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
from render_util import html_to_png, FONT
from gold_step import ding_wav

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
W0 = MASCOT.parent
EP = MASCOT / "ep2"
B = EP / "_build"
B.mkdir(exist_ok=True)
FF = imageio_ffmpeg.get_ffmpeg_exe()
FPS, SR = 30, 44100
GOLD, CREAM = "#C9A227", "#F3F0E8"
TEMPO = 1.08
TARGET_I = -14.0


def load(p, sr=SR):
    raw = subprocess.run([FF, "-v", "quiet", "-i", str(p), "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768


def fade(x, ms=15):
    n = int(SR * ms / 1000); x = x.copy()
    x[:n] *= np.linspace(0, 1, n); x[-n:] *= np.linspace(1, 0, n)
    return x


def tempo(y, f):
    out = subprocess.run([FF, "-v", "quiet", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "-", "-af", f"atempo={f}", "-f", "f32le", "-"],
                         input=y.astype(np.float32).tobytes(), capture_output=True).stdout
    return np.frombuffer(out, np.float32).copy()


lam = load(EP / "lam_ep2_lam.mp3")
pel = load(EP / "lam_ep2_peleh.mp3")
# boundaries from a 20 ms energy map (voiced: L 0.16–3.08 | 4.36–7.04 ; P 0.16–3.22 | 3.84–6.96)
ITEMS = [("L1", "L", 0.06, 3.20, 0.05),   # وقتِ کتاب... ندارم.
         ("P1", "P", 0.06, 3.34, 0.14),   # چهل و هفت... دقیقه؟
         ("L2", "L", 4.24, 7.18, 0.14),   # [آه] اونا... حساب نیست.
         ("P2", "P", 3.72, 7.12, 0.12)]   # پونزده دقیقه‌ش... مالِ کتاب.
segs, t = {}, 0.0
for key, spk, a, b, gap in ITEMS:
    src = lam if spk == "L" else pel
    y = fade(tempo(fade(src[int(a * SR):int(b * SR)]), TEMPO))
    t += gap
    segs[key] = (t, t + len(y) / SR, y, spk)
    t += len(y) / SR
S_ = lambda k: segs[k][0]
E_ = lambda k: segs[k][1]
TAIL = 2.6
DUR = E_("P2") + TAIL
T_CTA = E_("P2") + 0.35
N = int(round(DUR * FPS)); NS = int(DUR * SR) + SR
lam_tr, pel_tr = np.zeros(NS, np.float32), np.zeros(NS, np.float32)
for key, (a, b, y, spk) in segs.items():
    tr = lam_tr if spk == "L" else pel_tr
    i = int(a * SR); tr[i:i + len(y)] += y[:max(0, min(len(y), NS - i))]
print({k: (round(v[0], 2), round(v[1], 2)) for k, v in segs.items()}, "DUR", round(DUR, 2))

# head-bob envelope from Lam's voice (smoothed RMS per video frame)
hop = SR // FPS
lr = np.array([np.sqrt((lam_tr[k * hop:(k + 1) * hop] ** 2).mean() + 1e-12) for k in range(N)])
lr = np.convolve(lr, np.ones(4) / 4, "same"); lr = lr / (np.percentile(lr[lr > 0.005], 95) + 1e-6) if (lr > 0.005).any() else lr
BOB = np.clip(lr, 0, 1)

# ---------------------------------------------------------------- sources
still = cv2.imread(str(EP / "lam_ep2_start.jpg"))[:, :, ::-1]
s = 1080 / still.shape[1]
still = cv2.resize(still, (1080, round(still.shape[0] * s)), interpolation=cv2.INTER_AREA)
oy = (still.shape[0] - 1920) // 2
STILL = still[oy:oy + 1920].astype(np.float32) if still.shape[0] >= 1920 else cv2.resize(still, (1080, 1920)).astype(np.float32)

raw = subprocess.run([FF, "-v", "quiet", "-i", str(EP / "lam_ep2_flow_clip.mp4"), "-vf", "fps=30,scale=1080:1920:flags=lanczos",
                      "-an", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
CLIP = np.frombuffer(raw, np.uint8).reshape(-1, 1920, 1080, 3)
CN = len(CLIP); print("clip frames", CN)

# clip mapping: L2 ← clip 0.0–2.5 (scroll + surprised look) · P2 ← clip 2.5–6.0 (phone down, book) · tail ← clip 6.0–10.0 (reading)
C_L2 = (S_("L2") - 0.10, 0.0, 2.5)
C_P2 = (S_("P2") - 0.06, 2.5, 6.0)
C_T = (E_("P2"), 6.0, CN / FPS - 0.04)


def clip_frame(t):
    for (t0, a, b), t1 in ((C_L2, C_P2[0]), (C_P2, C_T[0]), (C_T, DUR)):
        if t0 <= t < t1:
            u = (t - t0) / max(1e-3, t1 - t0)
            return CLIP[min(CN - 1, int((a + (b - a) * u) * FPS))].astype(np.float32)
    return None


def cam(img, z, fx, fy):
    cw, ch = 1080 / z, 1920 / z
    x0 = float(np.clip(fx - cw / 2, 0, 1080 - cw)); y0 = float(np.clip(fy - ch / 2, 0, 1920 - ch))
    M = np.float32([[z, 0, -x0 * z], [0, z, -y0 * z]])
    out = cv2.warpAffine(img, M, (1080, 1920), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
    if z > 1.25:
        out = out + 0.3 * (out - cv2.GaussianBlur(out, (0, 0), 1.2))
    return out


# shots on the still: (t0, t1, z0, z1, fx, fy)
STILL_SHOTS = [(0.0, S_("P1") - 0.07, 1.00, 1.07, 540, 900),                      # wide, slow push-in (hook)
               (S_("P1") - 0.07, C_L2[0], 1.38, 1.46, 430, 930)]                  # punch-in: face + phone during «۴۷ دقیقه؟»

# ---------------------------------------------------------------- overlays (safe zone y 220–1540)
CSS = (f"@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}"
       "html,body{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}body{font-family:Vaz;direction:rtl}")


def ov(name, body):
    p = B / f"ov_{name}.png"
    html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style>{body}", p, 1080, 1920)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def sub(text, color):
    return (f"<div style='position:absolute;left:50px;right:50px;top:1420px;text-align:center'><span style='display:inline-block;"
            f"background:rgba(14,22,40,.74);border-radius:22px;padding:10px 30px;font-size:58px;font-weight:700;line-height:1.35;color:{color}'>{text}</span></div>")


ICON = (W0 / "app_ref" / "icon-512.png").as_uri()
OV = {
    "label": ov("label", f"<div style='position:absolute;right:46px;top:236px;background:rgba(14,22,40,.72);border:2px solid rgba(201,162,39,.7);"
                         f"border-radius:20px;padding:6px 20px;font-size:36px;font-weight:800;color:{CREAM}'>لَم · <span style='color:{GOLD}'>قسمت ۲</span></div>"),
    "hook": ov("hook", f"<div style='position:absolute;left:60px;right:60px;top:330px;text-align:center'><div style='display:inline-block;"
                       f"background:rgba(14,22,40,.84);border:2px solid rgba(201,162,39,.6);border-radius:28px;padding:20px 44px;font-size:84px;"
                       f"font-weight:800;color:{CREAM}'>وقتِ کتاب <span style='color:{GOLD}'>ندارم.</span></div></div>"),
    "counter": ov("counter", f"<div style='position:absolute;left:0;right:0;top:330px;text-align:center'><div style='display:inline-block;"
                             f"background:{GOLD};border-radius:999px;padding:14px 40px;font-size:62px;font-weight:900;color:#1B2A4A;"
                             f"box-shadow:0 10px 40px rgba(0,0,0,.45)'>📱 ۴۷ دقیقه ریلز</div></div>"),
    "P1": ov("P1", sub("چهل و هفت دقیقه؟", GOLD)),
    "L2": ov("L2", sub("…اونا حساب نیست.", CREAM)),
    "P2": ov("P2", sub("پونزده دقیقه‌ش مالِ کتاب.", GOLD)),
    "cta": ov("cta", f"<div style='position:absolute;left:50px;right:50px;top:300px;text-align:center'><div style='display:inline-block;"
                     f"background:rgba(14,22,40,.86);border:2px solid rgba(201,162,39,.7);border-radius:30px;padding:22px 44px'>"
                     f"<div style='font-size:74px;font-weight:800;color:{CREAM};line-height:1.35'>بهانه‌ی بعدی مال تو؟</div>"
                     f"<div style='font-size:42px;font-weight:700;color:{GOLD};margin-top:8px'>لَم · قسمت ۳ دوشنبه · فالو کن</div></div></div>"
                     f"<div style='position:absolute;left:0;right:0;top:1400px;text-align:center'><div style='display:inline-flex;align-items:center;gap:18px;"
                     f"background:rgba(14,22,40,.80);border-radius:26px;padding:12px 28px 12px 18px'><img src='{ICON}' style='width:84px;height:84px;"
                     f"border-radius:20px;box-shadow:0 0 0 2px {GOLD}'><span style='font-size:50px;font-weight:800;color:{CREAM}'>پله</span></div></div>"),
}


def over(img, rgba, a=1.0):
    al = rgba[..., 3:] / 255 * a
    return img * (1 - al) + rgba[..., :3] * al


T_COUNT = E_("L1") - 0.05
enc = subprocess.Popen([FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", str(B / "video.mp4")], stdin=subprocess.PIPE)
for k in range(N):
    t = k / FPS
    cf = clip_frame(t)
    if cf is None:
        sh = next(x for x in STILL_SHOTS if x[0] <= t < x[1] + 1e-6) if t < STILL_SHOTS[-1][1] else STILL_SHOTS[-1]
        u = np.clip((t - sh[0]) / max(1e-3, sh[1] - sh[0]), 0, 1)
        z = sh[2] + (sh[3] - sh[2]) * u + 0.010 * BOB[k]
        img = cam(STILL, z, sh[4], sh[5] - 6 * BOB[k])
    else:
        z = (1.04 if t < C_T[0] else 1.04 + 0.05 * np.clip((t - C_T[0]) / TAIL, 0, 1)) + 0.010 * BOB[k]
        img = cam(cf, z, 540, 940 - 6 * BOB[k])
    img = over(img, OV["label"])
    if t < S_("P1") - 0.05:
        img = over(img, OV["hook"], np.clip((S_("P1") - 0.05 - t) / 0.2, 0, 1))
    if T_COUNT <= t < S_("P2"):
        a = np.clip(min((t - T_COUNT) / 0.15, (S_("P2") - t) / 0.2), 0, 1)
        c = OV["counter"]
        if t - T_COUNT < 0.3:
            sc = 1 + 0.18 * np.exp(-((t - T_COUNT - 0.08) / 0.09) ** 2)
            c = cv2.warpAffine(c, cv2.getRotationMatrix2D((540, 380), 0, sc), (1080, 1920), borderValue=(0, 0, 0, 0))
        img = over(img, c, a)
    for key in ("P1", "L2", "P2"):
        if S_(key) - 0.05 <= t < E_(key) + 0.25 and t < T_CTA:
            img = over(img, OV[key], np.clip(min((t - S_(key) + 0.05) / 0.12, (E_(key) + 0.25 - t) / 0.15), 0, 1))
    if t >= T_CTA:
        img = over(img, OV["cta"], np.clip((t - T_CTA) / 0.2, 0, 1))
    enc.stdin.write(np.clip(img, 0, 255).astype(np.uint8).tobytes())
enc.stdin.close(); enc.wait()

# ---------------------------------------------------------------- audio
mus = load(W0 / "reel_d010" / "music_leberch_reading.mp3")
mus = mus[int(2.0 * SR):int(2.0 * SR) + NS]; mus = np.pad(mus, (0, max(0, NS - len(mus))))
voice = lam_tr + pel_tr
act = np.convolve((np.abs(voice) > 0.01).astype(np.float32), np.ones(int(0.25 * SR)) / int(0.25 * SR), "same") > 0.02
duck = np.convolve(np.where(act, 0.09, 0.20).astype(np.float32), np.ones(int(0.3 * SR)) / int(0.3 * SR), "same")
tt = np.arange(NS) / SR
duck *= np.clip(tt / 0.4, 0, 1) * np.clip((DUR - tt) / 0.7, 0, 1)
mix = voice + mus * duck


def add(x, at, g):
    i = int(at * SR)
    if 0 <= i < NS:
        n = max(0, min(len(x), NS - i)); mix[i:i + n] += x[:n] * g


wh = load(W0 / "reel_d013" / "_build" / "sfx_whoosh.wav")
add(wh, C_L2[0] - 0.05, 0.12)                                     # cut to the clip
pt = load(W0 / "audio" / "page_turn.wav"); pt = pt[:int(0.9 * SR)] * np.linspace(1, 0, int(0.9 * SR)) ** 0.5
book_open = C_P2[0] + (C_T[0] - C_P2[0]) * ((5.2 - 2.5) / (6.0 - 2.5))
add(pt, book_open, 0.40)
ding_wav(B / "ding.wav", at=0.0, total=2.0, sr=SR)
add(load(B / "ding.wav"), T_CTA + 0.05, 0.6)
add(load(B / "ding.wav")[:int(0.6 * SR)], T_COUNT, 0.25)          # tiny tick when the counter pops
mix = mix[:int(DUR * SR)]; mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
with wave.open(str(B / "mix.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype(np.int16).tobytes())


def lufs(path):
    e = subprocess.run([FF, "-hide_banner", "-i", str(path), "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    s_ = e[e.rindex("Summary:"):]
    return float(s_.split("I:")[1].split("LUFS")[0]), float(s_.split("Peak:")[1].split("dBFS")[0])


I0, _ = lufs(B / "mix.wav"); gain = TARGET_I - I0
for _ in range(4):
    subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "mix.wav"), "-af", f"volume={gain:.2f}dB,alimiter=limit=0.84:attack=3:release=60:level=false,aresample=48000",
                    "-ac", "2", str(B / "mix_norm.wav")], check=True)
    I1, tp1 = lufs(B / "mix_norm.wav")
    if abs(I1 - TARGET_I) < 0.3:
        break
    gain += TARGET_I - I1
out = EP / "lam_ep2_final.mp4"
subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "video.mp4"), "-i", str(B / "mix_norm.wav"), "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                "-shortest", "-movflags", "+faststart", str(out)], check=True)
subprocess.run([FF, "-y", "-v", "error", "-i", str(out), "-c:v", "libx264", "-preset", "slow", "-b:v", "1700k", "-maxrate", "2200k", "-bufsize", "4400k",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(EP / "lam_ep2_final_upload.mp4")], check=True)
subprocess.run([FF, "-y", "-v", "error", "-i", str(out), "-frames:v", "1", "-q:v", "2", str(EP / "frame0_lam_ep2.jpg")], check=True)
# check sheet every 0.5 s
tiles = []
for ti in np.arange(0, DUR, 0.5):
    r = subprocess.run([FF, "-v", "quiet", "-ss", f"{ti:.2f}", "-i", str(out), "-frames:v", "1", "-vf", "scale=180:320", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                       capture_output=True).stdout
    if len(r) == 180 * 320 * 3:
        tiles.append(np.frombuffer(r, np.uint8).reshape(320, 180, 3))
cols = 10; rows = (len(tiles) + cols - 1) // cols
sheet = np.full((rows * 320, cols * 180, 3), 255, np.uint8)
for i, tl in enumerate(tiles):
    sheet[(i // cols) * 320:(i // cols + 1) * 320, (i % cols) * 180:(i % cols + 1) * 180] = tl
Image.fromarray(sheet).save(EP / "check_sheet_ep2.jpg", quality=85)
json.dump({"segments": {k: [round(v[0], 3), round(v[1], 3)] for k, v in segs.items()}, "T_COUNT": T_COUNT, "clip_L2": C_L2, "clip_P2": C_P2,
           "clip_tail": C_T, "T_CTA": T_CTA, "DUR": DUR, "loudness": {"input_I": I0, "out_I": I1, "out_TP": tp1}},
          open(EP / "lam_ep2_timeline.json", "w"), indent=1)
print("done", out, round(DUR, 2), "LUFS", I1)
