import subprocess, numpy as np, imageio_ffmpeg, sys
from pathlib import Path
EP = Path(__file__).resolve().parents[2] / "ep1"
ff = imageio_ffmpeg.get_ffmpeg_exe()


def load(p, sr=22050):
    raw = subprocess.run([ff, "-v", "quiet", "-i", str(p), "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768, sr


for n in ("lam_ep1_lam.mp3", "lam_ep1_peleh.mp3"):
    x, sr = load(EP / "voice" / n)
    hop = sr // 100
    rms = np.sqrt(np.convolve(x ** 2, np.ones(hop * 3) / (hop * 3), "same"))[::hop]
    th = max(0.012, 0.08 * np.percentile(rms, 95))
    on = rms > th
    segs, i = [], 0
    while i < len(on):
        if on[i]:
            j = i
            while j < len(on) and (on[j] or (j + 35 < len(on) and on[j:j + 35].any())):  # bridge gaps < 0.35 s
                j += 1
            segs.append((i / 100, j / 100))
            i = j
        i += 1
    print(n, f"len={len(x)/sr:.2f}s th={th:.3f}")
    for a, b in segs:
        print(f"   {a:6.2f} - {b:6.2f}  ({b-a:.2f})")
