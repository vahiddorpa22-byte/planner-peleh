"""Cut Vahid's prop renders (grey bg) and place them on the locked app canvas (R1 coords + offset).
Writes 1720x1720 RGBA layers to app_assets/_work/prop_<name>.png."""
from pathlib import Path
import numpy as np, cv2
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
SRC = MASCOT / "renders_vahid" / "app_props"
WORK = MASCOT / "app_assets" / "_work"
CANVAS, OX, OY = 1720, 193, -120

r1 = cv2.imread(str(ROOT / "renders_cc" / "lam_r_front_noface_01_v1_cc.png"))[:, :, ::-1].astype(np.float32)
BASE_NAVY = np.median(r1[700:1200, 400:900].reshape(-1, 3), 0)


def load(n):
    return np.asarray(Image.open(SRC / n).convert("RGB")).astype(np.float32)


def poly(shape, pts):
    m = np.zeros(shape[:2], np.uint8); cv2.fillPoly(m, [np.array(pts, np.int32)], 1); return m


def cream_gold(img):
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    lum = img @ np.array([0.299, 0.587, 0.114])
    cream = (lum > 125) & (r > b + 8)
    gold = (r > b + 45) & (r > 90)
    white = (lum > 170) & (np.abs(r - b) < 30)
    return cream | gold, white


def grade_to_base(img, body_box):
    x0, y0, x1, y1 = body_box
    src_navy = np.median(img[y0:y1, x0:x1].reshape(-1, 3), 0)
    ratio = np.clip(BASE_NAVY / np.maximum(src_navy, 1), 0.6, 1.6)
    lum = img @ np.array([0.299, 0.587, 0.114])
    navyish = np.clip((img[..., 2] - img[..., 0] - 5) / 25, 0, 1) * np.clip((150 - lum) / 40, 0, 1)
    return img * (1 - navyish[..., None]) + img * ratio * navyish[..., None]


def place(img, alpha, src_anchor, dst_anchor_r1, sx, sy=None):
    sy = sy or sx
    M = np.float32([[sx, 0, dst_anchor_r1[0] + OX - src_anchor[0] * sx], [0, sy, dst_anchor_r1[1] + OY - src_anchor[1] * sy]])
    rgba = np.dstack([img, alpha * 255]).astype(np.float32)
    pm = np.dstack([rgba[..., :3] * alpha[..., None], rgba[..., 3:]])
    out = cv2.warpAffine(pm, M, (CANVAS, CANVAS), flags=cv2.INTER_AREA if sx < 1 else cv2.INTER_CUBIC, borderValue=(0, 0, 0, 0))
    a = np.clip(out[..., 3:], 0, 255) / 255
    rgb = out[..., :3] / np.maximum(a, 1e-4)
    return np.clip(np.dstack([rgb, a * 255]), 0, 255)


def refine(img, rough, fgsure=None, iters=5):
    gc = np.where(rough > 0, cv2.GC_PR_FGD, cv2.GC_BGD).astype(np.uint8)
    if fgsure is not None:
        gc[fgsure > 0] = cv2.GC_FGD
    cv2.grabCut(img.astype(np.uint8)[:, :, ::-1].copy(), gc, None, np.zeros((1, 65)), np.zeros((1, 65)), iters, cv2.GC_INIT_WITH_MASK)
    return np.isin(gc, (1, 3)).astype(np.uint8)


def soft(m, s=0.9):
    return cv2.GaussianBlur(m.astype(np.float32), (0, 0), s)


def save(name, rgba):
    Image.fromarray(rgba.astype(np.uint8), "RGBA").save(WORK / f"prop_{name}.png")
    print(name)


# ---------------- scarf: cream/gold knit only
sc = load("scarf.webp")
cg, _ = cream_gold(sc)
box = poly(sc.shape, [(150, 470), (950, 470), (950, 760), (480, 760), (480, 1120), (190, 1120), (190, 760), (150, 760)])
m = (cg & (box > 0)).astype(np.uint8)
m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
n, lbl, st, _ = cv2.connectedComponentsWithStats(m)
m = (lbl == 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])).astype(np.uint8)
ff = m.copy(); cv2.floodFill(ff, np.zeros((m.shape[0] + 2, m.shape[1] + 2), np.uint8), (0, 0), 1)
m[(ff == 0)] = 1
sc_g = grade_to_base(sc, (300, 420, 700, 480))
# render band centre (550, 620) -> base chest band (690, 1100); x-stretch to the wider locked body
save("scarf", place(sc_g, soft(m), (550, 495), (690, 990), 1.30, 0.90))

# ---------------- yoga mat
ym = load("yogamat.jpg")
cg, white = cream_gold(ym)
pm_ = poly(ym.shape, [(470, 1050), (488, 990), (540, 958), (620, 935), (780, 902), (845, 912), (868, 985), (858, 1066), (760, 1094), (600, 1132), (520, 1152), (478, 1122)])
m = ((cg | white) & (pm_ > 0)).astype(np.uint8)
m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
ff = m.copy(); cv2.floodFill(ff, np.zeros((m.shape[0] + 2, m.shape[1] + 2), np.uint8), (0, 0), 1); m[ff == 0] = 1
mat = place(ym, soft(m), (470, 1150), (1070, 1812), 1.22)
# soft contact shadow under the mat
sh = np.zeros((CANVAS, CANVAS), np.float32)
cv2.ellipse(sh, (1070 + OX + 230, 1812 + OY - 6), (240, 20), -6, 0, 360, 1.0, -1)
sh = cv2.GaussianBlur(sh, (0, 0), 10) * 0.40
sha = np.dstack([np.zeros((CANVAS, CANVAS, 3)) + np.array([8, 12, 24]), sh[..., None] * 255])
a1, a2 = sha[..., 3:] / 255, mat[..., 3:] / 255
oa = a2 + a1 * (1 - a2)
save("yoga", np.dstack([(mat[..., :3] * a2 + sha[..., :3] * a1 * (1 - a2)) / np.maximum(oa, 1e-4), oa * 255]))

# ---------------- volleyball: ball (circle) + wrapping hand
vb = load("volleyball.jpg")
ball = np.zeros(vb.shape[:2], np.uint8); cv2.circle(ball, (232, 640), 166, 1, -1)
hand = poly(vb.shape, [(18, 688), (60, 676), (100, 690), (125, 742), (198, 776), (228, 800), (222, 842), (160, 850), (95, 822), (45, 780), (18, 735)])
rough = cv2.dilate(((ball + hand) > 0).astype(np.uint8), np.ones((9, 9), np.uint8))
sure = cv2.erode(ball, np.ones((15, 15), np.uint8)) | cv2.erode(hand, np.ones((9, 9), np.uint8))
m = refine(vb, rough, sure)
m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
vb_g = grade_to_base(vb, (450, 300, 700, 500))
# hand over the base left hand, ball low at the hip/side (never the chest)
save("volleyball", place(vb_g, soft(m), (125, 772), (215, 1455), 1.12))

# ---------------- dumbbell: fist + plates
db = load("dumbbell.jpg")
pd = poly(db.shape, [(430, 640), (470, 610), (520, 612), (560, 588), (610, 558), (662, 544), (702, 560), (724, 620), (718, 700), (692, 762), (640, 782), (580, 772), (542, 762), (512, 802), (470, 808), (438, 782), (418, 740), (414, 690)])
rough = cv2.dilate(pd, np.ones((7, 7), np.uint8))
gold_rings = ((db[..., 0] > db[..., 2] + 40) & (pd > 0)).astype(np.uint8)
m = refine(db, rough, cv2.erode(pd, np.ones((25, 25), np.uint8)) | gold_rings)
m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
db_g = grade_to_base(db, (150, 300, 450, 520))
save("gym", place(db_g, soft(m), (630, 680), (1110, 1455), 1.15))
