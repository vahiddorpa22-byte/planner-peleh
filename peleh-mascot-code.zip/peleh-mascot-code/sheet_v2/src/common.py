﻿"""Shared page styles for the LAM sheet v2 (1920x1080, Vazirmatn, brand palette)."""
from pathlib import Path
from render_util import FONT, html_to_png

ROOT = Path(__file__).resolve().parents[1]
REFD = ROOT.parent / "ref"
NAVY, GOLD, CREAM, GREY = "#1B2A4A", "#C9A227", "#F3F0E8", "#8A8F99"
RED = "#E2574C"


def uri(p):
    return Path(p).resolve().as_uri()


CSS = f"""
@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}
*{{box-sizing:border-box;margin:0;padding:0}}
html,body{{width:1920px;height:1080px;overflow:hidden}}
body{{font-family:Vaz,sans-serif;background:#141F38;color:{CREAM};direction:rtl}}
.page{{position:relative;width:1920px;height:1080px;background:radial-gradient(120% 90% at 85% 0%,#22335A 0%,#16213C 55%,#0F172C 100%);overflow:hidden}}
.hdr{{position:absolute;top:0;left:0;right:0;height:96px;display:flex;align-items:center;padding:0 64px;border-bottom:1px solid rgba(201,162,39,.35)}}
.hdr .no{{font-size:15px;color:{GOLD};letter-spacing:.12em;font-weight:700;direction:ltr;margin-left:22px;border:1px solid {GOLD};border-radius:20px;padding:4px 12px}}
.hdr h1{{font-size:38px;font-weight:800;color:{CREAM}}}
.hdr h1 small{{font-size:19px;font-weight:400;color:#AEB4C2;margin-right:14px}}
.hdr .brand{{margin-right:auto;display:flex;align-items:center;gap:12px;font-size:20px;font-weight:800;color:{CREAM}}}
.hdr .brand b{{color:{GOLD};font-size:30px}}
.ftr{{position:absolute;bottom:0;left:0;right:0;height:44px;display:flex;align-items:center;padding:0 64px;font-size:14px;color:#8790A6;border-top:1px solid rgba(255,255,255,.07)}}
.ftr .l{{margin-right:auto;direction:ltr}}
.ltr{{direction:ltr;unicode-bidi:isolate}}
.tag{{display:inline-block;white-space:nowrap;font-size:13px;font-weight:700;padding:3px 10px;border-radius:12px;background:rgba(201,162,39,.16);color:{GOLD};border:1px solid rgba(201,162,39,.5)}}
.tag.red{{background:rgba(226,87,76,.15);color:#F08A80;border-color:rgba(226,87,76,.55)}}
.tag.grey{{background:rgba(255,255,255,.06);color:#C3C8D3;border-color:rgba(255,255,255,.2)}}
.card{{background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.09);border-radius:18px}}
.wait{{border:2px dashed rgba(201,162,39,.55);border-radius:18px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:{GOLD};background:repeating-linear-gradient(135deg,rgba(201,162,39,.04) 0 14px,transparent 14px 28px);text-align:center}}
.wait b{{font-size:24px;font-weight:800}}
.wait span{{font-size:15px;color:#AEB4C2;max-width:80%}}
h3{{font-size:22px;font-weight:800;color:{GOLD};margin-bottom:10px}}
p,li{{font-size:17px;line-height:1.75;color:#D9DCE4}}
"""

LOGO = f"""<svg width="34" height="30" viewBox="0 0 34 30"><path d="M0 30V22H8V15H16V8H24V0H34V30Z" fill="{GOLD}"/></svg>"""


def page(no, title, sub, body, footer_note=""):
    return (f"<!doctype html><meta charset='utf-8'><style>{CSS}</style><div class='page'>"
            f"<div class='hdr'><span class='no'>{no}</span><h1>{title}<small>{sub}</small></h1>"
            f"<div class='brand'>{LOGO}<span>لَم</span><span style='color:#8790A6;font-weight:400;font-size:15px'>شیت کاراکتر · بسته‌ی قفل P1 · نسخه‌ی ۲</span></div></div>"
            f"{body}<div class='ftr'><span>{footer_note}</span><span class='l'>peleh_work/mascot/sheet_v2 · 2026-11-02 · draft for Vahid</span></div></div>")


def render_page(html, png, scale=1):
    return html_to_png(html, png, 1920, 1080, scale=scale, transparent=False)
