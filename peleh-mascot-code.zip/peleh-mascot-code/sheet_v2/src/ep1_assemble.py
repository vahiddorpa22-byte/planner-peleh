"""Assemble «بهانه‌های لَم» episode 1 -> ep1/lam_ep1_final.mp4 (1080x1920, 30 fps, voices + music + SFX baked in)."""
from pathlib import Path
import copy, json, subprocess, wave
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
import lam_facekit as K
from render_util import html_to_png, FONT
from gold_step import light_up_frame, ding_wav

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
W0 = MASCOT.parent                                   # peleh_work
EP = MASCOT / "ep1"
BUILD = EP / "_build"
BUILD.mkdir(exist_ok=True)
FF = imageio_ffmpeg.get_ffmpeg_exe()
FPS, SR = 30, 44100
NAVY, GOLD, CREAM = "#1B2A4A", "#C9A227", "#F3F0E8"


# =============================================================== audio
def load(p, sr=SR):
    raw = subprocess.run([FF, "-v", "quiet", "-i", str(p), "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768


def rms_frames(x, hop):
    n = len(x) // hop
    return np.sqrt((x[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12)


def trim_internal(x, maxgap, th=0.0045):
    """Shorten silences inside a chunk to `maxgap` seconds (delivery kept, only dead air removed)."""
    hop = SR // 100
    r = rms_frames(x, hop)
    quiet = r < th
    keep = np.ones(len(r), bool)
    i = 0
    while i < len(r):
        if quiet[i]:
            j = i
            while j < len(r) and quiet[j]:
                j += 1
            run = j - i
            mg = int(maxgap * 100)
            if run > mg and i > 0 and j < len(r):
                a = i + mg // 2
                keep[a:a + run - mg] = False
            i = j
        else:
            i += 1
    out, cur = [], None
    for k in range(len(r)):
        if keep[k]:
            out.append(x[k * hop:(k + 1) * hop])
    y = np.concatenate(out + [x[len(r) * hop:]])
    return y


def fade(x, ms=25):
    n = int(SR * ms / 1000)
    x = x.copy()
    x[:n] *= np.linspace(0, 1, n)
    x[-n:] *= np.linspace(1, 0, n)
    return x


lam = load(EP / "voice" / "lam_ep1_lam.mp3")
pel = load(EP / "voice" / "lam_ep1_peleh.mp3")
cut = lambda x, a, b: x[int(a * SR):int(b * SR)]
CH = [  # (speaker, chunk audio, max internal gap)
    ("L1", cut(lam, 0.00, 7.10), 0.30),
    ("P1", cut(pel, 0.22, 3.78), 0.30),
    ("L2", cut(lam, 8.92, 11.78), 0.50),
    ("P2", cut(pel, 5.02, 8.38), 0.35),
    ("L3a", cut(lam, 13.32, 15.62), 0.30),
    ("L3b", cut(lam, 16.88, 20.15), 0.32),
]
GAPS = {"L1": 0.15, "P1": 0.14, "L2": 0.12, "P2": 0.14, "L3a": 0.14, "L3b": 0.10}
segs, t = {}, 0.0
for name, x, mg in CH:
    y = fade(trim_internal(x, mg))
    t += GAPS[name]
    segs[name] = (t, t + len(y) / SR, y)
    t += len(y) / SR


def last_voiced_start(y, min_len=0.6, th=0.01):
    r = rms_frames(y, SR // 100) > th
    runs, i = [], 0
    while i < len(r):
        if r[i]:
            j = i
            while j < len(r) and (r[j] or r[j:j + 12].any()):
                j += 1
            runs.append((i, j)); i = j
        i += 1
    for a, b in reversed(runs):
        if (b - a) / 100 >= min_len:
            return a / 100
    return runs[-1][0] / 100


def first_gap_after(y, after=2.0, gap=0.18, th=0.006):
    r = rms_frames(y, SR // 100) < th
    k0 = int(after * 100)
    for i in range(k0, len(r)):
        if r[i:i + int(gap * 100)].all():
            j = i + int(gap * 100)
            while j < len(r) and r[j]:
                j += 1
            return i / 100, j / 100
    return None


L1s, L1e, L1y = segs["L1"]
g = first_gap_after(L1y)
T_L1b = L1s + (g[1] if g else 3.4)                  # «ولی نشونه‌ش…» starts
L3bs, L3be, L3by = segs["L3b"]
T_14 = L3bs + last_voiced_start(L3by) - 0.05        # «چهارده‌م خوندم» starts
T_FLOW = (segs["L3a"][1] + L3bs) / 2                # cut to Flow between L3a and L3b
T_GOLD = T_14 + 0.05
T_END = max(L3be + 0.25, T_GOLD + 1.0)              # end card starts
DUR = T_END + 2.0
print({k: (round(v[0], 2), round(v[1], 2)) for k, v in segs.items()}, "L1b", round(T_L1b, 2), "flow", round(T_FLOW, 2),
      "14", round(T_14, 2), "end", round(T_END, 2), "dur", round(DUR, 2))

N = int(round(DUR * FPS))
NS = int(DUR * SR) + SR
lam_tr, pel_tr = np.zeros(NS, np.float32), np.zeros(NS, np.float32)
for name, (a, b, y) in segs.items():
    tr = lam_tr if name.startswith("L") else pel_tr
    i = int(a * SR); tr[i:i + len(y)] += y

# =============================================================== lip-sync (energy + spectral centroid -> 10 visemes)
hop = SR // FPS
def frame_feats(x):
    rms, cen = [], []
    win = np.hanning(2048)
    for k in range(N):
        c = int((k + 0.5) * hop)
        seg = x[max(0, c - 1024):c + 1024]
        if len(seg) < 2048:
            seg = np.pad(seg, (0, 2048 - len(seg)))
        rms.append(np.sqrt((x[k * hop:(k + 1) * hop] ** 2).mean() + 1e-12))
        sp = np.abs(np.fft.rfft(seg * win))
        f = np.fft.rfftfreq(2048, 1 / SR)
        cen.append((sp * f).sum() / (sp.sum() + 1e-9))
    return np.array(rms), np.array(cen)


lr, lc = frame_feats(lam_tr)
lr = np.convolve(lr, [0.25, 0.5, 0.25], "same")
p95 = np.percentile(lr[lr > 0.01], 95)


def viseme(k):
    o = min(1.0, lr[k] / (0.65 * p95))
    c = lc[k]
    if o < 0.13:
        return "X"
    if o < 0.30:
        return "A_MBP" if c < 1300 else "B_SSH"
    if c > 3400:
        return "B_SSH"
    if c > 2300:
        return "EE_wide" if o > 0.55 else "C_E"
    if c < 1050:
        return "E_O" if o > 0.5 else "F_OO"
    if 1600 < c < 2000 and o < 0.5:
        return "H_L"
    return "D_AA" if o > 0.72 else "C_E"


vis = [viseme(k) for k in range(N)]
# min hold 2 frames + fill single-frame blips
for k in range(1, N - 1):
    if vis[k] != vis[k - 1] and vis[k] != vis[k + 1]:
        vis[k] = vis[k - 1]
json.dump(vis, open(BUILD / "visemes.json", "w"))

# =============================================================== layers on R3a (graded like the style test)
base = cv2.imread(str(MASCOT / "renders_vahid" / "R3a.jpg"))[:, :, ::-1].astype(np.float32)
H0, W0p = base.shape[:2]
G = dict(R=56, eyeL=(545, 800), eyeR=(662, 802), browL=(541, 714), browR=(654, 717), mouth=(612, 886), ms=1.15)
GRADE = np.array((0.85, 0.83, 0.86))
NAVY_L = 0.299 * 0x1B + 0.587 * 0x2A + 0.114 * 0x4A
LOCAL = cv2.GaussianBlur(base, (0, 0), 22)


def render_svg(inner):
    p = BUILD / "_lay.png"
    html_to_png("<!doctype html><style>html,body{margin:0;background:transparent}</style>" + K.svg_doc(inner, W0p, H0, (0, 0, W0p, H0)), p, W0p, H0)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def grade(lay, seed=1):
    rgb, a = lay[..., :3].copy(), lay[..., 3]
    lum = rgb @ np.array([0.299, 0.587, 0.114])
    nv = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] + 8) & (lum < 150)).astype(np.float32), (0, 0), 0.8)[..., None]
    ratio = np.clip(lum / NAVY_L, 0.45, 1.30)[..., None]
    rgb = rgb * (1 - nv) + np.clip(LOCAL * ratio, 0, 255) * nv
    rgb = cv2.GaussianBlur(rgb * GRADE, (0, 0), 0.7) + np.random.default_rng(seed).normal(0, 2.2, rgb.shape[:2])[..., None]
    return np.dstack([np.clip(rgb, 0, 255), cv2.GaussianBlur(a, (0, 0), 0.6)])


def face_inner(ex, look=None, closed=False, mouth=None):
    saved = copy.deepcopy(K.EXPR[ex]); e = K.EXPR[ex]
    for side in ("eyeL", "eyeR"):
        if e[side] != "happy":
            l = list(e[side])
            if look is not None:
                l[3] = look
            if closed:
                l[0], l[2] = 0.97, 0.0
            e[side] = tuple(l)
    e["mouth"] = mouth if mouth else ("none", False)
    R = G["R"]; u = lambda p: (p[0] / R, p[1] / R)
    inner = K.face(R, ex, eyeL=u(G["eyeL"]), eyeR=u(G["eyeR"]), browL=u(G["browL"]), browR=u(G["browR"]), mouthc=u(G["mouth"]), mscale=G["ms"])
    K.EXPR[ex] = saved
    return inner


S = 1080 / W0p
HS = round(H0 * S)  # 1620
PAD_T = (1920 - HS) // 2


def scale_rgba(a):
    return np.clip(cv2.resize(a, (1080, HS), interpolation=cv2.INTER_AREA), 0, 255).astype(np.uint8)


cache = BUILD / "layers.npz"
FACES = {"E01cam": ("E01", (0.12, 0.04)), "E01book": ("E01", (-0.22, 0.26)), "E08": ("E08", (-0.25, 0.28)),
         "E03": ("E03", (0.30, -0.28)), "E05": ("E05", (-0.30, 0.22)), "E10": ("E10", (0.05, 0.05))}
if cache.exists():
    L = dict(np.load(cache))
else:
    L = {}
    for k, (ex, look) in FACES.items():
        L[f"face_{k}"] = scale_rgba(grade(render_svg(face_inner(ex, look))))
        L[f"blink_{k}"] = scale_rgba(grade(render_svg(face_inner(ex, look, closed=True))))
    R = G["R"]
    for m in K.MOUTHS:
        for fr in (False, True):
            inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth(R, m, fr, G["ms"])}</g>'
            L[f"m_{m}_{int(fr)}"] = scale_rgba(grade(render_svg(inner), 3))
    for kind in ("smile_soft", "smirk_wide", "hmm", "purse"):
        inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth_for_expr(R, (kind, kind == "purse"), G["ms"])}</g>'
        L[f"rest_{kind}"] = scale_rgba(grade(render_svg(inner), 3))
    np.savez(cache, **L)
BASE = cv2.resize(base, (1080, HS), interpolation=cv2.INTER_AREA)
LOCAL_S = cv2.GaussianBlur(BASE, (0, 0), 18)


def over(img, rgba):
    rgba = rgba.astype(np.float32)
    a = rgba[..., 3:] / 255
    return img * (1 - a) + rgba[..., :3] * a


# padded plate background (same method as the Flow start frame)
def pad_canvas(small):
    out = np.zeros((1920, 1080, 3), np.float32)
    out[PAD_T:PAD_T + HS] = small
    def ext(up, n):
        band = (small[:120] if up else small[-120:])[::-1]
        rep = np.concatenate([band] * (n // 120 + 2), 0)[:n]
        rep = cv2.GaussianBlur(rep, (0, 0), 28) * np.linspace(1.0, 0.82, n)[:, None, None]
        return rep[::-1] if up else rep
    out[:PAD_T] = ext(True, PAD_T)
    out[PAD_T + HS:] = ext(False, 1920 - PAD_T - HS)
    bl = cv2.GaussianBlur(out, (0, 0), 8)
    ys = np.arange(1920)[:, None, None]
    w = np.zeros((1920, 1, 1), np.float32)
    for y0 in (PAD_T, PAD_T + HS):
        w = np.maximum(w, np.clip(1 - np.abs(ys - y0) / 36.0, 0, 1))
    return out * (1 - w) + bl * w


PAD_BG = pad_canvas(BASE)   # static padding (only the inner 1620 band changes per frame)

# halo ring mask for Peleh's presence pulse
yy, xx = np.mgrid[0:HS, 0:1080].astype(np.float32)
cx, cy, rr = 670 * S, 760 * S, 435 * S
d = np.abs(np.hypot(xx - cx, yy - cy) - rr)
warm = (BASE[..., 0] > 150) & (BASE[..., 0] > BASE[..., 2] + 20)
ring = cv2.GaussianBlur(((d < 26) & warm).astype(np.float32), (0, 0), 10)
ring = ring / (ring.max() + 1e-6)

# gold step-1 mask (scaled from ep1_gold.py)
P1 = np.array([(480, 618), (496, 598), (688, 576), (698, 584), (826, 606), (832, 732), (700, 740), (700, 1010), (478, 1010)], np.float32) * S
sm = np.zeros((HS, 1080), np.uint8); cv2.fillPoly(sm, [P1.astype(np.int32)], 255)
cv2.circle(sm, (int(662 * S), int(802 * S)), int(64 * S), 255, -1)
STEP = cv2.GaussianBlur(sm.astype(np.float32) / 255, (0, 0), 1.0) * np.clip((1010 * S - yy) / (90 * S), 0, 1)
BP = np.array([(455, 600), (700, 565), (1060, 930), (1060, 1180), (455, 1180)], np.float32) * S
bm = np.zeros((HS, 1080), np.uint8); cv2.fillPoly(bm, [BP.astype(np.int32)], 255)
BODY = cv2.GaussianBlur(bm.astype(np.float32) / 255, (0, 0), 8)

# =============================================================== Flow clip frames (page turn)
FLOW_IN = 4.55
flow_len = T_14 - T_FLOW
raw = subprocess.run([FF, "-v", "quiet", "-ss", str(FLOW_IN), "-t", f"{flow_len + 0.2:.3f}", "-i", str(EP / "flow" / "ep1_flow_pageturn.mp4"),
                      "-vf", "fps=30,scale=1080:1920:flags=lanczos", "-an", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
FLOW = np.frombuffer(raw, np.uint8).reshape(-1, 1920, 1080, 3)
print("flow frames", len(FLOW))

# =============================================================== text overlays (Edge, Vazirmatn)
CSS = (f"@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}"
       "html,body{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}"
       "body{font-family:Vaz;direction:rtl}")


def overlay(name, body):
    p = BUILD / f"ov_{name}.png"
    if not p.exists():
        html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style>{body}", p, 1080, 1920)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def sub(txt, who):
    col = CREAM if who == "L" else GOLD
    return (f"<div style='position:absolute;left:50px;right:50px;top:1432px;text-align:center'>"
            f"<span style='display:inline-block;background:rgba(14,22,40,.72);border-radius:22px;padding:10px 30px;"
            f"font-size:58px;font-weight:700;line-height:1.35;color:{col}'>{txt}</span></div>")


OV = {
    "hook": overlay("hook", f"<div style='position:absolute;left:60px;right:60px;top:210px;text-align:center'>"
                            f"<div style='display:inline-block;background:rgba(14,22,40,.80);border:2px solid rgba(201,162,39,.55);border-radius:28px;padding:22px 36px;"
                            f"font-size:66px;font-weight:800;line-height:1.45;color:{CREAM}'>سه ماهه کتابم رو<br>صفحه‌ی <span style='color:{GOLD}'>دوازده</span> مونده.</div></div>"),
    "L1b": overlay("L1b", sub("ولی نشونه‌ش… خیلی قشنگه.", "L")),
    "P1": overlay("P1", sub("قشنگه. صفحه‌ی سیزده چطوره؟", "P")),
    "L2": overlay("L2", sub("سیزده… نحسه.", "L")),
    "P2": overlay("P2", sub("فقط یه صفحه. نحسیش با من.", "P")),
    "L3a": overlay("L3a", sub("یه صفحه که حساب نمی‌شه…", "L")),
    "L3b1": overlay("L3b1", sub("خب…", "L")),
    "L3b2": overlay("L3b2", sub("چهارده‌م خوندم.", "L")),
}
ICON = (W0 / "app_ref" / "icon-512.png").as_uri()
endp = BUILD / "ov_end.png"
if not endp.exists():
    html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS} body{{background:radial-gradient(120% 80% at 50% 35%,#24345C,{NAVY} 60%,#111A31)}}</style>"
                f"<div style='position:absolute;top:640px;width:100%;text-align:center;color:{CREAM};font-size:92px;font-weight:800'>بهانه‌ی خودت چیه؟</div>"
                f"<div style='position:absolute;top:800px;width:100%;text-align:center;color:{GOLD};font-size:44px;font-weight:600'>بنویس، شاید قسمت بعدی مال تو باشه.</div>"
                f"<div style='position:absolute;top:900px;left:470px;width:140px;height:4px;background:{GOLD};border-radius:2px'></div>"
                f"<div style='position:absolute;top:1010px;left:465px;width:150px;height:150px;border-radius:34px;overflow:hidden;box-shadow:0 0 0 3px {GOLD}'><img src='{ICON}' style='width:100%;height:100%'></div>"
                f"<div style='position:absolute;top:1180px;width:100%;text-align:center;color:{CREAM};font-size:50px;font-weight:800'>پله</div>",
                endp, 1080, 1920, transparent=False)
END = np.asarray(Image.open(endp).convert("RGB")).astype(np.float32)

# =============================================================== timeline
def state(t):
    """-> (kind, face, mouth_set_frown, rest_mouth, subtitle)"""
    in_seg = lambda n: segs[n][0] - 0.05 <= t < segs[n][1] + 0.05
    if t < segs["L1"][1] + 0.1:
        return "talk", ("E01cam" if t < T_L1b - 0.1 else "E01book"), 0, "X_rest", ("hook" if t < 2.6 else ("L1b" if t >= T_L1b - 0.05 else None))
    if t < segs["P1"][1] + 0.1:
        return "listen", "E08", 0, "rest_smile_soft", "P1"
    if t < segs["L2"][1] + 0.12:
        return "talk", "E03", 0, "rest_hmm", "L2"
    if t < segs["P2"][1] + 0.1:
        return "listen", "E08", 0, "rest_smile_soft", "P2"
    if t < T_FLOW:
        return "talk", "E05", 1, "rest_purse", "L3a"
    if t < T_14:
        return "flow", None, 0, None, "L3b1"
    if t < T_END:
        return "talk", "E10", 0, "rest_smirk_wide", "L3b2"
    return "end", None, 0, None, None


GOLDV = np.array([0xC9, 0xA2, 0x27], np.float32)
_er = cv2.erode((STEP > 0.5).astype(np.uint8), np.ones((15, 15), np.uint8)).astype(np.float32)
RIM = np.clip(cv2.GaussianBlur((STEP > 0.5).astype(np.float32) - _er, (0, 0), 3) * 1.6, 0, 1)
ys_ = np.nonzero(STEP > 0.5)[0]
xs_all = np.nonzero(STEP > 0.5)[1]
RIM = RIM * cv2.GaussianBlur(((yy < ys_.min() + 45) | (xx < xs_all.min() + 22)).astype(np.float32), (0, 0), 6)   # silhouette edges only
GRAD = np.clip((ys_.max() - yy) / (ys_.max() - ys_.min()), 0, 1)       # 1 at the top of the wall -> 0 at the bottom
_soft = cv2.GaussianBlur(STEP, (0, 0), 14)          # feathered (the step-1/2 split on the flat front is not a hard edge)
GLAZE_W = np.clip(_soft * (0.38 + 0.42 * GRAD) + RIM * 0.40, 0, 0.92)[..., None]
GLOW = cv2.GaussianBlur(STEP, (0, 0), 0.4 * 160 * S)[..., None]


def glaze_amount(dt):
    x = np.clip(dt / 0.6, 0, 1)
    return 1 - (1 - x) ** 3                                              # monotonic, no dip


def glaze(img, dt):
    a = glaze_amount(dt)
    lum = (img @ np.array([0.299, 0.587, 0.114], np.float32))[..., None]
    gold_col = np.clip(GOLDV / 159.6 * lum * 1.85 * np.array([1.18, 0.96, 0.62], np.float32), 0, 255)             # gold hue, clay luminance/texture kept
    s = GLAZE_W * 0.62 * a                                               # ~0.5-0.65 on the wall at peak
    out = img * (1 - s) + gold_col * s
    peak = np.exp(-((dt - 0.45) / 0.22) ** 2)
    g = GLOW * (0.10 * a + 0.22 * peak)
    out = 255 - (255 - out) * (1 - g * GOLDV / 255)
    if 0.15 < dt < 1.4:                                                  # 4 small rising specks
        rng = np.random.default_rng(5)
        xs_ = np.nonzero(STEP[int(ys_.min()) + 5] > 0.5)[0]
        lay = np.zeros(img.shape[:2], np.float32)
        for i in range(4):
            q = (dt - 0.15 - i * 0.1) / 0.9
            if 0 < q < 1:
                x0 = rng.uniform(xs_.min() + 10, xs_.max() - 10)
                cv2.circle(lay, (int(x0 + 5 * np.sin(q * 6 + i)), int(ys_.min() + 8 - q * 110)), 3, float((1 - q) ** 0.7), -1, cv2.LINE_AA)
        lay = cv2.GaussianBlur(lay, (0, 0), 1.3) + cv2.GaussianBlur(lay, (0, 0), 5) * 1.4
        out = 255 - (255 - out) * (1 - np.clip(lay, 0, 1)[..., None] * (GOLDV + 40) / 255)
    return out


def warm_lids(rgba, a, glazed):
    """Lids / socket shading follow the glazed wall colour (60%), so no grey patch around the eyes; whites, pupils, brows, mouth untouched."""
    f = rgba.astype(np.float32).copy()
    rgb = f[..., :3]
    lum = rgb @ np.array([0.299, 0.587, 0.114], np.float32)
    nv = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] - 6) & (lum < 165) & (np.abs(rgb[..., 0] - rgb[..., 1]) < 60)).astype(np.float32), (0, 0), 0.8)
    nv = (nv * cv2.GaussianBlur(STEP, (0, 0), 14))[..., None]
    localg = cv2.GaussianBlur(glazed, (0, 0), 18)
    ratio = np.clip(lum / NAVY_L, 0.45, 1.30)[..., None] / np.clip((LOCAL_S @ np.array([0.299, 0.587, 0.114], np.float32))[..., None] / NAVY_L, 0.5, 3)
    tgt = np.clip(localg * np.clip(ratio, 0.4, 1.4), 0, 255)
    k = nv * 0.6 * a
    f[..., :3] = rgb * (1 - k) + tgt * k
    return f


def zoom(img, t):
    z = 1.0 + 0.03 * min(t, T_END) / T_END
    h, w = img.shape[:2]
    ch, cw = int(h / z), int(w / z)
    y0, x0 = int((h - ch) * 0.42), (w - cw) // 2
    return cv2.resize(img[y0:y0 + ch, x0:x0 + cw], (w, h), interpolation=cv2.INTER_LINEAR)


blink_frames = set()
for bt in np.arange(1.7, DUR, 3.1):
    for k in range(3):
        blink_frames.add(int(bt * FPS) + k)

enc = subprocess.Popen([FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", str(BUILD / "video.mp4")], stdin=subprocess.PIPE)
check_times = {}
prev = None
for k in range(N):
    t = k / FPS
    kind, face, frown, rest, subk = state(t)
    if kind == "end":
        a = min(1.0, (t - T_END) / 0.3)
        img = END * a + (prev if prev is not None else END) * (1 - a)
    elif kind == "flow":
        fi = min(len(FLOW) - 1, int((t - T_FLOW) * FPS))
        img = zoom(FLOW[fi].astype(np.float32), t)
    else:
        inner = BASE.copy()
        if t >= T_GOLD:
            inner = glaze(inner, t - T_GOLD)
        fkey = ("blink_" if (k in blink_frames and face not in ("E04",)) else "face_") + face
        flay = warm_lids(L[fkey], glaze_amount(t - T_GOLD), inner) if t >= T_GOLD else L[fkey]
        inner = over(inner, flay)
        v = vis[k]
        if kind == "listen" or v == "X":
            inner = over(inner, L[rest] if rest.startswith("rest_") else L[f"m_X_rest_{frown}"])
        else:
            inner = over(inner, L[f"m_{v}_{frown}"])
        if kind == "listen":                                  # Peleh's presence: soft halo pulse
            name = "P1" if t < segs["L2"][0] else "P2"
            a0, a1 = segs[name][0], segs[name][1]
            env = np.clip(min(t - a0 + 0.3, a1 + 0.3 - t) / 0.4, 0, 1)
            pulse = env * (0.55 + 0.45 * np.sin(2 * np.pi * (t - a0) / 1.3))
            inner = 255 - (255 - inner) * (1 - ring[..., None] * pulse * 0.55 * np.array([1.0, 0.85, 0.45]))
        img = PAD_BG.copy()
        img[PAD_T:PAD_T + HS] = inner
        img = zoom(img, t)
        prev = img
    if subk:
        ov = OV[subk]
        if subk == "hook":
            a = np.clip(min(t / 0.15 if t > 0 else 1, (2.6 - t) / 0.3), 0, 1)
            ov = ov.copy(); ov[..., 3] *= a
        img = over(img, ov)
    img8 = np.clip(img, 0, 255).astype(np.uint8)
    enc.stdin.write(img8.tobytes())
    for ct in (0.5, 2.0, T_L1b + 0.5, segs["P1"][0] + 1.0, segs["L2"][0] + 0.6, segs["P2"][0] + 1.0, segs["L3a"][0] + 0.6,
               T_FLOW + 0.3, T_FLOW + 0.9, T_14 + 0.1, T_GOLD + 0.2, T_GOLD + 0.45, T_GOLD + 1.0, T_END + 1.0):
        if abs(t - ct) < 0.5 / FPS:
            check_times[round(t, 2)] = img8.copy()
enc.stdin.close(); enc.wait()

# =============================================================== audio mix
mus = load(W0 / "reel_d010" / "music_leberch_reading.mp3")
mus = mus[int(2.0 * SR):int(2.0 * SR) + NS]
mus = np.pad(mus, (0, max(0, NS - len(mus))))
voice = lam_tr + pel_tr
act = np.convolve((np.abs(voice) > 0.01).astype(np.float32), np.ones(int(0.25 * SR)) / int(0.25 * SR), "same") > 0.02
duck = np.where(act, 0.10, 0.22).astype(np.float32)
duck = np.convolve(duck, np.ones(int(0.3 * SR)) / int(0.3 * SR), "same")
tt = np.arange(NS) / SR
duck *= np.clip(tt / 0.6, 0, 1) * np.clip((DUR - tt) / 0.8, 0, 1)
mix = voice * 1.0 + mus * duck
# page flip SFX (under the Flow page turn) + ding (gold step)
pt = load(W0 / "audio" / "page_turn.wav")
pt = pt[:int(1.4 * SR)] * np.linspace(1, 0.0, int(1.4 * SR)) ** 0.5
i = int((T_FLOW + 0.35) * SR); mix[i:i + len(pt)] += pt[:max(0, min(len(pt), NS - i))] * 0.55
ding_wav(BUILD / "ding.wav", at=0.0, total=2.0, sr=SR)
dg = load(BUILD / "ding.wav")
i = int((T_GOLD + 0.09) * SR); mix[i:i + len(dg)] += dg[:max(0, min(len(dg), NS - i))] * 0.9
mix = mix[:int(DUR * SR)]
mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
with wave.open(str(BUILD / "mix.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((mix * 32767).astype(np.int16).tobytes())
def lufs(path):
    e = subprocess.run([FF, "-hide_banner", "-i", str(path), "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    s = e[e.rindex("Summary:"):]
    I = float(s.split("I:")[1].split("LUFS")[0])
    tp = float(s.split("Peak:")[1].split("dBFS")[0])
    return I, tp


I0, _ = lufs(BUILD / "mix.wav")
gain = -15.0 - I0
for it in range(3):
    af = f"volume={gain:.2f}dB,alimiter=limit=0.84:attack=3:release=60:level=false,aresample=48000"
    subprocess.run([FF, "-y", "-v", "error", "-i", str(BUILD / "mix.wav"), "-af", af, "-ac", "2", str(BUILD / "mix_norm.wav")], check=True)
    I1, tp1 = lufs(BUILD / "mix_norm.wav")
    if abs(I1 + 15) < 0.3:
        break
    gain += -15.0 - I1
js = {"input_I": I0, "gain_dB": gain, "out_I": I1, "out_TP": tp1}
out = EP / "lam_ep1_final.mp4"
subprocess.run([FF, "-y", "-v", "error", "-i", str(BUILD / "video.mp4"), "-i", str(BUILD / "mix_norm.wav"), "-c:v", "copy",
                "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", str(out)], check=True)
print("loudness", js)

# =============================================================== check sheet
ks = sorted(check_times)
th = [cv2.resize(check_times[k], (270, 480), interpolation=cv2.INTER_AREA) for k in ks]
cols = 7
rows = (len(th) + cols - 1) // cols
sheet = np.full((rows * 520, cols * 280, 3), 20, np.uint8)
for i, (k, im) in enumerate(zip(ks, th)):
    x, y = (i % cols) * 280 + 5, (i // cols) * 520 + 5
    sheet[y:y + 480, x:x + 270] = im
    cv2.putText(sheet, f"{k:.2f}s", (x + 4, y + 505), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (243, 240, 232), 2, cv2.LINE_AA)
Image.fromarray(sheet).save(EP / "check_sheet_ep1.jpg", quality=90)
json.dump({"segments": {k: [round(v[0], 3), round(v[1], 3)] for k, v in segs.items()}, "T_L1b": T_L1b, "T_FLOW": T_FLOW, "T_14": T_14,
           "T_GOLD": T_GOLD, "T_END": T_END, "DUR": DUR, "loudness": js}, open(EP / "lam_ep1_timeline.json", "w"), indent=1)
print("done", out, DUR)
