"""«بهانه‌های لَم» episode 3 «از یه روز تمیز» (2026-11-12).
Two talking plates with the face kit (A: phone pose = Vahid's still · B: book pose = last frame of his Flow clip),
the Flow clip in between (Lam silent), syllable-timed lip-sync, acting that follows each line:
  L1 «چالش؟ از شنبه.»                 bored, one brow flicks up on «چالش؟»
  P1 «چرا شنبه؟»                       glance up toward the voice
  L2 «آدم باید… از یه روز تمیز…»       lids low, chin-up professor, brows lifted
  P2 «اول ماه بود. دیروز.»             eyes slide to the calendar, widen on «دیروز» (gold circle on «۱ آذر»)
  (beat)                               eyes dart left/right, forced grin
  L3 «…پس از سال دیگه. با یه دفتر نو!» smug, brows up, counter jumps «۵ روز» → «۳۶۴ روز 😐»
  P3 «یه صفحه، لَم.»                   → Flow clip: sigh, phone down, book, reading
  L4 «اِ… همین بود؟» (plate B)          wide surprised eyes, brows up
  P4 «همین.»                           blink, eyes drop to the book
  L5 «…یکی دیگه.»                      mischievous smirk · tick «روز ۱ ✅» · CTA
Output: ep3/lam_ep3_final.mp4 (+ _upload), ep3/_build/check_*.jpg, ep3/lam_ep3_timeline.json
"""
from pathlib import Path
import copy, json, subprocess, wave
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
import lam_facekit as K
from render_util import html_to_png, FONT
from gold_step import ding_wav

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
W0 = MASCOT.parent
EP = MASCOT / "ep3"
B = EP / "_build"
B.mkdir(exist_ok=True)
FF = imageio_ffmpeg.get_ffmpeg_exe()
FPS, SR = 30, 44100
GOLD, CREAM = "#C9A227", "#F3F0E8"
TEMPO = 1.05
TARGET_I = -14.0


# =============================================================== audio
def load(p, sr=SR):
    raw = subprocess.run([FF, "-v", "quiet", "-i", str(p), "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768


def fade(x, ms=15):
    n = int(SR * ms / 1000); x = x.copy()
    x[:n] *= np.linspace(0, 1, n); x[-n:] *= np.linspace(1, 0, n)
    return x


def tempo(y, f):
    out = subprocess.run([FF, "-v", "quiet", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "-", "-af", f"atempo={f}", "-f", "f32le", "-"],
                         input=y.astype(np.float32).tobytes(), capture_output=True).stdout
    return np.frombuffer(out, np.float32).copy()


lam = load(EP / "lam_ep3_lam.mp3")
pel = load(EP / "lam_ep3_peleh.mp3")
# (key, speaker, src start, src end, gap before) — the take reads the labels «L1/P1…» aloud: those are skipped.
ITEMS = [("L1", "L", 1.15, 3.42, 0.12),
         ("P1", "P", 1.26, 2.45, 0.10),
         ("L2", "L", 4.94, 9.32, 0.10),
         ("P2", "P", 3.89, 6.36, 0.10),
         ("L3", "L", 11.40, 14.12, 0.55),      # 0.55 s silent eye-dart beat before «پس…»
         ("P3", "P", 7.90, 9.44, 0.14),
         ("L4", "L", 15.65, 17.24, None),     # placed after the clip
         ("P4", "P", 11.15, 11.68, 0.10),
         ("L5", "L", 18.86, 20.16, 0.14)]
CUTS = {"L2": [(6.52, 6.62)], "P2": [(5.30, 5.42)], "L4": [(16.14, 16.26)]}   # keep the comic pauses, just tighter
XF = int(0.012 * SR)
CLIP_LEN = 5.2           # Flow clip (6.04 s) played a little faster


def cut_take(src, key, a, b):
    pieces, p0 = [], a
    for c0, c1 in CUTS.get(key, []) + [(b, b)]:
        pieces.append(src[int(p0 * SR):int(c0 * SR)].copy()); p0 = c1
    y0 = pieces[0]
    for pc in pieces[1:]:
        if len(pc) == 0:
            continue
        r = np.linspace(0, 1, XF, dtype=np.float32)
        y0 = np.concatenate([y0[:-XF], y0[-XF:] * (1 - r) + pc[:XF] * r, pc[XF:]])
    return fade(tempo(fade(y0), TEMPO))


segs, t = {}, 0.0
for key, spk, a, b, gap in ITEMS:
    y = cut_take(lam if spk == "L" else pel, key, a, b)
    if key == "L4":
        t = segs["P3"][0] - 0.10 + CLIP_LEN + 0.15
    else:
        t += gap
    segs[key] = (t, t + len(y) / SR, y, spk, a)
    t += len(y) / SR
S_ = lambda k: segs[k][0]
E_ = lambda k: segs[k][1]


def to_out(key, ts):
    rm = 0.0
    for c0, c1 in CUTS.get(key, []):
        if ts >= c1:
            rm += c1 - c0
        elif ts > c0:
            rm += ts - c0
    return segs[key][0] + (ts - segs[key][4] - rm) / TEMPO


T_CLIP = S_("P3") - 0.10
T_B = T_CLIP + CLIP_LEN
T_CTA = E_("L5") + 0.35
TAIL = 2.4
DUR = E_("L5") + TAIL
N = int(round(DUR * FPS)); NS = int(DUR * SR) + SR
lam_tr, pel_tr = np.zeros(NS, np.float32), np.zeros(NS, np.float32)
for key, (a, b, y, spk, _) in segs.items():
    tr = lam_tr if spk == "L" else pel_tr
    i = int(a * SR); tr[i:i + len(y)] += y[:max(0, min(len(y), NS - i))]
print({k: (round(v[0], 2), round(v[1], 2)) for k, v in segs.items()}, "clip", round(T_CLIP, 2), round(T_B, 2), "DUR", round(DUR, 2))

# =============================================================== syllable-timed visemes
# Voiced runs of the Lam take (source seconds, 10 ms energy map, peak-35 dB) and their syllables:
# syllable = (onset viseme | None, vowel viseme, coda viseme | None)
M, T, L_, FV = "A_MBP", "B_SSH", "H_L", "G_FV"
AA, E, I, U, O = "D_AA", "C_E", "EE_wide", "F_OO", "E_O"
RUNS = {
    "L1": [((1.21, 2.29), [(T, AA, None), (L_, E, T)]),                                    # چا لِش
           ((2.58, 3.37), [(None, E, T), (T, E, M), (M, E, None)])],                       # اَز شَم بِه
    "L2": [((5.00, 6.45), [(None, AA, None), (T, E, M), (M, AA, None), (T, E, T)]),         # آ دَم با یَد
           ((6.89, 9.26), [(None, E, T), (T, E, None), (L_, U, T), (T, E, None), (M, I, T),  # اَز یه روز تَ میز
                           (T, O, None), (L_, U, None), (T, O, None), (L_, E, None)])],      # شُ روع کُ نه
    "L3": [((11.46, 12.59), [(M, E, T), (None, E, T), (T, AA, L_), (T, I, None), (T, E, None)]),   # پَس اَز سال دی گه
           ((12.87, 14.05), [(M, AA, None), (T, E, None), (T, E, FV), (T, E, L_), (L_, U, None)])],  # با یه دَف تَر نو
    "L4": [((15.71, 16.07), [(None, E, None)]),                                               # اِ
           ((16.55, 17.17), [(None, E, None), (M, I, L_), (M, U, T)])],                       # هَ مین بود
    "L5": [((18.92, 20.10), [(T, E, None), (T, I, None), (T, I, None), (T, E, None)])],       # یِ کی دی گه
}
WEIGHT = {AA: 1.35, U: 1.3, I: 1.25, O: 1.1, E: 1.0}
vis = ["X"] * N


def put(t0, t1, v):
    k0, k1 = int(round(t0 * FPS)), int(round(t1 * FPS))
    for k in range(max(0, k0), min(N, max(k1, k0 + 2))):
        vis[k] = v


for key, runs in RUNS.items():
    for (a, b), syl in runs:
        w = np.array([WEIGHT[s[1]] + (0.35 if s[0] else 0) + (0.3 if s[2] else 0) for s in syl])
        edges = a + (b - a) * np.concatenate([[0], np.cumsum(w) / w.sum()])
        for (on, vw, co), s0, s1 in zip(syl, edges[:-1], edges[1:]):
            d = s1 - s0
            p0 = s0 + (0.24 * d if on else 0)
            p1 = s1 - (0.22 * d if co else 0)
            if on:
                put(to_out(key, s0), to_out(key, p0), on)
            put(to_out(key, p0), to_out(key, p1), vw)
            if co:
                put(to_out(key, p1), to_out(key, s1), co)
vis = vis[1:] + ["X"]          # lips lead the sound by one frame

# =============================================================== plates + kit layers (1116x2000 still space)
S = 1080 / 1116
HS = round(2000 * S)
CROP = (HS - 1920) // 2


def to1080(a):
    a = cv2.resize(a, (1080, HS), interpolation=cv2.INTER_AREA)
    return a[CROP:CROP + 1920]


PL = {
    "A": dict(img="lam_ep3_A_faceless.png",
              G=dict(R=48, eyeL=(540, 834), eyeR=(641, 837), browL=(543, 761), browR=(638, 757), mouth=(591, 908), ms=1.05)),
    "B": dict(img="lam_ep3_B_faceless.png",
              G=dict(R=86, eyeL=(503, 818), eyeR=(684, 818), browL=(499, 678), browR=(683, 672), mouth=(605, 960), ms=1.12)),
}
GRADE = np.array((0.86, 0.84, 0.88))
NAVY_L = 0.299 * 0x1B + 0.587 * 0x2A + 0.114 * 0x4A

# expressions: per eye (cover, tilt, lower, (lookx, looky), pupil scale, sparkle) | brows | mouth none (swapped for lip-sync)
X = lambda eL, eR, bL, bR: dict(eyeL=eL, eyeR=eR, browL=bL, browR=bR, mouth=("none", False))
K.EXPR.update({
    "e_bored":    X((0.50, -4, 0, (-0.30, 0.34), 1, False), (0.50, 4, 0, (-0.30, 0.34), 1, False), ("flat", 0.02), ("flat", 0.02)),
    "e_flick":    X((0.40, -4, 0, (-0.20, 0.20), 1, False), (0.30, 4, 0, (-0.20, 0.20), 1, False), ("flat", 0.02), ("up", -0.04)),
    "e_listen":   X((0.18, 0, 0, (0.30, -0.28), 1, False), (0.18, 0, 0, (0.30, -0.28), 1, False), ("soft", -0.04), ("up", -0.04)),
    "e_philo":    X((0.66, -3, 0, (0.10, -0.18), 1, False), (0.62, 3, 0, (0.10, -0.18), 1, False), ("up", -0.06), ("up", -0.14)),
    "e_philo2":   X((0.74, -3, 0, (0.06, -0.20), 1, False), (0.70, 3, 0, (0.06, -0.20), 1, False), ("up", -0.10), ("up", -0.16)),
    "e_side":     X((0.10, 0, 0, (-0.52, 0.02), 1, False), (0.10, 0, 0, (-0.52, 0.02), 1, False), ("flat", 0.0), ("soft", -0.02)),
    "e_wide":     X((0.00, 0, 0, (-0.50, 0.00), 0.84, False), (0.00, 0, 0, (-0.50, 0.00), 0.84, False), ("up", -0.10), ("up", -0.10)),
    "e_dartL":    X((0.06, 0, 0, (-0.55, 0.05), 0.9, False), (0.06, 0, 0, (-0.55, 0.05), 0.9, False), ("worried", 0.0), ("worried", 0.0)),
    "e_dartR":    X((0.06, 0, 0, (0.55, 0.05), 0.9, False), (0.06, 0, 0, (0.55, 0.05), 0.9, False), ("worried", 0.0), ("worried", 0.0)),
    "e_smug":     X((0.46, -4, 0, (0.10, 0.04), 1, False), (0.36, 4, 0, (0.10, 0.04), 1, False), ("base", 0.02), ("up", -0.12)),
    "e_smug_up":  X((0.40, -4, 0, (0.12, 0.00), 1, False), (0.30, 4, 0, (0.12, 0.00), 1, False), ("soft", -0.02), ("up", -0.16)),
    "e_surprise": X((0.00, 0, 0, (0.00, 0.06), 1.06, True), (0.00, 0, 0, (0.00, 0.06), 1.06, True), ("up", -0.10), ("up", -0.10)),
    "e_lookbook": X((0.30, 0, 0, (-0.15, 0.40), 1, False), (0.30, 0, 0, (-0.15, 0.40), 1, False), ("soft", 0.0), ("soft", 0.0)),
    "e_mischief": X((0.32, -3, 0, (0.10, 0.06), 1, False), (0.24, 3, 0, (0.10, 0.06), 1, False), ("soft", 0.04), ("up", -0.08)),
})
EXS = {"A": ["e_bored", "e_flick", "e_listen", "e_philo", "e_philo2", "e_side", "e_wide", "e_dartL", "e_dartR", "e_smug", "e_smug_up"],
       "B": ["e_surprise", "e_lookbook", "e_mischief"]}
RESTS = ["flat_down", "hmm", "forced", "smirk_wide", "o_small", "smile_soft"]


def render_svg(inner, name, W, H):
    p = B / f"_{name}.png"
    html_to_png("<!doctype html><style>html,body{margin:0;background:transparent}</style>" + K.svg_doc(inner, W, H, (0, 0, W, H)), p, W, H)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def build_layers(pk):
    P = PL[pk]; G = P["G"]
    plate0 = cv2.imread(str(EP / P["img"]))[:, :, ::-1].astype(np.float32)
    H0, W0p = plate0.shape[:2]
    LOCAL = cv2.GaussianBlur(plate0, (0, 0), 22)
    soft = 0.7 if pk == "A" else 1.4      # plate B is an upscaled video frame: match its softness

    def grade(lay, seed=1):
        rgb, a = lay[..., :3].copy(), lay[..., 3]
        lum = rgb @ np.array([0.299, 0.587, 0.114])
        nv = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] + 8) & (lum < 150)).astype(np.float32), (0, 0), 0.8)[..., None]
        ratio = np.clip(lum / NAVY_L, 0.45, 1.30)[..., None]
        rgb = rgb * (1 - nv) + np.clip(LOCAL * ratio, 0, 255) * nv
        rgb = cv2.GaussianBlur(rgb * GRADE, (0, 0), soft) + np.random.default_rng(seed).normal(0, 2.0, rgb.shape[:2])[..., None]
        return np.dstack([np.clip(rgb, 0, 255), cv2.GaussianBlur(a, (0, 0), soft * 0.85)])

    def face_inner(ex, closed=False):
        saved = copy.deepcopy(K.EXPR[ex]); e = K.EXPR[ex]
        if closed:
            for side in ("eyeL", "eyeR"):
                l = list(e[side]); l[0], l[2] = 0.97, 0.0; e[side] = tuple(l)
        R = G["R"]; u = lambda p: (p[0] / R, p[1] / R)
        inner = K.face(R, ex, eyeL=u(G["eyeL"]), eyeR=u(G["eyeR"]), browL=u(G["browL"]), browR=u(G["browR"]), mouthc=u(G["mouth"]), mscale=G["ms"])
        K.EXPR[ex] = saved
        return inner

    cache = B / f"layers_{pk}.npz"
    if cache.exists():
        Lr = dict(np.load(cache))
    else:
        Lr = {}
        for ex in EXS[pk]:
            Lr[f"face_{ex}"] = np.clip(to1080(grade(render_svg(face_inner(ex), f"{pk}_{ex}", W0p, H0))), 0, 255).astype(np.uint8)
            Lr[f"blink_{ex}"] = np.clip(to1080(grade(render_svg(face_inner(ex, True), f"{pk}_{ex}_b", W0p, H0))), 0, 255).astype(np.uint8)
        R = G["R"]
        for m in K.MOUTHS:
            inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth(R, m, False, G["ms"])}</g>'
            Lr[f"m_{m}"] = np.clip(to1080(grade(render_svg(inner, f"{pk}_m_{m}", W0p, H0), 3)), 0, 255).astype(np.uint8)
        for kind in RESTS:
            inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth_for_expr(R, (kind, False), G["ms"])}</g>'
            Lr[f"rest_{kind}"] = np.clip(to1080(grade(render_svg(inner, f"{pk}_r_{kind}", W0p, H0), 3)), 0, 255).astype(np.uint8)
        np.savez(cache, **Lr)
    return to1080(plate0), Lr


PLATE_A, LA = build_layers("A")
PLATE_B, LB = build_layers("B")


def over(img, rgba, a=1.0):
    rgba = rgba.astype(np.float32); al = rgba[..., 3:] / 255 * a
    return img * (1 - al) + rgba[..., :3] * al


# warm ring light on plate A (excluding the desk lamp) — breathes while Peleh speaks
warm = ((PLATE_A[..., 0] > 150) & (PLATE_A[..., 0] > PLATE_A[..., 2] + 25)).astype(np.float32)
warm[:700, :330] = 0
RING = cv2.GaussianBlur(warm, (0, 0), 9); RING /= RING.max() + 1e-6

# =============================================================== acting
s_word = lambda key, ts: to_out(key, ts)
P2_DAY = to_out("P2", 5.62)          # «دیروز»


def act(t):
    """(plate, expression, rest mouth) at time t (talking plates only)."""
    if t < s_word("L1", 2.40):
        return "A", ("e_flick" if t < s_word("L1", 2.05) else "e_bored"), "flat_down"
    if t < S_("P1") - 0.05:
        return "A", "e_bored", "flat_down"
    if t < E_("P1") + 0.10:
        return "A", "e_listen", "hmm"
    if t < E_("L2") + 0.15:
        return "A", ("e_philo2" if t > s_word("L2", 7.45) else "e_philo"), "smile_soft"
    if t < P2_DAY - 0.05:
        return "A", "e_side", "hmm"
    if t < E_("P2") + 0.12:
        return "A", "e_wide", "forced"
    if t < S_("L3") - 0.02:                                   # eye-dart beat
        u = (t - E_("P2") - 0.12) / max(0.05, S_("L3") - E_("P2") - 0.14)
        return "A", ("e_dartL" if u < 0.35 else "e_dartR" if u < 0.75 else "e_smug"), "forced"
    if t < T_CLIP:
        return "A", ("e_smug_up" if t > s_word("L3", 12.85) else "e_smug"), "smirk_wide"
    # plate B
    if t < E_("L4") + 0.12:
        return "B", "e_surprise", "o_small"
    if t < S_("L5") - 0.05:
        return "B", "e_lookbook", "o_small"
    return "B", "e_mischief", "smirk_wide"


BLINKS = [1.0, S_("P1") + 0.55, S_("P2") + 0.25, S_("L3") + 1.1, T_B + 0.25, S_("P4") + 0.15, T_CTA + 1.2]
blink_frames = {int(bt * FPS) + i for bt in BLINKS for i in range(3)}


def face_frame(k, t):
    pk, ex, rest = act(t)
    plate, Lr = (PLATE_A, LA) if pk == "A" else (PLATE_B, LB)
    img = over(plate, Lr[("blink_" if k in blink_frames else "face_") + ex])
    v = vis[k]
    img = over(img, Lr[f"rest_{rest}"] if v == "X" else Lr[f"m_{v}"])
    if pk == "A":
        for key in ("P1", "P2"):
            a0, a1 = S_(key), E_(key)
            if a0 - 0.25 <= t <= a1 + 0.3:
                env = np.clip(min(t - a0 + 0.25, a1 + 0.3 - t) / 0.4, 0, 1)
                pulse = env * (0.55 + 0.45 * np.sin(2 * np.pi * (t - a0) / 1.3))
                img = 255 - (255 - img) * (1 - RING[..., None] * pulse * 0.5 * np.array([1.0, 0.85, 0.45]))
    return img, pk


# =============================================================== Flow clip (Lam silent)
raw = subprocess.run([FF, "-v", "quiet", "-i", str(EP / "lam_ep3_flow_clip.mp4"), "-vf", "fps=30,scale=1080:1920:flags=lanczos",
                      "-an", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
CLIP = np.frombuffer(raw, np.uint8).reshape(-1, 1920, 1080, 3)
CN = len(CLIP)


def clip_frame(t):
    if T_CLIP <= t < T_B:
        u = (t - T_CLIP) / CLIP_LEN
        return CLIP[min(CN - 1, int(u * (CN - 1)))].astype(np.float32)
    return None


def cam(img, z, fx, fy):
    cw, ch = 1080 / z, 1920 / z
    x0 = float(np.clip(fx - cw / 2, 0, 1080 - cw)); y0 = float(np.clip(fy - ch / 2, 0, 1920 - ch))
    Mx = np.float32([[z, 0, -x0 * z], [0, z, -y0 * z]])
    out = cv2.warpAffine(img, Mx, (1080, 1920), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
    if z > 1.25:
        out = out + 0.3 * (out - cv2.GaussianBlur(out, (0, 0), 1.2))
    return out


FACE_A = (590 * S, 860 * S - CROP)
SHOTS = [(0.0, S_("P1") - 0.05, 1.00, 1.06, 560, 960),                         # wide: «از شنبه»
         (S_("P1") - 0.05, S_("P2") - 0.06, 1.45, 1.52, FACE_A[0], FACE_A[1]),  # close: the professor
         (S_("P2") - 0.06, S_("L3") - 0.04, 1.12, 1.16, 470, 900),             # medium with the calendar
         (S_("L3") - 0.04, T_CLIP, 1.55, 1.70, FACE_A[0], FACE_A[1])]          # punch-in: «با یه دفتر نو!»
SHOT_B = (T_B, DUR, 1.00, 1.05, 540, 900)

hop = SR // FPS
lr = np.array([np.sqrt((lam_tr[k * hop:(k + 1) * hop] ** 2).mean() + 1e-12) for k in range(N)])
lr = np.convolve(lr, np.ones(4) / 4, "same"); BOB = np.clip(lr / (np.percentile(lr[lr > 0.005], 95) + 1e-6), 0, 1)

# =============================================================== overlays
CSS = (f"@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}"
       "html,body{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}body{font-family:Vaz;direction:rtl}")


def ov(name, body):
    p = B / f"ov_{name}.png"
    html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style>{body}", p, 1080, 1920)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def sub(text, color):
    return (f"<div style='position:absolute;left:50px;right:50px;top:1430px;text-align:center'><span style='display:inline-block;"
            f"background:rgba(14,22,40,.74);border-radius:22px;padding:10px 30px;font-size:56px;font-weight:700;line-height:1.35;color:{color}'>{text}</span></div>")


def pill(text):
    return (f"<div style='position:absolute;left:0;right:0;top:300px;text-align:center'><div style='display:inline-block;"
            f"background:{GOLD};border-radius:999px;padding:14px 40px;font-size:62px;font-weight:900;color:#1B2A4A;"
            f"box-shadow:0 10px 40px rgba(0,0,0,.45)'>{text}</div></div>")


ICON = (W0 / "app_ref" / "icon-512.png").as_uri()
CAL = (int(90 * S), int(796 * S) - CROP)          # a cell in the first date row of the wall calendar (plate space, before camera)
OV = {
    "label": ov("label", f"<div style='position:absolute;right:46px;top:200px;background:rgba(14,22,40,.72);border:2px solid rgba(201,162,39,.7);"
                         f"border-radius:20px;padding:6px 20px;font-size:36px;font-weight:800;color:{CREAM}'>لَم · <span style='color:{GOLD}'>قسمت ۳</span></div>"),
    "hook": ov("hook", f"<div style='position:absolute;left:60px;right:60px;top:300px;text-align:center'><div style='display:inline-block;"
                       f"background:rgba(14,22,40,.84);border:2px solid rgba(201,162,39,.6);border-radius:28px;padding:20px 44px;font-size:80px;"
                       f"font-weight:800;color:{CREAM}'>از <span style='color:{GOLD}'>شنبه</span> شروع می‌کنم.</div></div>"),
    "c5": ov("c5", pill("📅 ۵ روز دیگه")),
    "c364": ov("c364", pill("📅 ۳۶۴ روز دیگه 😐")),
    "cal": ov("cal", f"<div style='position:absolute;left:{CAL[0] - 30}px;top:{CAL[1] - 30}px;width:60px;height:60px;border-radius:50%;"
                     f"border:6px solid {GOLD};box-shadow:0 0 18px rgba(201,162,39,.8)'></div>"
                     f"<div style='position:absolute;left:{CAL[0] - 30}px;top:{CAL[1] - 150}px;background:{GOLD};color:#1B2A4A;border-radius:14px;"
                     f"padding:2px 12px;font-size:34px;font-weight:900'>۱ آذر</div>"),
    "P1": ov("P1", sub("چرا شنبه؟", GOLD)),
    "L2": ov("L2", sub("«از یه روز تمیز.»", CREAM)),
    "P2": ov("P2", sub("اول ماه بود. دیروز.", GOLD)),
    "L3": ov("L3", sub("…پس از سال دیگه. با یه دفتر نو!", CREAM)),
    "P3": ov("P3", sub("یه صفحه، لَم.", GOLD)),
    "L4": ov("L4", sub("اِ… همین بود؟", CREAM)),
    "P4": ov("P4", sub("همین.", GOLD)),
    "L5": ov("L5", sub("…یکی دیگه.", CREAM)),
    "tick": ov("tick", f"<div style='position:absolute;left:70px;top:1250px;background:rgba(14,22,40,.82);border:3px solid {GOLD};"
                       f"border-radius:24px;padding:10px 26px;font-size:54px;font-weight:900;color:{CREAM}'>روز ۱ <span style='color:{GOLD}'>✅</span></div>"),
    "cta": ov("cta", f"<div style='position:absolute;left:50px;right:50px;top:280px;text-align:center'><div style='display:inline-block;"
                     f"background:rgba(14,22,40,.88);border:2px solid rgba(201,162,39,.7);border-radius:30px;padding:22px 40px'>"
                     f"<div style='font-size:62px;font-weight:800;color:{CREAM};line-height:1.4'>تو <span style='color:{GOLD}'>شنبه‌ای</span>، اول‌ماهی<br>یا سال‌دیگه‌ای؟ 👇</div>"
                     f"<div style='font-size:40px;font-weight:700;color:{GOLD};margin-top:10px'>لَم · قسمت ۴ دوشنبه · فالو کن</div></div></div>"
                     f"<div style='position:absolute;left:0;right:0;top:1640px;text-align:center'><div style='display:inline-flex;align-items:center;gap:18px;"
                     f"background:rgba(14,22,40,.80);border-radius:26px;padding:12px 28px 12px 18px'><img src='{ICON}' style='width:80px;height:80px;"
                     f"border-radius:20px;box-shadow:0 0 0 2px {GOLD}'><span style='font-size:48px;font-weight:800;color:{CREAM}'>پله</span></div></div>"),
}
T_C5 = to_out("L1", 3.30)
T_C364 = to_out("L3", 12.40)          # right on «سال دیگه»
T_CAL = to_out("P2", 4.10)


def pop(img, layer, t0, t, a=1.0, sc=0.16, cx=540, cy=360):
    if t - t0 < 0.3:
        s_ = 1 + sc * np.exp(-((t - t0 - 0.08) / 0.09) ** 2)
        layer = cv2.warpAffine(layer, cv2.getRotationMatrix2D((cx, cy), 0, s_), (1080, 1920), borderValue=(0, 0, 0, 0))
    return over(img, layer, a)


# =============================================================== render
enc = subprocess.Popen([FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", str(B / "video.mp4")], stdin=subprocess.PIPE)
for k in range(N):
    t = k / FPS
    cf = clip_frame(t)
    if cf is None:
        img, pk = face_frame(k, t)
        if pk == "A":
            sh = next((x for x in SHOTS if x[0] <= t < x[1]), SHOTS[-1])
        else:
            sh = SHOT_B
        u = np.clip((t - sh[0]) / max(1e-3, sh[1] - sh[0]), 0, 1)
        z = sh[2] + (sh[3] - sh[2]) * u + 0.008 * BOB[k]
        if pk == "A" and abs(t - T_C364) < 0.18:                       # little shake when the counter jumps
            z += 0.012 * np.sin((t - T_C364) * 90)
        if pk == "A" and T_CAL <= t < S_("L3") - 0.04:                 # gold circle on «۱ آذر» lives on the plate (moves with the camera)
            img = pop(img, OV["cal"], T_CAL, t, a=np.clip(min((t - T_CAL) / 0.12, (S_("L3") - 0.04 - t) / 0.15), 0, 1), sc=0.3, cx=CAL[0], cy=CAL[1])
        img = cam(img, z, sh[4], sh[5] - 5 * BOB[k])
    else:
        img = cam(cf, 1.02, 540, 960)
    img = over(img, OV["label"])
    if t < S_("P1") - 0.05:
        img = over(img, OV["hook"], np.clip((S_("P1") - 0.05 - t) / 0.2, 0, 1) * (1 if t < T_C5 - 0.1 else 0.0))
    if T_C5 <= t < T_C364:
        img = pop(img, OV["c5"], T_C5, t)
    if T_C364 <= t < T_CLIP + 1.0:
        img = pop(img, OV["c364"], T_C364, t, a=np.clip((T_CLIP + 1.0 - t) / 0.3, 0, 1), sc=0.24)
    for key in ("P1", "L2", "P2", "L3", "P3", "L4", "P4", "L5"):
        if S_(key) - 0.05 <= t < E_(key) + 0.25 and t < T_CTA:
            img = over(img, OV[key], np.clip(min((t - S_(key) + 0.05) / 0.12, (E_(key) + 0.25 - t) / 0.15), 0, 1))
    if t >= E_("L5") - 0.2:
        img = pop(img, OV["tick"], E_("L5") - 0.2, t, sc=0.2, cx=200, cy=1290)
    if t >= T_CTA:
        img = over(img, OV["cta"], np.clip((t - T_CTA) / 0.2, 0, 1))
    enc.stdin.write(np.clip(img, 0, 255).astype(np.uint8).tobytes())
enc.stdin.close(); enc.wait()

# =============================================================== audio mix
mus = load(W0 / "reel_d010" / "music_leberch_reading.mp3")
mus = mus[int(20.0 * SR):int(20.0 * SR) + NS]; mus = np.pad(mus, (0, max(0, NS - len(mus))))
voice = lam_tr + pel_tr
actv = np.convolve((np.abs(voice) > 0.01).astype(np.float32), np.ones(int(0.25 * SR)) / int(0.25 * SR), "same") > 0.02
duck = np.convolve(np.where(actv, 0.09, 0.20).astype(np.float32), np.ones(int(0.3 * SR)) / int(0.3 * SR), "same")
tt = np.arange(NS) / SR
duck *= np.clip(tt / 0.4, 0, 1) * np.clip((DUR - tt) / 0.7, 0, 1)
mix = voice + mus * duck


def add(x, at, g):
    i = int(at * SR)
    if 0 <= i < NS:
        n = max(0, min(len(x), NS - i)); mix[i:i + n] += x[:n] * g


wh = load(W0 / "reel_d013" / "_build" / "sfx_whoosh.wav")
add(wh, SHOTS[1][0] - 0.05, 0.07)
add(wh, SHOTS[3][0] - 0.05, 0.09)
add(wh, T_CLIP - 0.05, 0.10)
pt = load(W0 / "audio" / "page_turn.wav"); pt = pt[:int(0.9 * SR)] * np.linspace(1, 0, int(0.9 * SR)) ** 0.5
add(pt, T_CLIP + CLIP_LEN * 0.80, 0.40)
add(pt, to_out("L5", 19.6), 0.30)
ding_wav(B / "ding.wav", at=0.0, total=2.0, sr=SR)
dg = load(B / "ding.wav")
add(dg[:int(0.6 * SR)], T_C5, 0.22)
add(dg[:int(0.8 * SR)], T_C364, 0.30)
add(dg[:int(0.6 * SR)], T_CAL, 0.18)
add(dg, T_CTA + 0.05, 0.55)
mix = mix[:int(DUR * SR)]; mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
with wave.open(str(B / "mix.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype(np.int16).tobytes())


def lufs(path):
    e = subprocess.run([FF, "-hide_banner", "-i", str(path), "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    s_ = e[e.rindex("Summary:"):]
    return float(s_.split("I:")[1].split("LUFS")[0]), float(s_.split("Peak:")[1].split("dBFS")[0])


I0, _ = lufs(B / "mix.wav"); gain = TARGET_I - I0
for _ in range(4):
    subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "mix.wav"), "-af", f"volume={gain:.2f}dB,alimiter=limit=0.84:attack=3:release=60:level=false,aresample=48000",
                    "-ac", "2", str(B / "mix_norm.wav")], check=True)
    I1, tp1 = lufs(B / "mix_norm.wav")
    if abs(I1 - TARGET_I) < 0.3:
        break
    gain += TARGET_I - I1
out = EP / "lam_ep3_final.mp4"
subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "video.mp4"), "-i", str(B / "mix_norm.wav"), "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                "-shortest", "-movflags", "+faststart", str(out)], check=True)
subprocess.run([FF, "-y", "-v", "error", "-i", str(out), "-c:v", "libx264", "-preset", "slow", "-b:v", "1900k", "-maxrate", "2400k", "-bufsize", "4800k",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(EP / "lam_ep3_final_upload.mp4")], check=True)
json.dump({"segments": {k: [round(v[0], 3), round(v[1], 3)] for k, v in segs.items()}, "visemes": vis, "T_CLIP": T_CLIP, "T_B": T_B,
           "T_CTA": T_CTA, "DUR": DUR, "loudness": {"input_I": I0, "out_I": I1, "out_TP": tp1}}, open(EP / "lam_ep3_timeline.json", "w"), indent=1)
print("done", out, round(DUR, 2), "LUFS", I1)
