﻿"""Episode 1 (بهانه‌های لَم · قسمت ۱) assets on R3a:
face frames, registered eye/brow layers + full mouth set for lip-sync, Flow start frame 1080x1920,
and an arm cut-out rig test (R1; R3a arms judged impractical - see README)."""
from pathlib import Path
import copy, json, shutil, subprocess
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
import lam_facekit as K
from render_util import html_to_png

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
EP = MASCOT / "ep1"
for d in ("frames", "rig_face", "rig_mouth", "rig_arms"):
    (EP / d).mkdir(parents=True, exist_ok=True)
SRC = MASCOT / "renders_vahid"
CC = ROOT / "renders_cc"

base = cv2.imread(str(SRC / "R3a.jpg"))[:, :, ::-1].astype(np.float32)
H, W = base.shape[:2]
G = dict(R=56, eyeL=(545, 800), eyeR=(662, 802), browL=(541, 714), browR=(654, 717), mouth=(612, 886), ms=1.15)
GRADE = np.array((0.85, 0.83, 0.86))
NAVY_L = 0.299 * 0x1B + 0.587 * 0x2A + 0.114 * 0x4A
LOCAL = cv2.GaussianBlur(base, (0, 0), 22)


def render_svg(inner):
    p = EP / "_lay.png"
    html_to_png("<!doctype html><style>html,body{margin:0;background:transparent}</style>" + K.svg_doc(inner, W, H, (0, 0, W, H)), p, W, H)
    lay = np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)
    p.unlink()
    return lay


def grade(lay, seed=1):
    """Same treatment as the style test: lids / lip rims take the body's local colour, scene grade, softness, grain.
    Returns RGBA float (straight alpha) ready to place on R3a."""
    rgb, a = lay[..., :3].copy(), lay[..., 3]
    lum = rgb @ np.array([0.299, 0.587, 0.114])
    navyish = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] + 8) & (lum < 150)).astype(np.float32), (0, 0), 0.8)[..., None]
    ratio = np.clip(lum / NAVY_L, 0.45, 1.30)[..., None]
    rgb = rgb * (1 - navyish) + np.clip(LOCAL * ratio, 0, 255) * navyish
    rgb = cv2.GaussianBlur(rgb * GRADE, (0, 0), 0.7)
    rgb += np.random.default_rng(seed).normal(0, 2.2, rgb.shape[:2])[..., None]
    a = cv2.GaussianBlur(a, (0, 0), 0.6)
    return np.dstack([np.clip(rgb, 0, 255), a])


def over(img, rgba):
    a = rgba[..., 3:] / 255
    return img * (1 - a) + rgba[..., :3] * a


def save_rgba(rgba, path):
    Image.fromarray(np.clip(rgba, 0, 255).astype(np.uint8), "RGBA").save(path)


def face_inner(ex, look=None, mouth=None):
    saved = copy.deepcopy(K.EXPR[ex])
    e = K.EXPR[ex]
    if look is not None:
        for side in ("eyeL", "eyeR"):
            if e[side] != "happy":
                l = list(e[side]); l[3] = look; e[side] = tuple(l)
    if mouth is not None:
        e["mouth"] = mouth
    R = G["R"]
    u = lambda p: (p[0] / R, p[1] / R)
    inner = K.face(R, ex, eyeL=u(G["eyeL"]), eyeR=u(G["eyeR"]), browL=u(G["browL"]), browR=u(G["browR"]),
                   mouthc=u(G["mouth"]), mscale=G["ms"])
    K.EXPR[ex] = saved
    return inner


# ------------------------------------------------------------------ face frames (bible §5 beats)
EP1 = {  # name: (expression, look, frown-mouth for the lip-sync set)
    "E01_hook": ("E01", (0.12, 0.04), False),        # «سه ماهه کتابم رو صفحه‌ی دوازده مونده» - to camera
    "E08_listening": ("E08", (-0.25, 0.28), False),   # while Peleh's voice talks - soft look at the book
    "E03_curious": ("E03", (0.30, -0.28), False),     # «سیزده... نحسه»
    "E10_satisfied": ("E10", (0.05, 0.05), False),    # «…خب، چهارده‌م خوندم» + gold step
}
for name, (ex, look, fr) in EP1.items():
    if (EP / "rig_face" / f"face_R3a_{name}_nomouth.png").exists():
        continue
    full = grade(render_svg(face_inner(ex, look)))
    Image.fromarray(over(base, full).astype(np.uint8)).save(EP / "frames" / f"lam_ep1_R3a_{name}.png")
    eyes = grade(render_svg(face_inner(ex, look, ("none", False))))
    save_rgba(eyes, EP / "rig_face" / f"face_R3a_{name}_nomouth.png")
print("frames ok")

# ------------------------------------------------------------------ mouth set registered on R3a
R = G["R"]
for m in K.MOUTHS:
    for fr in (False, True):
        if (EP / "rig_mouth" / f"mouth_R3a_{m}_{'frown' if fr else 'neutral'}.png").exists():
            continue
        inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth(R, m, fr, G["ms"])}</g>'
        save_rgba(grade(render_svg(inner), seed=3), EP / "rig_mouth" / f"mouth_R3a_{m}_{'frown' if fr else 'neutral'}.png")
# extra closed smile for E10 / E08 rest
for kind in ("smile_soft", "smirk_wide"):
    inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth_for_expr(R, (kind, False), G["ms"])}</g>'
    save_rgba(grade(render_svg(inner), seed=3), EP / "rig_mouth" / f"mouth_R3a_{kind}_rest.png")
cv2.imwrite(str(EP / "rig_face" / "body_R3a_noface.png"), base[:, :, ::-1].astype(np.uint8))
json.dump({"canvas": [W, H], "eye_R_px": R, **{k: v for k, v in G.items() if k != "R"},
           "rhubarb_map": {"X": "X_rest", "A": "A_MBP", "B": "B_SSH", "C": "C_E", "D": "D_AA", "E": "E_O", "F": "F_OO", "G": "G_FV", "H": "H_L"},
           "layer_order": ["body_R3a_noface.png", "face_R3a_<expr>_nomouth.png", "mouth_R3a_<shape>_<neutral|frown>.png"]},
          open(EP / "rig_face" / "ep1_face_rig.json", "w"), indent=1)
# lip-sync alignment check sheet
tiles = []
for m in K.MOUTHS:
    lay = np.asarray(Image.open(EP / "rig_mouth" / f"mouth_R3a_{m}_neutral.png")).astype(np.float32)
    eyes = np.asarray(Image.open(EP / "rig_face" / "face_R3a_E01_hook_nomouth.png")).astype(np.float32)
    img = np.ascontiguousarray(over(over(base, eyes), lay)[640:1000, 430:800].astype(np.uint8))
    cv2.putText(img, m, (8, 350), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (243, 240, 232), 2, cv2.LINE_AA)
    tiles.append(img)
sheet = np.vstack([np.hstack(tiles[:5]), np.hstack(tiles[5:])])
Image.fromarray(sheet.astype(np.uint8)).save(EP / "lam_ep1_mouth_alignment_check.png")
print("mouths ok")

# ------------------------------------------------------------------ Flow start frame 1080x1920 (pad, no distortion)
start = over(base, grade(render_svg(face_inner("E01", (-0.18, 0.22), ("X_rest", False)))))
s = 1080 / W
small = cv2.resize(start.astype(np.uint8), (1080, round(H * s)), interpolation=cv2.INTER_AREA).astype(np.float32)
h = small.shape[0]
pad_t = (1920 - h) // 2
pad_b = 1920 - h - pad_t
out = np.zeros((1920, 1080, 3), np.float32)
out[pad_t:pad_t + h] = small


def extend(strip_rows, n, up):
    """Extend the frame by n rows using a heavily blurred copy of the edge band (mirrored), fading slightly darker."""
    band = small[:strip_rows] if up else small[-strip_rows:]
    band = band[::-1]
    rep = np.concatenate([band] * (n // strip_rows + 2), 0)[:n]
    rep = cv2.GaussianBlur(rep, (0, 0), 28)
    fade = np.linspace(1.0, 0.82, n)[:, None, None]
    rep = rep * fade
    return rep[::-1] if up else rep


out[:pad_t] = extend(120, pad_t, True)
out[pad_t + h:] = extend(120, pad_b, False)
# feather the seams
blurred = cv2.GaussianBlur(out, (0, 0), 8)
ys = np.arange(1920)[:, None, None]
wseam = np.zeros((1920, 1, 1), np.float32)
for y0 in (pad_t, pad_t + h):
    wseam = np.maximum(wseam, np.clip(1 - np.abs(ys - y0) / 36.0, 0, 1))
out = out * (1 - wseam) + blurred * wseam
flow = EP / "lam_ep1_flow_start.png"
Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).save(flow)
dst = MASCOT.parents[1] / "peleh_copy_texts"
shutil.copy2(flow, dst / "lam_ep1_flow_start.png")
print("flow ok", dst)

# ------------------------------------------------------------------ arm rig test on R1 (free-hanging arms)
r1 = cv2.imread(str(CC / "lam_r_front_noface_01_v1_cc.png"))[:, :, ::-1].astype(np.float32)
H1, W1 = r1.shape[:2]
yy, xx = np.mgrid[0:H1, 0:W1]
rr, gg, bb = r1[..., 0], r1[..., 1], r1[..., 2]
navy = (bb > rr + 18) & (r1.sum(2) < 330)
regL = ((xx < 246) & (yy > 900) & (yy < 1630)) | ((xx < 370) & (yy > 1306) & (yy < 1630))
regR = ((xx > 1137) & (yy > 930) & (yy < 1630)) | ((xx > 980) & (yy > 1320) & (yy < 1630))
# background model (grey studio sweep) from pixels outside the character regions
bgm = (~navy) & (r1.sum(2) > 300) & (r1.sum(2) < 660) & ~regL & ~regR
bgm[:, 230:1150] &= (yy[:, 230:1150] < 260)
bgm[1450:] = False
gx, gy = xx / W1 - .5, yy / H1 - .5
A = np.stack([np.ones_like(gx), gx, gy, gx * gx, gx * gy, gy * gy, gy ** 3, gx * gx * gy], -1).astype(np.float32)
bgfit = np.zeros_like(r1)
idx = np.nonzero(bgm.ravel())[0][::5]
Af = A.reshape(-1, A.shape[-1])[idx]
for c in range(3):
    coef, *_ = np.linalg.lstsq(Af, r1[..., c].ravel()[idx], rcond=None)
    bgfit[..., c] = A @ coef
diff = np.linalg.norm(r1 - bgfit, axis=2)
def clean(m):
    m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    n, lbl, st, _ = cv2.connectedComponentsWithStats(m)
    k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
    m = (lbl == k).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    return cv2.dilate(m, np.ones((3, 3), np.uint8))
armL, armR = clean((diff > 26) & regL), clean((diff > 26) & regR)
hole = cv2.dilate((armL | armR).astype(np.uint8), np.ones((15, 15), np.uint8))
hm = cv2.GaussianBlur(hole.astype(np.float32), (0, 0), 3)[..., None]
plate = r1 * (1 - hm) + (bgfit + np.random.default_rng(2).normal(0, 1.5, r1.shape[:2])[..., None]) * hm
# body block in front of the arms (arms emerge from behind the body)
POLY = [(247, 365), (520, 288), (660, 310), (680, 495), (860, 520), (860, 712), (1040, 725), (1045, 948), (1130, 965), (1140, 1300), (1040, 1318), (250, 1305)]
bodym = np.zeros((H1, W1), np.uint8); cv2.fillPoly(bodym, [np.array(POLY, np.int32)], 255)
bodym = cv2.GaussianBlur(bodym.astype(np.float32) / 255, (0, 0), 1.2)
def rgba_of(m):
    a = cv2.GaussianBlur(m.astype(np.float32), (0, 0), 0.8) * 255
    return np.dstack([r1, a])
layers = {"plate": np.dstack([plate, np.full((H1, W1), 255.0)]), "armL": rgba_of(armL), "armR": rgba_of(armR), "body": np.dstack([r1, bodym * 255])}
for k, v in layers.items():
    save_rgba(v, EP / "rig_arms" / f"R1_{k}.png")
PIV = {"armL": (238, 985), "armR": (1138, 1030)}
json.dump({"pivots_px": PIV, "order": ["plate", "armL", "armR", "body"], "note": "rotate arm layers about pivot; positive deg = counter-clockwise"},
          open(EP / "rig_arms" / "R1_arm_rig.json", "w"), indent=1)


def pose(dl, dr):
    img = layers["plate"][..., :3].copy()
    for k, d in (("armL", dl), ("armR", dr)):
        M = cv2.getRotationMatrix2D(PIV[k], d, 1.0)
        rot = cv2.warpAffine(layers[k], M, (W1, H1), flags=cv2.INTER_LINEAR, borderValue=(0, 0, 0, 0))
        img = over(img, rot)
    return over(img, layers["body"])


fr = EP / "_arm"; fr.mkdir(exist_ok=True)
N = 90
for i in range(N):
    t = i / 30
    dl = -6 * np.sin(t * 2.2)
    dr = 28 * np.clip(np.sin(t * 1.4), 0, 1) ** 1.5 + 4 * np.sin(t * 6) * (t > 0.8)
    img = cv2.resize(pose(dl, dr).astype(np.uint8), (720, 1080), interpolation=cv2.INTER_AREA)
    cv2.imwrite(str(fr / f"{i:04d}.png"), img[:, :, ::-1])
    if i == 45:
        Image.fromarray(img).save(EP / "rig_arms" / "R1_arm_rig_pose_test.png")
ff = imageio_ffmpeg.get_ffmpeg_exe()
subprocess.run([ff, "-y", "-framerate", "30", "-i", str(fr / "%04d.png"), "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20",
                str(EP / "rig_arms" / "R1_arm_rig_test.mp4")], check=True, capture_output=True)
for p in fr.glob("*.png"):
    p.unlink()
fr.rmdir()
print("arms ok")
