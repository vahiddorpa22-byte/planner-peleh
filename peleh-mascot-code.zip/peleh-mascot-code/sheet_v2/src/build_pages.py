﻿"""Assemble the LAM sheet v2 (P1 lock pack) pages + combined PDF."""
from pathlib import Path
from PIL import Image
import lam_facekit as K
from common import *
from build_grid import spec_grid_page, overlay_pages, inconsist_page, fa

KIT = ROOT / "face_kit" / "png"
PAGES = ROOT / "pages"
PAGES.mkdir(exist_ok=True)
TMP = ROOT / "pages" / "_assets"
TMP.mkdir(exist_ok=True)


def assembled_eyes():
    """Eye previews per lid stage (white + pupil + highlight + lid), composited from the kit PNGs."""
    out = []
    for pct in (0, 20, 35, 55, 100):
        im = Image.open(KIT / "eyes" / "eye_L_white.png").convert("RGBA")
        pu = Image.open(KIT / "eyes" / "pupil.png").convert("RGBA")
        hi = Image.open(KIT / "eyes" / "eye_highlight.png").convert("RGBA")
        # clip pupil to the white
        wa = im.split()[3].point(lambda v: 255 if v > 200 else 0)
        layer = Image.new("RGBA", im.size)
        layer.alpha_composite(pu, (30, 8)); layer.alpha_composite(hi, (30, 8))
        a = Image.composite(layer, Image.new("RGBA", im.size), wa)
        im.alpha_composite(a)
        im.alpha_composite(Image.open(KIT / "eyes" / f"lid_L_{pct:03d}.png").convert("RGBA"))
        p = TMP / f"eye_stage_{pct:03d}.png"
        im.save(p)
        out.append((pct, p))
    return out


# ------------------------------------------------------------------ pages
def cover():
    bb = uri(REFD / "lam_beanbag_square_profile.jpg")
    body = f"""
<div style="position:absolute;inset:96px 0 44px 0">
 <div style="position:absolute;left:120px;top:70px;width:780px;height:780px;border-radius:50%;overflow:hidden;box-shadow:0 0 0 3px {GOLD},0 0 80px rgba(201,162,39,.35);background:url('{bb}') center/112%"></div>
 <div style="position:absolute;right:120px;top:90px;width:820px;text-align:right">
  <div style="font-size:22px;color:{GOLD};letter-spacing:.06em;font-weight:700">پله · شیت کاراکتر · نسخه‌ی ۲</div>
  <div style="font-size:280px;line-height:1.0;font-weight:900;color:{CREAM};margin-top:70px;text-shadow:0 8px 30px rgba(0,0,0,.35)">لَم</div>
  <div style="font-size:34px;font-weight:700;color:{CREAM};margin-top:80px">بسته‌ی قفل <span class="ltr">P1</span>: فرم، صورت، دهان، افکت</div>
  <div style="font-size:21px;color:#AEB4C2;margin-top:18px;line-height:1.8">«لَم» از لم دادن: همان بخش ذهن ما که می‌گوید «از فردا».<br>شخصیت اصلی سری «بهانه‌های لَم». طعنه‌اش فقط به خودش است، هرگز به مخاطب.</div>
  <div style="display:flex;gap:12px;justify-content:flex-start;flex-direction:row-reverse;margin-top:34px">
   <span class="tag">پیش‌نویس برای تأیید وحید</span><span class="tag grey">۱۱ آبان ۱۴۰۵</span><span class="tag grey">زیرتیم گرافیک · واحد ۴</span></div>
  <div style="display:flex;gap:14px;margin-top:40px;direction:ltr;justify-content:flex-end">
   <div style="text-align:center"><div style="width:120px;height:58px;border-radius:12px;background:{NAVY};border:1px solid rgba(255,255,255,.25)"></div><div style="font-size:15px;color:#AEB4C2;margin-top:6px">#1B2A4A</div></div>
   <div style="text-align:center"><div style="width:120px;height:58px;border-radius:12px;background:{GOLD}"></div><div style="font-size:15px;color:#AEB4C2;margin-top:6px">#C9A227</div></div>
   <div style="text-align:center"><div style="width:120px;height:58px;border-radius:12px;background:{CREAM}"></div><div style="font-size:15px;color:#AEB4C2;margin-top:6px">#F3F0E8</div></div></div>
 </div>
 <div style="position:absolute;left:120px;bottom:20px;font-size:15px;color:#8790A6">تصویر: رندر فعلی پوف (مرجع حال‌وهوا، نه فرم بدن)</div>
</div>"""
    return page("P1·01", "جلد", "Cover", body, "مرجع: character_sheet_spec.md (مشاور ارشد، ۱۱ آبان)")


def colour_page():
    sw = [(NAVY, "سرمه‌ای", "#1B2A4A", "~۷۰٪", "بدن، دست و پا، پلک، پوف، پس‌زمینه (کمی تیره‌تر)"),
          (GOLD, "طلایی خاموش", "#C9A227", "~۱۰٪", "کفش، پله‌ی روشن، هاله، لوگوی لیوان · هرگز زرد روشن"),
          (CREAM, "استخوانی", "#F3F0E8", "~۱۵٪", "سفیدی چشم، کفش، بند، متن (برند قدیم: <span class=ltr>#F2EAD3</span>)"),
          ("#33251A", "قهوه‌ای ابرو", "#33251A", "<۲٪", "نمونه‌برداری‌شده از رندر پوف (میانه‌ی پیکسل‌ها) · قفل"),
          ("#170D05", "مردمک", "#170D05", "—", "نمونه‌برداری‌شده از رندر پوف"),
          ("#2A1520", "داخل دهان", "#2A1520", "<۱٪", "برآورد مشخصات · نمونه‌ی <span class=ltr>v1: #442522</span>"),
          ("#C96A6A", "زبان", "#C96A6A", "<۱٪", "برآورد مشخصات · نمونه‌ی <span class=ltr>v1: #D55F43</span> نارنجی‌تر است؛ پیشنهاد: همان <span class=ltr>#C96A6A</span>")]
    rows = "".join(f"""<div style="display:flex;align-items:center;gap:18px;padding:11px 0;border-bottom:1px solid rgba(255,255,255,.07)">
<div style="width:74px;height:54px;border-radius:12px;background:{c};border:1px solid rgba(255,255,255,.2);flex:none"></div>
<div style="width:150px;font-weight:800;font-size:19px">{n}</div><div class="ltr" style="width:100px;font-size:16px;color:{GOLD}">{h}</div>
<div style="width:60px;font-size:16px;color:#C3C8D3">{s}</div><div style="font-size:15px;color:#AEB4C2">{u}</div></div>""" for c, n, h, s, u in sw)
    share = "".join(f'<div style="height:100%;width:{w}%;background:{c}"></div>' for c, w in ((NAVY, 70), (CREAM, 15), (GOLD, 10), ("#33251A", 2), ("#3E7D4E", 3)))
    light = f"""<svg width="520" height="420" style="direction:ltr">
<defs><radialGradient id="kl" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FFC877" stop-opacity=".9"/><stop offset="1" stop-color="#FFC877" stop-opacity="0"/></radialGradient></defs>
<ellipse cx="260" cy="360" rx="150" ry="20" fill="#000" opacity=".35"/>
<path d="M170 350 V110 H215 V140 H260 V170 H305 V200 H350 V350 Z" fill="{NAVY}" stroke="#4A5A8A" stroke-width="2"/>
<circle cx="70" cy="70" r="70" fill="url(#kl)"/><circle cx="70" cy="70" r="18" fill="#FFD48A"/>
<path d="M100 95 L165 125" stroke="#FFC877" stroke-width="4"/>
<text x="20" y="230" font-size="17" fill="#FFD48A" font-family="Vaz" font-weight="700">Key · 3200K</text><text x="20" y="252" font-size="15" fill="#E6E8EE" font-family="Vaz">گرم، بالا-چپ (چراغ مطالعه)</text>
<path d="M475 120 L360 200" stroke="#7FA3FF" stroke-width="4"/><circle cx="485" cy="115" r="14" fill="#7FA3FF"/>
<text x="510" y="280" font-size="17" fill="#9DB8FF" font-family="Vaz" font-weight="700" text-anchor="end">Rim · cool navy</text><text x="510" y="302" font-size="15" fill="#E6E8EE" font-family="Vaz" text-anchor="end">پشت-راست</text>
<path d="M260 30 L260 90" stroke="#C3C8D3" stroke-width="2" stroke-dasharray="5 5"/><text x="260" y="22" font-size="15" fill="#C3C8D3" font-family="Vaz" text-anchor="middle">Fill · ضعیف</text>
<text x="260" y="405" font-size="15" fill="#C3C8D3" font-family="Vaz" text-anchor="middle">سایه‌ی تماسی نرم زیر کفش و پوف</text></svg>"""
    body = f"""
<div class="card" style="position:absolute;top:122px;right:64px;width:1060px;padding:20px 30px">
 <h3>پالت قفل‌شده</h3>{rows}
 <div style="margin-top:18px;font-size:15px;color:#AEB4C2">سهم تقریبی در کادر</div>
 <div style="display:flex;height:22px;border-radius:11px;overflow:hidden;margin-top:8px;direction:ltr">{share}</div>
 <div style="display:flex;justify-content:space-between;font-size:13px;color:#8790A6;margin-top:6px"><span>سبز طبیعی فقط برای گیاه (&lt;۳٪)</span><span>سرمه‌ای ۷۰ · استخوانی ۱۵ · طلایی ۱۰</span></div>
</div>
<div class="card" style="position:absolute;top:122px;left:64px;width:640px;height:520px;padding:20px 26px">
 <h3>نور ثابت همه‌ی قسمت‌ها</h3>{light}</div>
<div class="card" style="position:absolute;top:660px;left:64px;width:640px;height:316px;padding:20px 26px">
 <h3>متریال و دوربین</h3>
 <p>• مات و خمیری، مثل <span class="ltr">Designer Toy / matte vinyl</span>؛ انعکاس خیلی کم، ریزبافت ملایم.</p>
 <p>• <b>نه</b> نمد و پرز، <b>نه</b> پلاستیک براق، <b>نه</b> فلز.</p>
 <p>• دوربین: عمودی <span class="ltr">9:16</span>، لنز معادل <span class="ltr">~50mm</span> در ارتفاع چشم لَم، عمق میدان کم.</p>
 <p>• کیت صورت همین نور را دارد: برق چشم ساعت ۱۰، سایه‌ها پایین-راست.</p></div>"""
    return page("P1·05", "رنگ، متریال، نور", "Colour · material · light", body,
                "رنگ‌های «نمونه‌برداری‌شده» با پایتون از ref/lam_beanbag_square_profile.jpg؛ «برآورد» = هنوز منبع قابل‌اتکا ندارد")


EPIS = {"E01": "۰، ۱، ۲", "E02": "۰، ۴", "E03": "۱، ۳، ۵", "E04": "پایان همه", "E05": "۱، ۲، ۳",
        "E06": "۲ (ساعت)", "E07": "۴", "E08": "همه (صدای پله)", "E09": "۵", "E10": "پایان ۱، ۳، ۵"}
RECIPE = {"E01": "پلک ۳۵٪ · نگاه کنار · ابروی راست بالا · لبخند کج",
          "E02": "پلک ۵۵٪ · مردمک پایین · ابرو صاف · خط رو به پایین",
          "E03": "کاملاً باز · مردمک بالا-کنار · هر دو ابرو بالا · «هوم»",
          "E04": "چشم هلالی ^ ^ · ابرو بالا · دهان باز خندان",
          "E05": "پلک ۴۵٪ · چشم‌غره · اخم ملایم · لب جمع و کج",
          "E06": "گشاد · مردمک فراری · ابروی نگران · لبخند زورکی",
          "E07": "گشاد با برق دوتایی · ابرو نرم بالا · «اُ» کوچک",
          "E08": "پلک ۲۰٪ · نگاه نرم پایین · ابرو نرم · لبخند بسته",
          "E09": "یک چشم تنگ · مردمک بالا · ابرو یکی بالا یکی پایین · لب کج",
          "E10": "پلک ۳۰٪ · نگاه به بیننده · ابرو آرام · لبخند کج پهن"}


def expr_page():
    cards = []
    for ex, e in K.EXPR.items():
        img = uri(KIT / "expr" / f"expr_{ex}_preview.png")
        cards.append(f"""<div class="card" style="width:340px;height:426px;padding:12px;display:flex;flex-direction:column;align-items:center">
<div style="width:300px;height:262px;background:#1B2A4A url('{img}') center 16%/300px auto no-repeat;border-radius:12px"></div>
<div style="display:flex;width:100%;align-items:center;gap:10px;margin-top:8px"><span class="tag ltr">{ex}</span><b style="font-size:19px">{e['name']}</b></div>
<div style="width:100%;font-size:13px;color:#8790A6;direction:ltr;text-align:right;margin-top:2px">{e['en']}</div>
<div style="width:100%;font-size:14px;color:#C3C8D3;margin-top:6px;line-height:1.6">{RECIPE[ex]}</div>
<div style="width:100%;font-size:13px;color:{GOLD};margin-top:auto">قسمت‌ها: {EPIS[ex]}</div></div>""")
    body = f"""<div style="position:absolute;top:116px;right:64px;left:64px;display:flex;flex-wrap:wrap;gap:16px 18px;justify-content:space-between">{''.join(cards)}</div>"""
    return page("P1·06", "۱۰ حالت چهره", "Expression sheet · vector face kit", body,
                "قانون احترام: حالت مسخره‌آمیز یا تحقیرشده نداریم؛ چهره هیچ‌وقت رو به بیننده پوزخند نمی‌زند · پیش‌نمایش روی صفحه‌ی خمیری سرمه‌ای، نه بدن نهایی")


PHON = {"X_rest": ("X", "سکوت", "لبخند کج پایه"), "A_MBP": ("A", "م ب پ", "لب بسته و فشرده"),
        "B_SSH": ("B", "س ش ز ژ چ ج ت د ک گ", "کمی باز، دندان روی هم"), "C_E": ("C", "اِ اَ ی ر", "باز متوسط"),
        "D_AA": ("D", "آ", "کاملاً باز، زبان"), "E_O": ("E", "اُ، «او» کوتاه", "گرد متوسط"),
        "F_OO": ("F", "او، و (گرد)", "غنچه"), "G_FV": ("G", "ف، و (ف‌مانند)", "دندان روی لب پایین"),
        "H_L": ("H", "ل ن (کشیده)", "نوک زبان بالا"), "EE_wide": ("+", "«ای» کشیده", "پهن با دندان")}


def mouth_page():
    cols = []
    for m in K.MOUTHS:
        r, ph, sh = PHON[m]
        cols.append(f"""<div style="width:168px;display:flex;flex-direction:column;align-items:center;gap:6px;direction:rtl">
<div style="width:60px;height:60px;border-radius:50%;background:{GOLD};color:{NAVY};font-size:30px;font-weight:900;display:flex;align-items:center;justify-content:center" class="ltr">{r}</div>
<div style="font-size:17px;font-weight:800;height:52px;text-align:center;line-height:1.5">{ph}</div>
<div style="font-size:13px;color:#AEB4C2;height:22px">{sh}</div>
<div style="width:168px;height:150px;border-radius:14px;background:{NAVY} url('{uri(KIT/'mouth'/f'mouth_{m}_neutral.png')}') center/112% no-repeat;border:1px solid rgba(255,255,255,.08)"></div>
<div style="width:168px;height:150px;border-radius:14px;background:#17223F url('{uri(KIT/'mouth'/f'mouth_{m}_frown.png')}') center/112% no-repeat;border:1px solid rgba(255,255,255,.08)"></div>
<div class="ltr" style="font-size:12px;color:#8790A6">mouth_{m}</div></div>""")
    body = f"""
<div style="position:absolute;top:124px;right:150px;left:52px;display:flex;justify-content:space-between;direction:ltr">{''.join(reversed(cols))}</div>
<div style="position:absolute;top:378px;right:52px;width:92px;text-align:center;font-size:16px;font-weight:800;color:{CREAM}">خنثی<br><span style="font-size:12px;color:#8790A6;font-weight:400">E01 E03 E08</span></div>
<div style="position:absolute;top:536px;right:52px;width:92px;text-align:center;font-size:16px;font-weight:800;color:{CREAM}">اخم‌دار<br><span style="font-size:12px;color:#8790A6;font-weight:400">E02 E05</span></div>
<div style="position:absolute;top:150px;right:52px;width:92px;text-align:center;font-size:14px;color:{GOLD};font-weight:700">شکل<br><span class="ltr">Rhubarb</span></div>
<div class="card" style="position:absolute;top:730px;right:64px;left:64px;padding:18px 26px;display:flex;gap:40px">
 <div style="flex:1"><h3>نام‌گذاری و استفاده</h3>
 <p>فایل‌ها: <span class="ltr">mouth_&lt;shape&gt;_neutral.png / _frown.png</span> (۲۰ فایل، SVG + PNG شفاف). حروف A تا H و X همان شکل‌های <span class="ltr">Rhubarb Lip Sync</span>اند؛ <span class="ltr">EE_wide</span> شکل اضافه برای «ای» کشیده و لبخند حرف‌زدن.</p></div>
 <div style="flex:1"><h3>هشدار صادقانه</h3>
 <p>دقت تشخیص واج فارسی با حالت phonetic در Rhubarb <b>فرضیه</b> است (طبق مشخصات). پیشنهاد: در قسمت ۰ روی یک جمله با روش فعلی «انرژی صدا» مقایسه شود.</p></div></div>"""
    return page("P1·07", "چارت دهان و ویزم‌های فارسی", "Mouth chart · 10 visemes × 2", body,
                "پایه‌ی هر دهان در مرکز بوم ۳۶۰×۳۰۰ است؛ پهنای پایه = 1.2G")


def parts_page():
    eyes = assembled_eyes()
    e_html = "".join(f"""<div style="text-align:center"><div style="width:150px;height:150px;border-radius:14px;background:{NAVY} url('{uri(p)}') center/100%"></div>
<div class="ltr" style="font-size:13px;color:#AEB4C2;margin-top:4px">lid_{pct:03d}</div><div style="font-size:14px">{fa(pct)}٪</div></div>""" for pct, p in eyes)
    raw = ["eye_L_white", "pupil", "eye_highlight", "eye_highlight_double", "eye_happy_arc", "lid_R_squint_lower"]
    r_html = "".join(f"""<div style="text-align:center"><div style="width:130px;height:130px;border-radius:14px;background:#2A3554 url('{uri(KIT/'eyes'/f'{n}.png')}') center/100%"></div>
<div class="ltr" style="font-size:12px;color:#AEB4C2;margin-top:4px">{n}</div></div>""" for n in raw)
    bn = {"base": "پایه", "up": "بالا", "frown": "اخم", "worried": "نگران", "soft": "نرم", "flat": "صاف"}
    b_html = "".join(f"""<div style="text-align:center"><div style="display:flex;gap:4px;direction:ltr"><div style="width:82px;height:56px;border-radius:10px;background:{NAVY} url('{uri(KIT/'brows'/f'brow_L_{s}.png')}') center/100%"></div>
<div style="width:82px;height:56px;border-radius:10px;background:{NAVY} url('{uri(KIT/'brows'/f'brow_R_{s}.png')}') center/100%"></div></div>
<div style="font-size:15px;margin-top:6px;font-weight:700">{bn[s]}</div><div class="ltr" style="color:#8790A6;font-size:11px">brow_L/R_{s}</div></div>""" for s in K.BROW_SHAPES)
    body = f"""
<div class="card" style="position:absolute;top:122px;right:64px;width:1100px;height:300px;padding:18px 26px">
 <h3>چشم: ۵ مرحله‌ی پلک (چپ؛ راست آینه با شیب برعکس)</h3><div style="display:flex;gap:42px;justify-content:center;margin-top:16px">{e_html}</div></div>
<div class="card" style="position:absolute;top:440px;right:64px;width:1100px;height:260px;padding:18px 26px">
 <h3>لایه‌های خام چشم</h3><div style="display:flex;gap:40px;justify-content:center;margin-top:12px">{r_html}</div></div>
<div class="card" style="position:absolute;top:718px;right:64px;width:1100px;height:262px;padding:18px 26px">
 <h3>ابرو: ۶ شکل × ۲ طرف (سر پهن سمت بینی، دم باریک)</h3><div style="display:flex;gap:10px;justify-content:space-between;margin-top:30px">{b_html}</div></div>
<div class="card" style="position:absolute;top:122px;left:64px;width:600px;height:858px;padding:22px 28px">
 <h3>ترتیب لایه‌ها (پایین ← بالا)</h3>
 <p class="ltr" style="text-align:left;font-size:15px;line-height:2;color:#D9DCE4">body (render) → eye_*_white → pupil + eye_highlight<br>(clipped to white alpha, offset by code) → lid_*_NNN → brow_* → mouth_*</p>
 <h3 style="margin-top:18px">قرارداد اندازه</h3>
 <p>همه‌ی قطعه‌ها در مرکز بوم خودشان‌اند. در کیت: شعاع چشم <span class="ltr">R = 140px</span> (یعنی <span class="ltr">0.9G</span>، پس <span class="ltr">G ≈ 156px</span>). روی بدن نهایی با یک ضریب مقیاس ثابت جا می‌افتند.</p>
 <h3 style="margin-top:18px">نور در کیت</h3>
 <p>نور اصلی بالا-چپ ثابت است؛ قطعه‌های سمت راست در <b>شکل</b> آینه می‌شوند ولی نورشان آینه نمی‌شود.</p>
 <h3 style="margin-top:18px">در انتظار رندر</h3>
 <p>ثبت (registration) روی بوم <span class="ltr">2160×3840</span> بخش ۷ فقط بعد از رندر بی‌صورت <b>R1</b> ممکن است؛ الان قطعه‌ها مستقل‌اند.</p>
 <div class="wait" style="height:150px;margin-top:16px"><b>در انتظار رندر R1</b><span>body_front_noface.png و ثبت مختصات چشم/دهان روی آن</span></div>
</div>"""
    return page("P1·08", "کیت صورت: قطعه‌ها", "Face kit parts · eyes · lids · brows", body,
                "منبع: face_kit/svg و face_kit/png (SVG وکتور + PNG شفاف) · lam_face_kit.svg همه را با id دارد")


def style_page():
    st = ROOT / "style_test"
    crop = (330, 250, 700, 600)
    items = [("original", REFD / "lam_beanbag_square_profile.jpg", "رندر اصلی"), ("removed", st / "beanbag_face_removed.png", "صورت پاک‌شده (inpaint)"),
             ("e01", st / "test_expr_E01.png", "کیت: E01 طعنه‌زن"), ("e03", st / "test_expr_E03.png", "کیت: E03 کنجکاو"),
             ("e04", st / "test_expr_E04.png", "کیت: E04 ذوق‌زده"), ("d", st / "test_mouth_D_AA.png", "دهان D (آ)"),
             ("e", st / "test_mouth_E_O.png", "دهان E (اُ)"), ("g", st / "test_mouth_G_FV.png", "دهان G (ف)")]
    tiles = []
    for k, p, lab in items:
        q = TMP / f"st_{k}.png"
        Image.open(p).convert("RGB").crop(crop).resize((370 * 2 // 2 + 0, 350)).save(q)
        tiles.append(f"""<div style="width:304px"><div style="width:304px;height:352px;border-radius:12px;background:url('{uri(q)}') center/cover;{'box-shadow:0 0 0 3px '+GOLD if k=='original' else ''}"></div>
<div style="font-size:15px;margin-top:6px;font-weight:700">{lab}</div></div>""")
    body = f"""
<div style="position:absolute;top:128px;right:64px;width:1280px;display:flex;flex-wrap:wrap;gap:34px 18px">{''.join(tiles)}</div>
<div class="card" style="position:absolute;top:120px;left:64px;width:470px;height:856px;padding:22px 26px">
 <h3>نتیجه‌ی تست (صادقانه)</h3>
 <p><b style="color:{GOLD}">دهان‌ها: خوب.</b> چون فرورفته‌اند، با سایه‌ی نرم و لبه‌ی روشن روی خمیر می‌نشینند و در اندازه‌ی گوشی جدا از رندر به نظر نمی‌رسند.</p>
 <p style="margin-top:8px"><b style="color:{GOLD}">ابروها: قابل قبول.</b> کمی تخت‌تر از ابروی حجیم رندر؛ لبه‌ی کناری ندارند.</p>
 <p style="margin-top:8px"><b style="color:#F08A80">چشم و پلک: هنوز یکدست نیست.</b> پلک رندر یک گنبد برجسته با لبه‌ی ضخیم و نورگیر است؛ پلک وکتور صاف‌تر است و چشم کمی «برچسبی» دیده می‌شود. از نزدیک (زوم ۱۰۰٪) فرق معلوم است؛ در ریلز با فاصله‌ی معمولی کمتر.</p>
 <p style="margin-top:8px"><b>پاک‌سازی صورت:</b> روی سطح صاف جواب داد، ولی جای ابرو نزدیک لبه‌ی پله کمی محو است. با رندر بی‌صورت R1 این مشکل کلاً حذف می‌شود.</p>
 <h3 style="margin-top:16px">پیشنهاد</h3>
 <p>• مسیر «بدن سه‌بعدی + صورت وکتور» برای دهان و ابرو <b>تأیید</b>.</p>
 <p>• برای چشم یکی از این دو: (الف) یک دور دیگر روی پلک وکتور (گنبد و لبه‌ی ضخیم‌تر، ~۱ ساعت)؛ (ب) گرفتن ۲ رندر چشم (باز / نیمه‌باز) در همان ابزار وحید و استفاده‌ی ترکیبی.</p>
 <p>• داوری نهایی روی R1 بی‌صورت، نه روی رندر inpaint‌شده.</p>
 <div style="margin-top:12px"><span class="tag">وضعیت فرضیه: نیمه‌تأیید</span></div>
</div>"""
    return page("P1·09", "تست هم‌سبکی: وکتور روی سه‌بعدی", "Style-match test", body,
                "روش: inpaint ناحیه‌ی صورت (Telea در ¼ وضوح + بافت خمیر) و کامپوزیت کیت با درجه‌بندی گرم صحنه · فایل‌ها: style_test/")


def fx_page():
    fx = ROOT / "fx"
    frames = sorted(fx.glob("_strip_*.png"))
    tiles = []
    for i, p in enumerate(frames):
        q = TMP / f"fx_{i}.png"
        Image.open(p).convert("RGB").crop((660, 420, 920, 680)).save(q)
        tiles.append(f"""<div style="text-align:center"><div style="width:180px;height:230px;border-radius:12px;background:url('{uri(q)}') center/cover"></div>
<div class="ltr" style="font-size:12px;color:#AEB4C2;margin-top:4px">f{int(p.stem.split('_')[-1]) - 15:02d}/18</div></div>""")
    lit = TMP / "fx_lit.png"
    Image.open(fx / "gold_step4_lit_beanbag.png").convert("RGB").crop((300, 140, 900, 740)).save(lit)
    masks = TMP / "fx_masks.png"
    Image.open(fx / "step_masks_overlay_beanbag.png").convert("RGB").crop((300, 140, 900, 740)).save(masks)
    props = [("پوف", "P1", "موجود در رندر فعلی", ""), ("کتاب نیمه‌باز + نشانه‌ی طلایی", "P1 · قسمت ۱", "", "R3a"),
             ("گوشی (صفحه‌ی خاموش، بی‌برند)", "P1 · قسمت ۲", "", "R3b"), ("ساعت دیواری (عقربه‌ها لایه‌ی جدا)", "P1 · قسمت ۲", "وکتور · هنوز ساخته نشده", ""),
             ("دفترچه + خودکار + تیک", "P1 · قسمت ۳", "", "R3c"), ("لیوان با لوگوی پله", "P1", "موجود در رندر فعلی", ""), ("پتوی بافتنی", "P2 · قسمت ۵", "بعد از تست", "")]
    pr = "".join(f"""<div style="display:flex;align-items:center;gap:12px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.07)"><b style="width:210px;font-size:16px">{n}</b><span style="width:96px;font-size:13px;color:#AEB4C2">{pp}</span>
{f'<span class="tag">در انتظار رندر {r}</span>' if r else f'<span class="tag grey">{s}</span>'}</div>""" for n, pp, s, r in props)
    body = f"""
<div class="card" style="position:absolute;top:120px;right:64px;width:1180px;height:450px;padding:18px 24px">
 <h3>افکت «روشن شدن پله‌ی طلایی» · ۰٫۶ ثانیه / ۱۸ فریم</h3>
 <div style="display:flex;gap:14px;direction:ltr;margin-top:6px">{''.join(tiles)}</div>
 <p style="margin-top:14px">سرمه‌ای ← <span class="ltr">#C9A227</span> با multiply + screen (بافت خمیر می‌ماند) · glow نرم (<span class="ltr">σ ≈ 0.4G</span>) · ۴ ذره‌ی طلایی رو به بالا · squash ۳٪ هم‌زمان با «دینگ» ملایم. دموی کامل با صدا: <span class="ltr">fx/lam_fx_gold_step4_demo_v1.mp4</span> · تابع پایتون: <span class="ltr">src/gold_step.py → light_up_frame()</span></p>
</div>
<div style="position:absolute;top:590px;right:64px;width:580px;display:flex;gap:16px">
 <div><div style="width:280px;height:280px;border-radius:14px;background:url('{uri(lit)}') center/cover"></div><div style="font-size:14px;margin-top:6px">پله‌ی ۴ روشن (حالت نگه‌داشت)</div></div>
 <div><div style="width:280px;height:280px;border-radius:14px;background:url('{uri(masks)}') center/cover"></div><div style="font-size:14px;margin-top:6px">۴ ماسک پله روی رندر فعلی</div></div></div>
<div class="card" style="position:absolute;top:590px;right:664px;width:580px;height:386px;padding:18px 24px;border-color:rgba(201,162,39,.55)">
 <h3>قانون (تصمیم وحید، ۱۱ آبان)</h3>
 <p>• در هر قسمت <b>فقط یک پله</b> روشن می‌شود و در قسمت بعد دوباره <b>خاموش</b> است (تجمعی نیست). با بند ۵ بایبل: «لَم کامل عوض نمی‌شود».</p>
 <p>• پله‌ی پایین (۴) اولین پله‌ای است که روشن می‌شود.</p>
 <p>• قسمت‌های تست: <b>۰ تا ۳</b> (تأیید وحید).</p>
 <p style="color:#F0B5AE">• محدودیت رندر فعلی: پله‌ی ۴ کوچک و پشت دست است؛ ستون پله‌ی ۱ و ۲ از روی صورت رد می‌شود. ماسک دقیق بعد از R3 ساخته می‌شود.</p></div>
<div class="card" style="position:absolute;top:120px;left:64px;width:480px;height:856px;padding:18px 24px">
 <h3>اشیا</h3>{pr}
 <div class="wait" style="height:250px;margin-top:18px"><b>در انتظار رندر R3a / R3b / R3c</b><span>لَم بی‌صورت روی پوف با کتاب، گوشی، دفترچه (پرامپت R3 در prompts/lam_prompts_v1.txt)</span></div></div>"""
    return page("P1·10", "اشیا و افکت پله‌ی طلایی", "Props · gold-step effect", body,
                "افکت روی رندر فعلی ساخته شده تا روش تأیید شود؛ نسخه‌ی نهایی روی رندرهای جدید")


def views_page():
    cut = ROOT / "cutouts"
    names = [("lam_v1_view_front", "روبه‌رو"), ("lam_v1_view_34", "سه‌رخ"), ("lam_v1_view_side", "کنار"), ("lam_v1_view_back", "پشت"),
             ("lam_v1_pose_sarcastic", "طعنه‌زن"), ("lam_v1_pose_tired", "خسته"), ("lam_v1_pose_excited", "ذوق‌زده"), ("lam_v1_pose_curious", "کنجکاو")]
    qual = {"lam_v1_pose_sarcastic": "لکه/سایه", "lam_v1_pose_curious": "سایه‌ی کف", "lam_v1_view_side": "لبه‌ی ناصاف"}
    t = "".join(f"""<div style="text-align:center"><div style="width:190px;height:200px;border-radius:12px;background:#6E7480 url('{uri(cut/(n+'.png'))}') center/contain no-repeat"></div>
<div style="font-size:14px;margin-top:4px">{lab} {f'<span class="tag red" style="font-size:11px">{qual[n]}</span>' if n in qual else ''}</div></div>""" for n, lab in names)
    slots = [("R1", "بدن بی‌صورت · روبه‌رو", "body_front_noface.png · bg #8A8F99"), ("R2", "بدن بی‌صورت · سه‌رخ", "lam_r_34_noface_01_v1.png"),
             ("R4", "اتاق خالی با هاله (بدون لَم)", "bg_room_halo.png · same camera + light")]
    s = "".join(f"""<div class="wait" style="width:370px;height:420px"><b>در انتظار رندر {k}</b><span style="font-size:18px;color:{CREAM}">{a}</span><span class="ltr">{b}</span></div>""" for k, a, b in slots)
    body = f"""
<div style="position:absolute;top:122px;right:64px;left:64px;display:flex;gap:30px;justify-content:space-between">{s}
 <div class="card" style="width:600px;height:420px;padding:20px 26px"><h3>چرا خالی است؟</h3>
 <p>این سه رندر کار وحید با ابزار خودش است (کردیت پولی صفر، پرامپت‌ها در <span class="ltr">prompts/lam_prompts_v1.txt</span>). تیم گرافیک هیچ تصویری را جای رندر نهایی نگذاشته است.</p>
 <p style="margin-top:10px"><b>ترتیب:</b> اول گرید صفحه‌ی ۲ تأیید شود، بعد R1، بعد R3a و R4.</p>
 <p style="margin-top:10px">اگر ابزار «بی‌صورت» را خوب نساخت، رندر عادی بگیرید؛ صورت را با همان روش صفحه‌ی ۹ پاک می‌کنیم.</p></div></div>
<div class="card" style="position:absolute;top:566px;right:64px;left:64px;height:410px;padding:16px 24px">
 <h3>برش‌های شفاف ۸ نمای شیت v1 <span class="tag grey" style="margin-right:10px">فقط مرجع / صفحه‌آرایی · فرم بدن منسوخ</span></h3>
 <div style="display:flex;gap:18px;justify-content:space-between;margin-top:14px;direction:ltr">{t}</div>
 <p style="font-size:14px;color:#AEB4C2;margin-top:10px">روش رایگان: مدل پس‌زمینه + GrabCut (OpenCV). ۶ از ۸ تمیز؛ ۲ تا (برچسب قرمز) پاک‌سازی دستی می‌خواهند. وضوح منبع پایین است (شیت ۱۵۳۶px).</p></div>"""
    return page("P1·11", "نماها و رندرهای در انتظار", "Views · pending renders", body, "فایل‌ها: cutouts/*.png (PNG شفاف، ۲× بزرگ‌نمایی)")


def dodont_page():
    rows = [("۴ پله‌ی شمردنی، بلندترین سمت چپ بیننده", "کمتر یا بیشتر از ۴ پله، یا جهت برعکس"),
            ("پهن‌تر از بلند (۸:۷)", "ستون باریک یا بدن مستطیلی تخت"),
            ("مات و خمیری (Designer Toy)", "نمد، پرز، پلاستیک براق، فلز"),
            ("طلایی خاموش <span class=ltr>#C9A227</span>", "زرد روشن، نارنجی، طلای براق آینه‌ای"),
            ("۳ انگشت + شست", "۵ انگشت یا انگشت اضافه"),
            ("چشم‌های بزرگ کرم، پلک سرمه‌ای", "چشم‌های کوچک یا مژه‌ی بلند"),
            ("ابروی قهوه‌ای ضخیم", "ابروی سیاه نازک"),
            ("اسنیکر کرم و طلایی بی‌برند", "لوگوی نایکی یا هر برند واقعی"),
            ("شیت = تنها رفرنس مولد تصویر", "دادن تصویر پوف به‌عنوان رفرنس فرم بدن"),
            ("چهره‌ی طعنه به خود", "پوزخند تحقیرآمیز رو به بیننده"),
            ("سبز فقط برای گیاه", "رنگ‌های خارج از پالت در لَم"),
            ("بدون متن یا لوگوی پله روی بدن لَم", "اسم اپ در ۳ ثانیه‌ی اول هر ویدیو")]
    ok = f'<svg width="26" height="26"><circle cx="13" cy="13" r="13" fill="{GOLD}"/><path d="M7 13.5l4 4 8-9" stroke="{NAVY}" stroke-width="3" fill="none" stroke-linecap="round"/></svg>'
    no = f'<svg width="26" height="26"><circle cx="13" cy="13" r="13" fill="{RED}"/><path d="M8.5 8.5l9 9M17.5 8.5l-9 9" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>'
    tr = "".join(f"""<div style="display:flex;border-bottom:1px solid rgba(255,255,255,.07)"><div style="flex:1;display:flex;gap:12px;align-items:center;padding:9px 16px">{ok}<span style="font-size:18px">{a}</span></div>
<div style="flex:1;display:flex;gap:12px;align-items:center;padding:9px 16px;background:rgba(226,87,76,.05)">{no}<span style="font-size:18px;color:#E9C9C5">{b}</span></div></div>""" for a, b in rows)
    good = TMP / "dd_good.png"
    Image.open(ROOT / "grid" / "lam_P1_proportion_grid_v1_alt_eye44.png").convert("RGB").crop((90, 130, 900, 900)).save(good)
    bad = TMP / "dd_bad.png"
    Image.open(REFD / "lam_character_sheet_v1.jpg").convert("RGB").crop((290, 25, 625, 400)).save(bad)
    body = f"""
<div class="card" style="position:absolute;top:122px;right:64px;width:1150px;padding:6px 0;overflow:hidden">
<div style="display:flex;font-weight:800;font-size:20px"><div style="flex:1;padding:10px 16px;color:{GOLD}">باید</div><div style="flex:1;padding:10px 16px;color:#F08A80">نباید</div></div>{tr}</div>
<div style="position:absolute;top:122px;left:64px;width:560px;display:flex;flex-direction:column;gap:18px">
 <div><div style="width:560px;height:400px;border-radius:16px;background:{GREY} url('{uri(good)}') center/contain no-repeat;box-shadow:0 0 0 3px {GOLD}"></div><div style="margin-top:8px;font-size:16px">{ok} <b>فرم قفل‌شده:</b> ۴ پله، پهن، بلندترین چپ (چشم در <span class=ltr>4.4G</span>، پیشنهاد)</div></div>
 <div><div style="width:560px;height:330px;border-radius:16px;background:#1D2440 url('{uri(bad)}') center/contain no-repeat;box-shadow:0 0 0 3px {RED}"></div><div style="margin-top:8px;font-size:16px">{no} <b>v1 روبه‌رو:</b> قله‌ی وسط و بلندتر از پهنا</div></div>
</div>"""
    return page("P1·12", "بایدها و نبایدها", "Do · Don't", body, "مطابق بخش ۸ مشخصات")


def files_page():
    tree = """peleh_work/mascot/
  sheet_v2/                     ← این بسته
    pages/       lam_sheet_v2_P1_pNN.png · lam_sheet_v2_P1.pdf
    grid/        lam_P1_proportion_grid_v1.png  (+ صفحه‌های گرید)
    face_kit/    lam_face_kit.svg
                 svg/ png/  eyes/ brows/ mouth/ expr/
    style_test/  test_expr_E01.png … test_mouth_G_FV.png
    fx/          lam_fx_gold_step4_demo_v1.mp4
                 masks/body_step1..4_mask_beanbag.png
    cutouts/     lam_v1_view_*.png · lam_v1_pose_*.png
    src/         lam_facekit.py · gold_step.py · build_*.py
  renders/  lam_r_<view|scene>_<nn>_v<k>.png   ← رندرهای وحید
  rig/      body/ eyes/ brows/ mouth/ props/ bg/ fx/"""
    status = [("گرید تناسب + اورلی", "آماده · منتظر تأیید", ""), ("کیت صورت: ۱۰ حالت، ۲۰ دهان، ۱۲ ابرو، ۵ پلک", "آماده", ""),
              ("تست هم‌سبکی", "آماده · نتیجه: نیمه‌تأیید", ""), ("افکت پله‌ی طلایی + دمو", "آماده", ""),
              ("برش‌های v1", "۶ از ۸ تمیز", ""), ("بدن بی‌صورت روبه‌رو / سه‌رخ", "", "R1 · R2"),
              ("صحنه‌های پوف با شیء", "", "R3a · R3b · R3c"), ("اتاق خالی", "", "R4"),
              ("ماسک ۴ پله روی بدن نهایی + ثبت لایه‌ها روی 2160×3840", "", "R1"), ("ساعت، دفترچه، تیک (وکتور)", "مرحله‌ی بعد تیم", "")]
    st = "".join(f"""<div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.07)"><span style="flex:1;font-size:16px">{a}</span>
{f'<span class="tag">{b}</span>' if b else ''}{f'<span class="tag red">در انتظار رندر {c}</span>' if c else ''}</div>""" for a, b, c in status)
    body = f"""
<div class="card" style="position:absolute;top:122px;right:64px;width:960px;height:560px;padding:20px 26px">
 <h3>پوشه و نام‌گذاری</h3>
 <pre class="ltr" style="font-family:Vaz,monospace;font-size:16px;line-height:1.75;color:#D9DCE4;text-align:left;white-space:pre">{__import__("html").escape(tree)}</pre></div>
<div class="card" style="position:absolute;top:700px;right:64px;width:960px;height:276px;padding:18px 26px">
 <h3>قوانین نام</h3>
 <p>• همه لاتین و کوچک، بدون فاصله · نسخه با <span class="ltr">_v1</span>، <span class="ltr">_v2</span> · روی نسخه‌ی قبلی ذخیره نمی‌شود.</p>
 <p>• دهان: <span class="ltr">mouth_&lt;Rhubarb&gt;_&lt;neutral|frown&gt;</span> · پلک: <span class="ltr">lid_L|R_000..100</span> · ابرو: <span class="ltr">brow_L|R_&lt;shape&gt;</span> · حالت: <span class="ltr">expr_E01..E10</span></p>
 <p>• رندر: <span class="ltr">lam_r_front_noface_01_v1.png</span> · افکت: <span class="ltr">lam_fx_&lt;name&gt;_v1.mp4</span></p></div>
<div class="card" style="position:absolute;top:122px;left:64px;width:720px;height:854px;padding:20px 26px">
 <h3>وضعیت بسته‌ی P1</h3>{st}
 <p style="margin-top:16px;font-size:15px;color:#AEB4C2">هزینه‌ی این بسته: ۰ تومان (کردیت پولی مصرف نشد).</p></div>"""
    return page("P1·13", "نام‌گذاری فایل و وضعیت", "File naming · status", body, "مطابق بخش ۷ و ۹ مشخصات")


if __name__ == "__main__":
    import sys
    builders = [cover, spec_grid_page, overlay_pages, inconsist_page, colour_page, expr_page, mouth_page, parts_page,
                style_page, fx_page, views_page, dodont_page, files_page]
    only = set(int(a) for a in sys.argv[1:])
    outs = []
    for i, b in enumerate(builders, 1):
        p = PAGES / f"lam_sheet_v2_P1_p{i:02d}.png"
        if not only or i in only:
            render_page(b(), p)
            print("page", i)
        outs.append(p)
    if not only:
        ims = [Image.open(p).convert("RGB") for p in outs]
        ims[0].save(PAGES / "lam_sheet_v2_P1.pdf", save_all=True, append_images=ims[1:], resolution=96, quality=92)
        print("pdf")
