"""«لَم» episode 4 «زمستون» (Mon 9 Azar 1405).
Plate A = Flow clip db497413 @2.9 s (faceless + face kit) · Flow clip 2.9→7.2 s (Lam silent: reaches, takes the book, opens it)
· Plate B = clip @7.2 s (faceless + kit, reading). Voices: Vahid's Danesh take (Lam) + Sara (Peleh).
  L1 «آخ جون، زمستون شد!»        cheer, brows up
  L2 «پتو، چای…»                 cozy, lids low
  YAWN                            eyes shut, mouth wide
  L3 «وقتشه که… بخوابم.»         lids sink
  P1 «لَم! کتاب؟»                 eyes pop open, glance up
  L4 «هوا سرده! کتاب که پتو نمی‌شه!» whiny, worried brows
  P2 «از زیر پتو هم می‌شه خوند. فقط ده صفحه.»   eyes slide to the book
  L5 «باشه…»                      sigh → Flow clip
  L6 «عه…» (plate B)               surprised
  L7 «این که خوب بود! یه صفحه‌ی دیگه؟»  delighted
  P3 «زمستون، پتو، چای، و ده صفحه. لینک چالش تو بیو.»  reading · CTA
Output: ep4/lam_ep4_final.mp4 (+ _upload), ep4/_build/check.jpg, ep4/lam_ep4_timeline.json
"""
from pathlib import Path
import copy, json, subprocess, wave
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
import lam_facekit as K
from render_util import html_to_png, FONT
from gold_step import ding_wav

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
W0 = MASCOT.parent
EP = MASCOT / "ep4"
B = EP / "_build"
B.mkdir(exist_ok=True)
FF = imageio_ffmpeg.get_ffmpeg_exe()
FPS, SR = 30, 44100
GOLD, CREAM = "#C9A227", "#F3F0E8"
TEMPO = 1.06
TARGET_I = -14.0


def load(p, sr=SR):
    raw = subprocess.run([FF, "-v", "quiet", "-i", str(p), "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768


def fade(x, ms=15):
    n = int(SR * ms / 1000); x = x.copy()
    x[:n] *= np.linspace(0, 1, n); x[-n:] *= np.linspace(1, 0, n)
    return x


def tempo(y, f):
    out = subprocess.run([FF, "-v", "quiet", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "-", "-af", f"atempo={f}", "-f", "f32le", "-"],
                         input=y.astype(np.float32).tobytes(), capture_output=True).stdout
    return np.frombuffer(out, np.float32).copy()


lam = load(EP / "lam_ep4_lam.mp3")
pel = load(EP / "lam_ep4_peleh.mp3")
pel = pel * (np.sqrt(np.mean(lam[np.abs(lam) > .02] ** 2)) / np.sqrt(np.mean(pel[np.abs(pel) > .02] ** 2)))   # level Sara to Lam
ITEMS = [("L1", "L", 0.08, 2.72, 0.15),
         ("L2", "L", 3.42, 5.04, 0.25),
         ("YW", "L", 5.36, 6.24, 0.12),
         ("L3", "L", 6.62, 8.42, 0.10),
         ("P1", "P", 0.12, 2.02, 0.14),
         ("L4", "L", 9.92, 13.32, 0.10),
         ("P2", "P", 3.32, 6.52, 0.12),
         ("L5", "L", 14.44, 15.60, 0.18),
         ("L6", "L", 16.32, 16.72, None),      # after the clip
         ("L7", "L", 17.20, 19.52, 0.30),
         ("P3", "P", 7.48, 13.66, 0.25)]
CUTS = {"L7": [(18.18, 18.42)]}
XF = int(0.012 * SR)
CLIP_A, CLIP_B = 2.9, 7.2          # source seconds of the Flow clip that are played between the plates
CLIP_LEN = CLIP_B - CLIP_A


def cut_take(src, key, a, b):
    pieces, p0 = [], a
    for c0, c1 in CUTS.get(key, []) + [(b, b)]:
        pieces.append(src[int(p0 * SR):int(c0 * SR)].copy()); p0 = c1
    y0 = pieces[0]
    for pc in pieces[1:]:
        r = np.linspace(0, 1, XF, dtype=np.float32)
        y0 = np.concatenate([y0[:-XF], y0[-XF:] * (1 - r) + pc[:XF] * r, pc[XF:]])
    return fade(tempo(fade(y0), TEMPO))


segs, t = {}, 0.0
for key, spk, a, b, gap in ITEMS:
    y = cut_take(lam if spk == "L" else pel, key, a, b)
    if key == "L6":
        t = segs["L5"][1] + 0.12 + CLIP_LEN + 0.12
    else:
        t += gap
    segs[key] = (t, t + len(y) / SR, y, spk, a)
    t += len(y) / SR
S_ = lambda k: segs[k][0]
E_ = lambda k: segs[k][1]


def to_out(key, ts):
    rm = 0.0
    for c0, c1 in CUTS.get(key, []):
        if ts >= c1:
            rm += c1 - c0
        elif ts > c0:
            rm += ts - c0
    return segs[key][0] + (ts - segs[key][4] - rm) / TEMPO


T_CLIP = E_("L5") + 0.12
T_B = T_CLIP + CLIP_LEN
T_CTA = S_("P3") + 2.6
TAIL = 1.6
DUR = E_("P3") + TAIL
N = int(round(DUR * FPS)); NS = int(DUR * SR) + SR
lam_tr, pel_tr = np.zeros(NS, np.float32), np.zeros(NS, np.float32)
for key, (a, b, y, spk, _) in segs.items():
    tr = lam_tr if spk == "L" else pel_tr
    i = int(a * SR); tr[i:i + len(y)] += y[:max(0, min(len(y), NS - i))]
print({k: (round(v[0], 2), round(v[1], 2)) for k, v in segs.items()}, "clip", round(T_CLIP, 2), round(T_B, 2), "DUR", round(DUR, 2))

# =============================================================== syllable-timed visemes (source seconds of Vahid's take)
M, T, L_, FV = "A_MBP", "B_SSH", "H_L", "G_FV"
AA, E, I, U, O = "D_AA", "C_E", "EE_wide", "F_OO", "E_O"
RUNS = {
    "L1": [((0.12, 0.45), [(None, AA, T)]),                                                    # آخ
           ((0.63, 1.32), [(T, U, L_)]),                                                       # جون
           ((1.41, 2.67), [(T, E, None), (M, E, T), (T, U, L_), (T, O, T)])],                  # زِ مِس تون شُد
    "L2": [((3.48, 4.22), [(M, E, None), (T, U, None)]),                                       # پَ تو
           ((4.33, 4.98), [(T, AA, None), (None, I, None)])],                                  # چا ی
    "YW": [((5.40, 6.20), [(None, AA, None)])],                                                # yawn
    "L3": [((6.67, 7.53), [(None, E, T), (T, E, None), (T, E, None)]),                         # وَق تِ شه که
           ((7.85, 8.36), [(M, E, None), (T, AA, M)])],                                        # بِ خوابم
    "L4": [((9.96, 11.36), [(None, E, None), (U, AA, None), (T, E, L_), (T, E, None)]),        # هَ وا سَر دِه
           ((11.59, 12.07), [(T, E, None), (T, AA, M)]),                                       # کِ تاب
           ((12.15, 13.28), [(T, E, None), (M, E, None), (T, U, None), (L_, E, None), (M, I, None), (T, E, None)])],
    "L5": [((14.48, 14.71), [(None, E, None)]),                                                # (sigh)
           ((15.11, 15.53), [(M, AA, None), (T, E, None)])],                                   # با شه
    "L6": [((16.38, 16.66), [(None, E, None)])],                                               # عه
    "L7": [((17.25, 17.77), [(None, I, L_), (T, E, None), (T, U, M)]),                         # این کِ خوب
           ((17.88, 18.15), [(M, U, T)]),                                                      # بود
           ((18.50, 19.47), [(None, E, None), (T, E, FV), (None, E, None), (T, I, None), (T, E, None)])],  # یه صَف حه دی گه
}
WEIGHT = {AA: 1.35, U: 1.3, I: 1.25, O: 1.1, E: 1.0}
vis = ["X"] * N


def put(t0, t1, v):
    k0, k1 = int(round(t0 * FPS)), int(round(t1 * FPS))
    for k in range(max(0, k0), min(N, max(k1, k0 + 2))):
        vis[k] = v


for key, runs in RUNS.items():
    for (a, b), syl in runs:
        w = np.array([WEIGHT[s[1]] + (0.35 if s[0] else 0) + (0.3 if s[2] else 0) for s in syl])
        edges = a + (b - a) * np.concatenate([[0], np.cumsum(w) / w.sum()])
        for (on, vw, co), s0, s1 in zip(syl, edges[:-1], edges[1:]):
            d = s1 - s0
            p0 = s0 + (0.24 * d if on else 0)
            p1 = s1 - (0.22 * d if co else 0)
            if on:
                put(to_out(key, s0), to_out(key, p0), on)
            put(to_out(key, p0), to_out(key, p1), vw)
            if co:
                put(to_out(key, p1), to_out(key, s1), co)
vis = vis[1:] + ["X"]

# =============================================================== plates + kit layers (1116x2000 space)
S = 1080 / 1116
HS = round(2000 * S)
CROP = (HS - 1920) // 2


def to1080(a):
    a = cv2.resize(a, (1080, HS), interpolation=cv2.INTER_AREA)
    return a[CROP:CROP + 1920]


PL = {
    "A": dict(img="lam_ep4_A_faceless.png", soft=1.3,
              G=dict(R=51, eyeL=(492, 866), eyeR=(600, 867), browL=(492, 781), browR=(592, 778), mouth=(549, 940), ms=1.08)),
    "B": dict(img="lam_ep4_B_faceless.png", soft=1.4,
              G=dict(R=84, eyeL=(449, 868), eyeR=(625, 872), browL=(436, 712), browR=(614, 705), mouth=(540, 972), ms=1.12)),
}
GRADE = np.array((0.86, 0.84, 0.88))
NAVY_L = 0.299 * 0x1B + 0.587 * 0x2A + 0.114 * 0x4A
X = lambda eL, eR, bL, bR: dict(eyeL=eL, eyeR=eR, browL=bL, browR=bR, mouth=("none", False))
K.EXPR.update({
    "w_cheer":   X((0.10, 0, 0, (0.05, 0.02), 1.05, True), (0.10, 0, 0, (0.05, 0.02), 1.05, True), ("up", -0.10), ("up", -0.12)),
    "w_cozy":    X((0.48, -3, 0, (0.20, 0.25), 1, False), (0.44, 3, 0, (0.20, 0.25), 1, False), ("soft", 0.02), ("soft", 0.0)),
    "w_yawn":    X((0.93, -3, 0, (0.0, 0.2), 1, False), (0.93, 3, 0, (0.0, 0.2), 1, False), ("up", -0.12), ("up", -0.12)),
    "w_sleepy":  X((0.66, -3, 0, (0.10, 0.30), 1, False), (0.64, 3, 0, (0.10, 0.30), 1, False), ("soft", 0.04), ("soft", 0.02)),
    "w_sleepy2": X((0.82, -3, 0, (0.10, 0.34), 1, False), (0.80, 3, 0, (0.10, 0.34), 1, False), ("soft", 0.06), ("soft", 0.04)),
    "w_startle": X((0.00, 0, 0, (0.30, -0.30), 0.9, False), (0.00, 0, 0, (0.30, -0.30), 0.9, False), ("up", -0.14), ("up", -0.14)),
    "w_whine":   X((0.30, 0, 0, (0.10, -0.10), 1, False), (0.30, 0, 0, (0.10, -0.10), 1, False), ("worried", -0.02), ("worried", -0.02)),
    "w_book":    X((0.24, 0, 0, (0.55, 0.35), 1, False), (0.24, 0, 0, (0.55, 0.35), 1, False), ("soft", 0.0), ("soft", -0.02)),
    "w_sigh":    X((0.58, -2, 0, (0.40, 0.30), 1, False), (0.56, 2, 0, (0.40, 0.30), 1, False), ("worried", 0.02), ("soft", 0.02)),
    "w_surprise": X((0.00, 0, 0, (0.0, 0.10), 1.06, True), (0.00, 0, 0, (0.0, 0.10), 1.06, True), ("up", -0.12), ("up", -0.12)),
    "w_delight": X((0.12, 0, 0, (0.05, 0.05), 1.04, True), (0.12, 0, 0, (0.05, 0.05), 1.04, True), ("up", -0.08), ("up", -0.10)),
    "w_read":    X((0.40, 0, 0, (0.0, 0.45), 1, False), (0.40, 0, 0, (0.0, 0.45), 1, False), ("soft", 0.0), ("soft", 0.0)),
})
EXS = {"A": ["w_cheer", "w_cozy", "w_yawn", "w_sleepy", "w_sleepy2", "w_startle", "w_whine", "w_book", "w_sigh"],
       "B": ["w_surprise", "w_delight", "w_read"]}
RESTS = ["flat_down", "hmm", "o_small", "smile_soft", "smirk_wide"]


def render_svg(inner, name, W, H):
    p = B / f"_{name}.png"
    html_to_png("<!doctype html><style>html,body{margin:0;background:transparent}</style>" + K.svg_doc(inner, W, H, (0, 0, W, H)), p, W, H)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def build_layers(pk):
    P = PL[pk]; G = P["G"]
    plate0 = cv2.imread(str(EP / P["img"]))[:, :, ::-1].astype(np.float32)
    H0, W0p = plate0.shape[:2]
    LOCAL = cv2.GaussianBlur(plate0, (0, 0), 22)
    soft = P["soft"]

    def grade(lay, seed=1):
        rgb, a = lay[..., :3].copy(), lay[..., 3]
        lum = rgb @ np.array([0.299, 0.587, 0.114])
        nv = cv2.GaussianBlur(((rgb[..., 2] > rgb[..., 0] + 8) & (lum < 150)).astype(np.float32), (0, 0), 0.8)[..., None]
        ratio = np.clip(lum / NAVY_L, 0.45, 1.30)[..., None]
        rgb = rgb * (1 - nv) + np.clip(LOCAL * ratio, 0, 255) * nv
        rgb = cv2.GaussianBlur(rgb * GRADE, (0, 0), soft) + np.random.default_rng(seed).normal(0, 2.0, rgb.shape[:2])[..., None]
        return np.dstack([np.clip(rgb, 0, 255), cv2.GaussianBlur(a, (0, 0), soft * 0.85)])

    def face_inner(ex, closed=False):
        saved = copy.deepcopy(K.EXPR[ex]); e = K.EXPR[ex]
        if closed:
            for side in ("eyeL", "eyeR"):
                l = list(e[side]); l[0], l[2] = 0.97, 0.0; e[side] = tuple(l)
        R = G["R"]; u = lambda p: (p[0] / R, p[1] / R)
        inner = K.face(R, ex, eyeL=u(G["eyeL"]), eyeR=u(G["eyeR"]), browL=u(G["browL"]), browR=u(G["browR"]), mouthc=u(G["mouth"]), mscale=G["ms"])
        K.EXPR[ex] = saved
        return inner

    cache = B / f"layers_{pk}.npz"
    if cache.exists():
        Lr = dict(np.load(cache))
    else:
        Lr = {}
        for ex in EXS[pk]:
            Lr[f"face_{ex}"] = np.clip(to1080(grade(render_svg(face_inner(ex), f"{pk}_{ex}", W0p, H0))), 0, 255).astype(np.uint8)
            Lr[f"blink_{ex}"] = np.clip(to1080(grade(render_svg(face_inner(ex, True), f"{pk}_{ex}_b", W0p, H0))), 0, 255).astype(np.uint8)
        R = G["R"]
        for m in K.MOUTHS:
            inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth(R, m, False, G["ms"])}</g>'
            Lr[f"m_{m}"] = np.clip(to1080(grade(render_svg(inner, f"{pk}_m_{m}", W0p, H0), 3)), 0, 255).astype(np.uint8)
        for kind in RESTS:
            inner = f'<g transform="translate({G["mouth"][0]},{G["mouth"][1]})">{K.mouth_for_expr(R, (kind, False), G["ms"])}</g>'
            Lr[f"rest_{kind}"] = np.clip(to1080(grade(render_svg(inner, f"{pk}_r_{kind}", W0p, H0), 3)), 0, 255).astype(np.uint8)
        np.savez(cache, **Lr)
    return to1080(plate0), Lr


PLATE_A, LA = build_layers("A")
PLATE_B, LB = build_layers("B")


def over(img, rgba, a=1.0):
    rgba = rgba.astype(np.float32); al = rgba[..., 3:] / 255 * a
    return img * (1 - al) + rgba[..., :3] * al


# =============================================================== acting
W_ = lambda key, ts: to_out(key, ts)


def act(t):
    if t < W_("L1", 1.35):
        return "A", "w_cheer", "smile_soft"
    if t < S_("L2") - 0.05:
        return "A", "w_cheer", "smile_soft"
    if t < S_("YW") - 0.03:
        return "A", "w_cozy", "smile_soft"
    if t < E_("YW") + 0.05:
        return "A", "w_yawn", "o_small"
    if t < S_("P1") - 0.04:
        return "A", ("w_sleepy2" if t > W_("L3", 7.70) else "w_sleepy"), "smile_soft"
    if t < S_("L4") - 0.05:
        return "A", "w_startle", "o_small"
    if t < S_("P2") - 0.05:
        return "A", "w_whine", "flat_down"
    if t < S_("L5") - 0.05:
        return "A", "w_book", "hmm"
    if t < T_CLIP:
        return "A", "w_sigh", "hmm"
    if t < E_("L6") + 0.10:
        return "B", "w_surprise", "o_small"
    if t < S_("P3") - 0.05:
        return "B", "w_delight", "smirk_wide"
    return "B", "w_read", "smile_soft"


BLINKS = [S_("L2") + 0.3, S_("P1") + 0.9, S_("L4") + 1.6, S_("P2") + 0.6, T_B + 0.15, S_("P3") + 0.8, S_("P3") + 3.6]
blink_frames = {int(bt * FPS) + i for bt in BLINKS for i in range(3)}


def face_frame(k, t):
    pk, ex, rest = act(t)
    plate, Lr = (PLATE_A, LA) if pk == "A" else (PLATE_B, LB)
    img = over(plate, Lr[("blink_" if (k in blink_frames and ex not in ("w_yawn",)) else "face_") + ex])
    v = vis[k]
    img = over(img, Lr[f"rest_{rest}"] if v == "X" else Lr[f"m_{v}"])
    return img, pk


# =============================================================== Flow clip
raw = subprocess.run([FF, "-v", "quiet", "-ss", str(CLIP_A), "-t", str(CLIP_LEN + 0.2), "-i", str(EP / "flow_clip_B.mp4"),
                      "-vf", "fps=30,scale=1116:1984:flags=lanczos,pad=1116:2000:0:8,scale=1080:1935,crop=1080:1920:0:7",
                      "-an", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
CLIP = np.frombuffer(raw, np.uint8).reshape(-1, 1920, 1080, 3)
CN = len(CLIP)
print("clip frames", CN)


def cam(img, z, fx, fy):
    cw, ch = 1080 / z, 1920 / z
    x0 = float(np.clip(fx - cw / 2, 0, 1080 - cw)); y0 = float(np.clip(fy - ch / 2, 0, 1920 - ch))
    Mx = np.float32([[z, 0, -x0 * z], [0, z, -y0 * z]])
    out = cv2.warpAffine(img, Mx, (1080, 1920), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
    if z > 1.25:
        out = out + 0.3 * (out - cv2.GaussianBlur(out, (0, 0), 1.2))
    return out


FACE_A = (546 * S, 880 * S - CROP)
SHOTS = [(0.0, S_("YW") - 0.05, 1.00, 1.05, 540, 960),                       # wide: «آخ جون، زمستون شد! پتو، چای…»
         (S_("YW") - 0.05, S_("P1") - 0.04, 1.32, 1.42, FACE_A[0], FACE_A[1]),  # close: yawn + «بخوابم»
         (S_("P1") - 0.04, S_("P2") - 0.06, 1.18, 1.24, FACE_A[0], FACE_A[1] + 40),  # «لَم! کتاب؟» + whine
         (S_("P2") - 0.06, T_CLIP, 1.06, 1.00, 540, 960)]                      # back to the clip framing (book on the table)
SHOT_B = (T_B, DUR, 1.00, 1.05, 540, 920)

hop = SR // FPS
lr = np.array([np.sqrt((lam_tr[k * hop:(k + 1) * hop] ** 2).mean() + 1e-12) for k in range(N)])
lr = np.convolve(lr, np.ones(4) / 4, "same"); BOB = np.clip(lr / (np.percentile(lr[lr > 0.005], 95) + 1e-6), 0, 1)

# =============================================================== overlays
CSS = (f"@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}"
       "html,body{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}body{font-family:Vaz;direction:rtl}")


def ov(name, body):
    p = B / f"ov_{name}.png"
    html_to_png(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style>{body}", p, 1080, 1920)
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)


def sub(text, color):
    return (f"<div style='position:absolute;left:50px;right:50px;top:1450px;text-align:center'><span style='display:inline-block;"
            f"background:rgba(14,22,40,.74);border-radius:22px;padding:10px 30px;font-size:56px;font-weight:700;line-height:1.35;color:{color}'>{text}</span></div>")


ICON = (W0 / "app_ref" / "icon-512.png").as_uri()
OV = {
    "label": ov("label", f"<div style='position:absolute;right:46px;top:200px;background:rgba(14,22,40,.72);border:2px solid rgba(201,162,39,.7);"
                         f"border-radius:20px;padding:6px 20px;font-size:36px;font-weight:800;color:{CREAM}'>لَم · <span style='color:{GOLD}'>قسمت ۴</span></div>"),
    "hook": ov("hook", f"<div style='position:absolute;left:60px;right:60px;top:300px;text-align:center'><div style='display:inline-block;"
                       f"background:rgba(14,22,40,.84);border:2px solid rgba(201,162,39,.6);border-radius:28px;padding:20px 44px;font-size:78px;"
                       f"font-weight:800;color:{CREAM}'>زمستون یعنی <span style='color:{GOLD}'>فقط خواب</span> 😴</div></div>"),
    "L1": ov("L1", sub("آخ جون، زمستون شد!", CREAM)),
    "L2": ov("L2", sub("پتو، چای…", CREAM)),
    "L3": ov("L3", sub("وقتشه که… بخوابم.", CREAM)),
    "P1": ov("P1", sub("لَم! کتاب؟", GOLD)),
    "L4": ov("L4", sub("هوا سرده! کتاب که پتو نمی‌شه!", CREAM)),
    "P2": ov("P2", sub("از زیر پتو هم می‌شه خوند. فقط ده صفحه.", GOLD)),
    "L5": ov("L5", sub("باشه…", CREAM)),
    "L6": ov("L6", sub("عه…", CREAM)),
    "L7": ov("L7", sub("این که خوب بود! یه صفحه‌ی دیگه؟", CREAM)),
    "P3": ov("P3", sub("زمستون، پتو، چای، و ده صفحه.", GOLD)),
    "cta": ov("cta", f"<div style='position:absolute;left:50px;right:50px;top:280px;text-align:center'><div style='display:inline-block;"
                     f"background:rgba(14,22,40,.88);border:2px solid rgba(201,162,39,.7);border-radius:30px;padding:22px 40px'>"
                     f"<div style='font-size:60px;font-weight:800;color:{CREAM};line-height:1.4'>پتو + چای + <span style='color:{GOLD}'>۱۰ صفحه</span> ☕📖</div>"
                     f"<div style='font-size:44px;font-weight:800;color:{GOLD};margin-top:10px'>شب ۹ از ۳۰ · لینک چالش تو بیو 👆</div></div></div>"
                     f"<div style='position:absolute;left:0;right:0;top:1660px;text-align:center'><div style='display:inline-flex;align-items:center;gap:18px;"
                     f"background:rgba(14,22,40,.80);border-radius:26px;padding:12px 28px 12px 18px'><img src='{ICON}' style='width:80px;height:80px;"
                     f"border-radius:20px;box-shadow:0 0 0 2px {GOLD}'><span style='font-size:48px;font-weight:800;color:{CREAM}'>پله · فالو کن</span></div></div>"),
}

# =============================================================== render
enc = subprocess.Popen([FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", str(B / "video.mp4")], stdin=subprocess.PIPE)
LAST_A = None
for k in range(N):
    t = k / FPS
    if T_CLIP <= t < T_B:
        u = (t - T_CLIP) / CLIP_LEN
        img = CLIP[min(CN - 1, int(round(u * CLIP_LEN * 30)))].astype(np.float32)
        if t - T_CLIP < 0.15 and LAST_A is not None:                # soft hand-over from the kit face to the clip's own face
            x = (t - T_CLIP) / 0.15
            img = img * x + LAST_A * (1 - x)
        img = cam(img, 1.0, 540, 960)
    else:
        img, pk = face_frame(k, t)
        if pk == "B" and t - T_B < 0.15:
            x = (t - T_B) / 0.15
            img = img * x + CLIP[min(CN - 1, int(CLIP_LEN * 30))].astype(np.float32) * (1 - x)
        sh = next((s for s in SHOTS if s[0] <= t < s[1]), SHOTS[-1]) if pk == "A" else SHOT_B
        uu = np.clip((t - sh[0]) / max(1e-3, sh[1] - sh[0]), 0, 1)
        z = sh[2] + (sh[3] - sh[2]) * uu + (0.008 * BOB[k] if pk == "A" and sh is not SHOTS[-1] else 0.006 * BOB[k])
        img = cam(img, z, sh[4], sh[5] - 4 * BOB[k])
        if pk == "A":
            LAST_A = img
    img = over(img, OV["label"])
    if t < S_("L2") - 0.1:
        img = over(img, OV["hook"], np.clip((S_("L2") - 0.1 - t) / 0.25, 0, 1))
    for key in ("L1", "L2", "L3", "P1", "L4", "P2", "L5", "L6", "L7", "P3"):
        if S_(key) - 0.05 <= t < E_(key) + 0.25 and not (key == "P3" and t >= T_CTA):
            img = over(img, OV[key], np.clip(min((t - S_(key) + 0.05) / 0.12, (E_(key) + 0.25 - t) / 0.15), 0, 1))
    if t >= T_CTA:
        img = over(img, OV["cta"], np.clip((t - T_CTA) / 0.25, 0, 1))
    if t > DUR - 0.4:
        img = img * (1 - (t - (DUR - 0.4)) / 0.4 * 0.5)
    enc.stdin.write(np.clip(img, 0, 255).astype(np.uint8).tobytes())
enc.stdin.close(); enc.wait()

# =============================================================== audio
mus = load(W0 / "reel_d012" / "music_white_clouds_leberch.mp3")
mus = mus[int(40.0 * SR):int(40.0 * SR) + NS]; mus = np.pad(mus, (0, max(0, NS - len(mus))))
voice = lam_tr + pel_tr
actv = np.convolve((np.abs(voice) > 0.01).astype(np.float32), np.ones(int(0.25 * SR)) / int(0.25 * SR), "same") > 0.02
duck = np.convolve(np.where(actv, 0.09, 0.20).astype(np.float32), np.ones(int(0.3 * SR)) / int(0.3 * SR), "same")
tt = np.arange(NS) / SR
duck *= np.clip(tt / 0.4, 0, 1) * np.clip((DUR - tt) / 0.7, 0, 1)
mix = voice + mus * duck


def add(x, at, g):
    i = int(at * SR)
    if 0 <= i < NS:
        n = max(0, min(len(x), NS - i)); mix[i:i + n] += x[:n] * g


wh = load(W0 / "reel_d013" / "_build" / "sfx_whoosh.wav")
add(wh, SHOTS[1][0] - 0.05, 0.07)
add(wh, T_CLIP - 0.05, 0.08)
pt = load(W0 / "audio" / "page_turn.wav"); pt = pt[:int(0.9 * SR)] * np.linspace(1, 0, int(0.9 * SR)) ** 0.5
add(pt, T_CLIP + 2.3, 0.35)                 # book opens (~5.2 s of the source clip)
ding_wav(B / "ding.wav", at=0.0, total=2.0, sr=SR)
add(load(B / "ding.wav"), T_CTA + 0.05, 0.5)
mix = mix[:int(DUR * SR)]; mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
with wave.open(str(B / "mix.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype(np.int16).tobytes())


def lufs(path):
    e = subprocess.run([FF, "-hide_banner", "-i", str(path), "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    s_ = e[e.rindex("Summary:"):]
    return float(s_.split("I:")[1].split("LUFS")[0]), float(s_.split("Peak:")[1].split("dBFS")[0])


I0, _ = lufs(B / "mix.wav"); gain = TARGET_I - I0
for _ in range(4):
    subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "mix.wav"), "-af", f"volume={gain:.2f}dB,alimiter=limit=0.84:attack=3:release=60:level=false,aresample=48000",
                    "-ac", "2", str(B / "mix_norm.wav")], check=True)
    I1, tp1 = lufs(B / "mix_norm.wav")
    if abs(I1 - TARGET_I) < 0.3:
        break
    gain += TARGET_I - I1
out = EP / "lam_ep4_final.mp4"
subprocess.run([FF, "-y", "-v", "error", "-i", str(B / "video.mp4"), "-i", str(B / "mix_norm.wav"), "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                "-shortest", "-movflags", "+faststart", str(out)], check=True)
subprocess.run([FF, "-y", "-v", "error", "-i", str(out), "-c:v", "libx264", "-preset", "slow", "-b:v", "1900k", "-maxrate", "2400k", "-bufsize", "4800k",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(EP / "lam_ep4_final_upload.mp4")], check=True)
subprocess.run([FF, "-y", "-v", "error", "-i", str(out), "-vf", "fps=2,scale=216:384,tile=10x7", "-frames:v", "1", str(B / "check.jpg")], check=True)
json.dump({"segments": {k: [round(v[0], 3), round(v[1], 3)] for k, v in segs.items()}, "T_CLIP": T_CLIP, "T_B": T_B, "T_CTA": T_CTA, "DUR": DUR,
           "loudness": {"input_I": I0, "out_I": I1, "out_TP": tp1}}, open(EP / "lam_ep4_timeline.json", "w"), indent=1)
print("done", out, round(DUR, 2), "LUFS", I1)
