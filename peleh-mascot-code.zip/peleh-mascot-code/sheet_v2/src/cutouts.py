﻿"""Transparent cut-outs of the 8 v1 poses/views (free method: background model + GrabCut, OpenCV only)."""
from pathlib import Path
import numpy as np, cv2

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT.parent / "ref" / "lam_character_sheet_v1.jpg"
OUT = ROOT / "cutouts"
OUT.mkdir(exist_ok=True)
img = cv2.imread(str(SRC))
H, W = img.shape[:2]

CELLS = {  # x0, y0, x1, y1 (excludes the labels)
    "lam_v1_view_front": (285, 28, 625, 398),
    "lam_v1_view_side": (640, 40, 835, 398),
    "lam_v1_view_back": (868, 30, 1200, 398),
    "lam_v1_view_34": (1215, 30, 1495, 398),
    "lam_v1_pose_sarcastic": (75, 555, 425, 912),
    "lam_v1_pose_tired": (445, 600, 790, 912),
    "lam_v1_pose_excited": (785, 530, 1130, 905),
    "lam_v1_pose_curious": (1170, 565, 1455, 912),
}


def bg_model(cell):
    """Smooth background estimate from the cell border (2nd order poly per channel)."""
    h, w = cell.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    border = np.zeros((h, w), bool)
    b = 6
    border[:b] = border[-b:] = True
    border[:, :b] = border[:, -b:] = True
    gx, gy = xx / w - .5, yy / h - .5
    A = np.stack([np.ones_like(gx), gx, gy, gx * gx, gx * gy, gy * gy], -1)
    out = np.zeros_like(cell, np.float32)
    for c in range(3):
        coef, *_ = np.linalg.lstsq(A[border], cell[..., c][border].astype(np.float32), rcond=None)
        out[..., c] = A @ coef
    return out


for name, (x0, y0, x1, y1) in CELLS.items():
    cell = img[y0:y1, x0:x1].copy()
    bg = bg_model(cell)
    d = np.linalg.norm(cell.astype(np.float32) - bg, axis=2)
    lab = cv2.cvtColor(cell, cv2.COLOR_BGR2LAB).astype(np.float32)
    lab_bg = cv2.cvtColor(np.clip(bg, 0, 255).astype(np.uint8), cv2.COLOR_BGR2LAB).astype(np.float32)
    dl = np.linalg.norm(lab - lab_bg, axis=2)
    score = np.maximum(d, dl * 1.3)
    gc = np.full(cell.shape[:2], cv2.GC_PR_BGD, np.uint8)
    gc[score > 18] = cv2.GC_PR_FGD
    gc[score > 45] = cv2.GC_FGD
    gc[score < 7] = cv2.GC_BGD
    # floor shadow / vignette: darker than bg but NOT more blue than bg and not bright -> background
    cf, bf = cell.astype(np.float32), bg
    blue = (cf[..., 0] - cf[..., 2]) - (bf[..., 0] - bf[..., 2])
    shadow = (blue < 10) & (cf.sum(2) < bf.sum(2) + 25)
    shadow[: int(cell.shape[0] * 0.92)] = False          # floor band only (bottom 20% of the cell)
    gc[shadow & (gc != cv2.GC_FGD)] = cv2.GC_PR_BGD
    gc[shadow & (score < 30)] = cv2.GC_BGD
    gc[:4] = gc[-2:] = cv2.GC_BGD
    gc[:, :4] = gc[:, -4:] = cv2.GC_BGD
    bgd, fgd = np.zeros((1, 65)), np.zeros((1, 65))
    cv2.grabCut(cell, gc, None, bgd, fgd, 6, cv2.GC_INIT_WITH_MASK)
    m = np.isin(gc, (cv2.GC_FGD, cv2.GC_PR_FGD)).astype(np.uint8)
    low = np.zeros_like(m, bool); low[int(m.shape[0] * 0.75):] = True
    m[low & (score < 10)] = 0                                    # floor shadow near the feet
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    # keep the character (largest component) — drops '?' marks, motion lines, floor shadow specks
    n, lbl, st, _ = cv2.connectedComponentsWithStats(m)
    if n > 1:
        k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
        m = (lbl == k).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    # fill holes
    ff = m.copy()
    h, w = m.shape
    fm = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(ff, fm, (0, 0), 1)
    holes = (ff == 0).astype(np.uint8)
    nh, lh, sh, _ = cv2.connectedComponentsWithStats(holes)
    for j in range(1, nh):
        hm = lh == j
        if sh[j, cv2.CC_STAT_AREA] < 900 or score[hm].mean() > 12:   # body-coloured holes; bg-coloured limb gaps stay clear
            m[lh == j] = 1
    alpha = cv2.GaussianBlur(m.astype(np.float32), (0, 0), 0.8)
    # decontaminate edge colour slightly toward the inside
    rgba = np.dstack([cell, (alpha * 255).astype(np.uint8)])
    ys, xs = np.nonzero(m)
    pad = 6
    rgba = rgba[max(0, ys.min() - pad):ys.max() + pad, max(0, xs.min() - pad):xs.max() + pad]
    # upscale 2x for layout use (source is 1536 px wide; marked as low-res in the report)
    rgba = cv2.resize(rgba, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    cv2.imwrite(str(OUT / f"{name}.png"), rgba)
    print(name, rgba.shape)
