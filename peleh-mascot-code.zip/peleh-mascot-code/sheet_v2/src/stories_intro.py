"""3 intro Stories for لَم (1080x1920 PNG + 5 s subtle-motion MP4). Sticker zones left EMPTY; top 250 / bottom 300 px text-free."""
from pathlib import Path
import shutil, subprocess
import numpy as np, cv2
from PIL import Image
import imageio_ffmpeg
from render_util import html_to_png, FONT

ROOT = Path(__file__).resolve().parents[1]
MASCOT = ROOT.parent
OUT = MASCOT / "stories_intro"; OUT.mkdir(exist_ok=True)
COPY = MASCOT.parents[1] / "peleh_copy_texts" / "stories_lam"; COPY.mkdir(parents=True, exist_ok=True)
FF = imageio_ffmpeg.get_ffmpeg_exe()
NAVY, CREAM, GOLD = "#1B2A4A", "#F2EAD3", "#C9A227"
GOLDV = np.array([0xC9, 0xA2, 0x27], np.float32)


def plate(img, top):
    """Scale a 1333x2000 render to width 1080 and place it at y=top; extend top/bottom with a blurred mirrored band."""
    s = 1080 / img.shape[1]
    sm = cv2.resize(img, (1080, round(img.shape[0] * s)), interpolation=cv2.INTER_AREA).astype(np.float32)
    h = sm.shape[0]
    out = np.zeros((1920, 1080, 3), np.float32)
    y1 = min(1920, top + h)
    out[top:y1] = sm[:y1 - top]
    if top > 0:
        band = sm[:120][::-1]
        rep = np.concatenate([band] * (top // 120 + 2), 0)[:top]
        out[:top] = (cv2.GaussianBlur(rep, (0, 0), 28) * np.linspace(1, 0.8, top)[:, None, None])[::-1]
    if y1 < 1920:
        n = 1920 - y1
        band = sm[-120:][::-1]
        rep = np.concatenate([band] * (n // 120 + 2), 0)[:n]
        out[y1:] = cv2.GaussianBlur(rep, (0, 0), 28) * np.linspace(1, 0.8, n)[:, None, None]
    bl = cv2.GaussianBlur(out, (0, 0), 8)
    ys = np.arange(1920)[:, None, None]
    w = np.zeros((1920, 1, 1), np.float32)
    for y0 in (top, y1):
        w = np.maximum(w, np.clip(1 - np.abs(ys - y0) / 36.0, 0, 1))
    return out * (1 - w) + bl * w, s


def ring_mask(p):
    r, g, b = p[..., 0], p[..., 1], p[..., 2]
    m = ((r > 150) & (r > b + 35) & (g > 110)).astype(np.float32)
    return cv2.GaussianBlur(m, (0, 0), 6)


def text_layer(name, body):
    css = (f"@font-face{{font-family:Vaz;src:url('{FONT}') format('woff2');font-weight:100 900}}"
           "html,body{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}body{font-family:Vaz;direction:rtl}")
    p = OUT / f"_txt_{name}.png"
    html_to_png(f"<!doctype html><meta charset='utf-8'><style>{css}</style>{body}", p, 1080, 1920)
    a = np.asarray(Image.open(p).convert("RGBA")).astype(np.float32)
    p.unlink()
    return a


def over(img, rgba):
    a = rgba[..., 3:] / 255
    return img * (1 - a) + rgba[..., :3] * a


def vignette(img, top=0.55, bottom=0.6):
    y = np.linspace(0, 1, 1920)[:, None, None]
    g = 1 - top * np.clip((0.22 - y) / 0.22, 0, 1) ** 1.5 - bottom * np.clip((y - 0.80) / 0.20, 0, 1) ** 1.5
    return img * g


def zoom(img, z, cy=0.45):
    h, w = img.shape[:2]
    ch, cw = int(h / z), int(w / z)
    y0, x0 = int((h - ch) * cy), (w - cw) // 2
    return cv2.resize(img[y0:y0 + ch, x0:x0 + cw], (w, h), interpolation=cv2.INTER_LINEAR)


def build(name, base, txt, ring, rimfx=None):
    still = over(base, txt)
    Image.fromarray(np.clip(still, 0, 255).astype(np.uint8)).save(OUT / f"{name}.png")
    enc = subprocess.Popen([FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920", "-r", "30", "-i", "-",
                            "-c:v", "libx264", "-crf", "18", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(OUT / f"{name}.mp4")], stdin=subprocess.PIPE)
    for k in range(150):
        t = k / 30
        img = base.copy()
        pulse = 0.5 + 0.5 * np.sin(2 * np.pi * t / 2.5)
        img = 255 - (255 - img) * (1 - ring[..., None] * (0.10 + 0.14 * pulse) * np.array([1.0, 0.85, 0.5]))
        if rimfx is not None:
            img = 255 - (255 - img) * (1 - rimfx[..., None] * (0.25 + 0.35 * pulse) * GOLDV / 255)
        img = zoom(img, 1.0 + 0.035 * t / 5)
        img = over(img, txt)                                   # text stays crisp and fixed
        enc.stdin.write(np.clip(img, 0, 255).astype(np.uint8).tobytes())
    enc.stdin.close(); enc.wait()
    for ext in ("png", "mp4"):
        shutil.copy2(OUT / f"{name}.{ext}", COPY / f"{name}.{ext}")
    print(name)


H1 = "font-size:74px;font-weight:800;line-height:1.45;color:" + CREAM
SMALL = f"font-size:40px;font-weight:500;color:{GOLD}"
card = lambda inner, top: (f"<div style='position:absolute;left:70px;right:70px;top:{top}px;text-align:center'>"
                           f"<div style='display:inline-block;background:rgba(12,19,36,.62);border:2px solid rgba(201,162,39,.45);border-radius:34px;padding:26px 40px'>{inner}</div></div>")

# ---------------------------------------------------------------- S1: empty room, question
r4 = cv2.imread(str(MASCOT / "renders_vahid" / "R4.jpg"))[:, :, ::-1]
b1, _ = plate(r4, 250)
b1 = vignette(b1 * np.array([1.03, 1.0, 0.96]))
t1 = text_layer("s1", card(f"<div style='{H1}'>بهانه‌ی همیشگی‌ت<br>برای شروع نکردن چیه؟</div>"
                           f"<div style='{SMALL};margin-top:14px'>جواب‌ها ناشناس می‌مونن</div>", 262))
build("lam_story_S1_sat16aban", b1, t1, ring_mask(b1))

# ---------------------------------------------------------------- S2: TRUE silhouette (character + bean bag one near-black shape)
r3a = cv2.imread(str(MASCOT / "renders_vahid" / "R3a.jpg"))[:, :, ::-1].astype(np.float32)
lum = r3a @ np.array([0.299, 0.587, 0.114])
ringm = ring_mask(r3a); ringm[950:] = 0; ringm[:, :250] = 0
H_, W_ = lum.shape
src8 = r3a[:, :, ::-1].astype(np.uint8)
gc = np.full((H_, W_), cv2.GC_PR_BGD, np.uint8)
gc[:, :] = cv2.GC_BGD
cv2.rectangle(gc, (20, 540), (1320, 1760), cv2.GC_PR_BGD, -1)
fgp = np.array([(470, 600), (700, 570), (1060, 930), (1250, 1150), (1250, 1600), (220, 1680), (60, 1320), (240, 1000), (450, 960)], np.int32)
cv2.fillPoly(gc, [fgp], cv2.GC_PR_FGD)
cv2.fillPoly(gc, [np.array([(520, 650), (680, 620), (980, 980), (1100, 1200), (1100, 1500), (400, 1550), (300, 1300), (480, 1000)], np.int32)], cv2.GC_FGD)
gc[ringm > 0.3] = cv2.GC_BGD
bgd, fgd = np.zeros((1, 65)), np.zeros((1, 65))
small = cv2.resize(src8, (W_ // 2, H_ // 2)); gcs = cv2.resize(gc, (W_ // 2, H_ // 2), interpolation=cv2.INTER_NEAREST)
cv2.grabCut(small, gcs, None, bgd, fgd, 5, cv2.GC_INIT_WITH_MASK)
fg = cv2.resize(np.isin(gcs, (1, 3)).astype(np.uint8), (W_, H_), interpolation=cv2.INTER_NEAREST)
n, lbl, st, _ = cv2.connectedComponentsWithStats(fg)
fg = (lbl == 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])).astype(np.uint8)
fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
cv2.fillPoly(fg, [np.array([(474, 612), (492, 588), (700, 566), (830, 596), (838, 722), (948, 734), (956, 912), (1058, 914), (1062, 1250), (470, 1250)], np.int32)], 1)
fg = (cv2.GaussianBlur(fg.astype(np.float32), (0, 0), 5) > 0.5).astype(np.uint8)
ff = fg.copy(); cv2.floodFill(ff, np.zeros((H_ + 2, W_ + 2), np.uint8), (0, 0), 1); fg[ff == 0] = 1
sil = cv2.GaussianBlur(fg.astype(np.float32), (0, 0), 1.2)[..., None]
# backlit room: wall slightly brighter, floor dark, silhouette #0B1220
room = r3a * 0.55 + np.array([4, 6, 14], np.float32)
glow = cv2.GaussianBlur(ringm, (0, 0), 60)[..., None] * 0.9
room = 255 - (255 - room) * (1 - glow * np.array([0.55, 0.45, 0.25]))
room = room * (1 - ringm[..., None]) + r3a * ringm[..., None]
dark = room * (1 - sil) + np.array([0x0B, 0x12, 0x20], np.float32) * sil
# thin gold rim on the upper outline of the shape (backlight from the halo)
er = cv2.erode(fg, np.ones((7, 7), np.uint8))
edge = (fg - er).astype(np.float32)
ys, xs = np.nonzero(fg)
topw = np.zeros_like(edge)
for x in range(xs.min(), xs.max() + 1):
    col = ys[xs == x]
    if len(col):
        if 440 <= x <= 1075 and col.min() < 960:
            topw[col.min():col.min() + 5, x] = 1
dist = np.clip(1 - np.abs(np.arange(H_)[:, None] - 760) / 520, 0, 1)        # strongest near the halo height
edge = topw * dist
rim = cv2.GaussianBlur(edge, (0, 0), 1.6) * 1.8 + cv2.GaussianBlur(edge, (0, 0), 9) * 1.2
dark = 255 - (255 - dark) * (1 - np.clip(rim, 0, 1)[..., None] * GOLDV / 255 * 0.95)
b2, s2 = plate(np.clip(dark, 0, 255).astype(np.uint8), 150)
rim_s = np.zeros((1920, 1080), np.float32)
rim_s[150:150 + round(2000 * s2)] = cv2.resize(np.clip(rim, 0, 1), (1080, round(2000 * s2)))[:1920 - 150]
b2 = vignette(b2)
t2 = text_layer("s2", card(f"<div style='{H1}'>یه نفر داره میاد…</div>"
                           f"<div style='font-size:44px;font-weight:600;color:{GOLD};margin-top:10px'>که همیشه از فردا شروع می‌کنه.</div>", 290))
build("lam_story_S2_sun17aban_teaser", b2, t2, ring_mask(b2) * 0.8, rim_s * 0.6)

# ---------------------------------------------------------------- S3: reveal (R3c + polished face E01, step 4 softly glazed)
r3c = cv2.imread(str(ROOT / "style_test" / "vr_R3c_E01.png"))[:, :, ::-1].astype(np.float32)
m4 = cv2.imread(str(ROOT / "fx" / "masks" / "body_step4_mask_R3c.png"), 0).astype(np.float32) / 255
soft = cv2.GaussianBlur(m4, (0, 0), 8)
ys4 = np.nonzero(m4 > 0.5)[0]
yy = np.arange(m4.shape[0], dtype=np.float32)[:, None]
grad = np.clip((ys4.max() - yy) / (ys4.max() - ys4.min()), 0, 1)
er = cv2.erode((m4 > 0.5).astype(np.uint8), np.ones((13, 13), np.uint8)).astype(np.float32)
rim4 = np.clip(cv2.GaussianBlur((m4 > 0.5).astype(np.float32) - er, (0, 0), 3) * 1.6, 0, 1) * (yy < ys4.min() + 40)
w = np.clip(soft * (0.38 + 0.42 * grad) + rim4 * 0.45, 0, 0.9)[..., None] * 0.62
l3 = (r3c @ np.array([0.299, 0.587, 0.114], np.float32))[..., None]
gold_col = np.clip(GOLDV / 159.6 * l3 * 1.85 * np.array([1.18, 0.96, 0.62], np.float32), 0, 255)
lit = r3c * (1 - w) + gold_col * w
glow = cv2.GaussianBlur(m4, (0, 0), 30)[..., None] * 0.12
lit = 255 - (255 - lit) * (1 - glow * GOLDV / 255)
b3, s3 = plate(np.clip(lit, 0, 255).astype(np.uint8), 210)
b3 = vignette(b3, 0.5, 0.55)
t3 = text_layer("s3", (f"<div style='position:absolute;left:0;right:0;top:262px;text-align:center;font-size:92px;font-weight:900;color:{CREAM};"
                       f"text-shadow:0 4px 24px rgba(0,0,0,.55)'>سلام. من لَم‌ام.</div>"
                       f"<div style='position:absolute;left:0;right:0;top:392px;text-align:center;font-size:40px;font-weight:500;color:{GOLD}'>(از لم دادن)</div>"
                       f"<div style='position:absolute;right:60px;top:1548px;background:rgba(12,19,36,.72);border:2px solid rgba(201,162,39,.5);border-radius:22px;"
                       f"padding:8px 24px;font-size:36px;font-weight:700;color:{CREAM}'>بهانه‌های لَم · قسمت ۱ <span style='color:{GOLD}'>تو ریلز</span></div>"))
build("lam_story_S3_reveal", b3, t3, ring_mask(b3))
