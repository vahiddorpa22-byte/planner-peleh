package ir.pelehapp.app;

import android.content.Context;
import android.content.pm.InstallSourceInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * پلاگین کوچیک برای گرفتن installer package name — یعنی این APK از کدوم
 * اپ/فروشگاه نصب شده. لازم برای تشخیص "نصب از کافه‌بازار" (com.farsitel.bazaar)
 * در برابر APK دانلود مستقیم از سایت خودمون.
 *
 * جاوااسکریپت (بدون بندلر، مستقیم تو app.js/books.js):
 *   const { installer } = await Capacitor.Plugins.InstallSource.getInstallerPackageName();
 */
@CapacitorPlugin(name = "InstallSource")
public class InstallSourcePlugin extends Plugin {

    @PluginMethod
    public void getInstallerPackageName(PluginCall call) {
        Context ctx = getContext();
        String pkg = ctx.getPackageName();
        String installer = null;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                InstallSourceInfo info = ctx.getPackageManager().getInstallSourceInfo(pkg);
                installer = info.getInstallingPackageName();
            } else {
                installer = ctx.getPackageManager().getInstallerPackageName(pkg);
            }
        } catch (Exception e) {
            installer = null;
        }

        JSObject result = new JSObject();
        result.put("installer", installer != null ? installer : "");
        call.resolve(result);
    }
}
