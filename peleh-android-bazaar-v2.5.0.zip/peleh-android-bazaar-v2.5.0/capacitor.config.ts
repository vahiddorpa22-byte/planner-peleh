import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "ir.pelehapp.app",
  appName: "پله",
  webDir: "www",
  plugins: {
    LocalNotifications: {
      smallIcon: "ic_stat_peleh",
      iconColor: "#D4A84B"
    }
  }
};

export default config;
